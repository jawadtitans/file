import 'dart:convert';
import 'package:flutter/services.dart';
import '../data/datamodels/chaper_model.dart';
import '../data/datamodels/verces.dart';

class QuranService {
  List<Chapter> _chapters = [];
  List<Verse> _verses = [];

  Future<void> loadQuran() async {
    final String response = await rootBundle.loadString(
      'assets/json/quran.json',
    );
    final data = json.decode(response);
    _chapters = (data['chapters'] as List)
        .map((e) => Chapter.fromJson(e))
        .toList();

    _verses = (data['verses'] as List).map((e) => Verse.fromJson(e)).toList();
  }

  List<Chapter> getChapters() => _chapters;

  List<Verse> getVersesBySurah(int surahNumber) {
    return _verses.where((verse) => verse.surah == surahNumber).toList();
  }
}
