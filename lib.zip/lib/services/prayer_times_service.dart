import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AfghanProvince {
  final String name;
  final String nameDari;
  final double latitude;
  final double longitude;
  final double utcOffset;
  const AfghanProvince({
    required this.name,
    required this.nameDari,
    required this.latitude,
    required this.longitude,
    this.utcOffset = 4.5,
  });
}

const List<AfghanProvince> afghanProvinces = [
  AfghanProvince(
    name: 'Kabul',
    nameDari: 'کابل',
    latitude: 34.5553,
    longitude: 69.2075,
  ),
  AfghanProvince(
    name: 'Herat',
    nameDari: 'هرات',
    latitude: 34.3482,
    longitude: 62.1999,
  ),
  AfghanProvince(
    name: 'Mazar-i-Sharif',
    nameDari: 'مزارشریف',
    latitude: 36.7069,
    longitude: 67.1128,
  ),
  AfghanProvince(
    name: 'Kandahar',
    nameDari: 'قندهار',
    latitude: 31.6129,
    longitude: 65.7372,
  ),
  AfghanProvince(
    name: 'Jalalabad',
    nameDari: 'جلال‌آباد',
    latitude: 34.4314,
    longitude: 70.4525,
  ),
  AfghanProvince(
    name: 'Kunduz',
    nameDari: 'کندز',
    latitude: 36.7287,
    longitude: 68.8681,
  ),
  AfghanProvince(
    name: 'Bamyan',
    nameDari: 'بامیان',
    latitude: 34.8188,
    longitude: 67.8311,
  ),
  AfghanProvince(
    name: 'Ghazni',
    nameDari: 'غزنی',
    latitude: 33.5539,
    longitude: 68.4212,
  ),
  AfghanProvince(
    name: 'Daikundi',
    nameDari: 'دایکندی',
    latitude: 33.6691,
    longitude: 66.0197,
  ),
  AfghanProvince(
    name: 'Farah',
    nameDari: 'فراه',
    latitude: 32.3731,
    longitude: 62.1139,
  ),
  AfghanProvince(
    name: 'Badakhshan',
    nameDari: 'بدخشان',
    latitude: 36.7337,
    longitude: 70.8117,
  ),
  AfghanProvince(
    name: 'Baghlan',
    nameDari: 'بغلان',
    latitude: 36.1701,
    longitude: 68.7068,
  ),
  AfghanProvince(
    name: 'Logar',
    nameDari: 'لوگر',
    latitude: 33.9833,
    longitude: 69.1500,
  ),
  AfghanProvince(
    name: 'Paktia',
    nameDari: 'پکتیا',
    latitude: 33.9861,
    longitude: 69.9024,
  ),
  AfghanProvince(
    name: 'Balkh',
    nameDari: 'بلخ',
    latitude: 36.7569,
    longitude: 66.8975,
  ),
];

enum PrayerMadhab { sunni, shia }

class PrayerMethod {
  final String name;
  final String nameDari;
  final double fajrAngle;
  final double ishaAngle;
  final PrayerMadhab madhab;
  const PrayerMethod({
    required this.name,
    required this.nameDari,
    required this.fajrAngle,
    required this.ishaAngle,
    required this.madhab,
  });
}

const sunniMethod = PrayerMethod(
  name: 'Sunni (Hanafi)',
  nameDari: 'اوقات نماز سنی',
  fajrAngle: 18.0,
  ishaAngle: 18.0,
  madhab: PrayerMadhab.sunni,
);
const shiaMethod = PrayerMethod(
  name: 'Shia (IGP Tehran)',
  nameDari: 'اوقات نماز شیعه',
  fajrAngle: 16.0,
  ishaAngle: 14.0,
  madhab: PrayerMadhab.shia,
);

class PrayerTimes {
  final DateTime fajr, sunrise, dhuhr, asr, maghrib, isha;
  const PrayerTimes({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });
}

class PrayerTimesCalculator {
  static PrayerTimes calculate({
    required double latitude,
    required double longitude,
    required DateTime date,
    required PrayerMethod method,
  }) {
    final jd = _jd(date.year, date.month, date.day);
    final eq = _eqTime(jd);
    final decl = _decl(jd);
    final lat = latitude * math.pi / 180;
    final dec = decl * math.pi / 180;
    final transit = 12.0 - longitude / 15.0 - eq + 4.5;

    double ha(double angle) {
      final cosH =
          (math.sin(angle * math.pi / 180) - math.sin(lat) * math.sin(dec)) /
          (math.cos(lat) * math.cos(dec));
      if (cosH < -1 || cosH > 1) return 0;
      return math.acos(cosH) * 180 / math.pi / 15;
    }

    final fajrH = ha(-method.fajrAngle);
    final srH = ha(-0.8333);
    final sf = method.madhab == PrayerMadhab.sunni ? 2.0 : 1.0;
    final asrA = math.atan(1.0 / (sf + math.tan((lat - dec).abs())));
    final cosAsrH =
        ((math.sin(asrA) - math.sin(lat) * math.sin(dec)) /
                (math.cos(lat) * math.cos(dec)))
            .clamp(-1.0, 1.0);
    final asrH = math.acos(cosAsrH) * 180 / math.pi / 15;
    final ishaH = ha(-method.ishaAngle);

    return PrayerTimes(
      fajr: _dt(date, transit - fajrH),
      sunrise: _dt(date, transit - srH),
      dhuhr: _dt(date, transit),
      asr: _dt(date, transit + asrH),
      maghrib: _dt(date, transit + srH),
      isha: _dt(date, transit + ishaH),
    );
  }

  static double _jd(int y, int m, int d) {
    if (m <= 2) {
      y -= 1;
      m += 12;
    }
    final a = (y / 100).floor();
    final b = 2 - a + (a / 4).floor();
    return (365.25 * (y + 4716)).floor() +
        (30.6001 * (m + 1)).floor() +
        d +
        b -
        1524.5;
  }

  static double _eqTime(double jd) {
    final t = (jd - 2451545.0) / 36525.0;
    final eps = 23.439291111 - 0.013004167 * t;
    final l0 = (280.46646 + 36000.76983 * t) % 360;
    final m = (357.52911 + 35999.05029 * t) * math.pi / 180;
    final e = 0.016708634 - 0.000042037 * t;
    final y = math.pow(math.tan(eps * math.pi / 360), 2).toDouble();
    final l0r = l0 * math.pi / 180;
    return (y * math.sin(2 * l0r) -
            2 * e * math.sin(m) +
            4 * e * y * math.sin(m) * math.cos(2 * l0r) -
            0.5 * y * y * math.sin(4 * l0r) -
            1.25 * e * e * math.sin(2 * m)) *
        4 *
        180 /
        math.pi /
        60;
  }

  static double _decl(double jd) {
    final t = (jd - 2451545.0) / 36525.0;
    final eps = 23.439291111 - 0.013004167 * t;
    final l0 = (280.46646 + 36000.76983 * t) % 360;
    final m = (357.52911 + 35999.05029 * t) * math.pi / 180;
    final c =
        (1.914602 - 0.004817 * t) * math.sin(m) +
        (0.019993 - 0.000101 * t) * math.sin(2 * m) +
        0.000289 * math.sin(3 * m);
    return math.asin(
          math.sin(eps * math.pi / 180) * math.sin((l0 + c) * math.pi / 180),
        ) *
        180 /
        math.pi;
  }

  static DateTime _dt(DateTime d, double h) {
    if (h.isNaN || h.isInfinite)
      return d.copyWith(hour: 0, minute: 0, second: 0);
    final tm = (h * 60).round();
    return DateTime(d.year, d.month, d.day, (tm ~/ 60) % 24, tm % 60);
  }
}

class PrayerSettingsService {
  static const _pk = 'selected_province_index';
  static const _mk = 'selected_madhab';
  static const _sk = 'selected_adhan_sound';

  static Future<void> saveProvinceIndex(int i) async =>
      (await SharedPreferences.getInstance()).setInt(_pk, i);
  static Future<int> getProvinceIndex() async =>
      (await SharedPreferences.getInstance()).getInt(_pk) ?? 0;
  static Future<void> saveMadhab(PrayerMadhab m) async =>
      (await SharedPreferences.getInstance()).setString(
        _mk,
        m == PrayerMadhab.sunni ? 'sunni' : 'shia',
      );
  static Future<PrayerMadhab> getMadhab() async {
    final v = (await SharedPreferences.getInstance()).getString(_mk) ?? 'sunni';
    return v == 'shia' ? PrayerMadhab.shia : PrayerMadhab.sunni;
  }

  static Future<void> saveAdhanSound(String k) async =>
      (await SharedPreferences.getInstance()).setString(_sk, k);
  static Future<String> getAdhanSound() async =>
      (await SharedPreferences.getInstance()).getString(_sk) ?? 'adhan_makkah';
}

class AdhanSound {
  final String key, name, nameDari, downloadUrl, description;
  const AdhanSound({
    required this.key,
    required this.name,
    required this.nameDari,
    required this.downloadUrl,
    required this.description,
  });
}

const List<AdhanSound> adhanSounds = [
  AdhanSound(
    key: 'adhan_makkah',
    name: 'Makkah Adhan',
    nameDari: 'اذان مکه',
    downloadUrl: 'https://www.islamcan.com/audio/adhan/azan1.mp3',
    description: 'Classic Makkah call to prayer',
  ),
  AdhanSound(
    key: 'adhan_medina',
    name: 'Medina Adhan',
    nameDari: 'اذان مدینه',
    downloadUrl: 'https://www.islamcan.com/audio/adhan/azan2.mp3',
    description: 'Medina style call to prayer',
  ),
  AdhanSound(
    key: 'adhan_egypt',
    name: 'Egyptian Adhan',
    nameDari: 'اذان مصری',
    downloadUrl: 'https://www.islamcan.com/audio/adhan/azan3.mp3',
    description: 'Egyptian style call to prayer',
  ),
  AdhanSound(
    key: 'adhan_turkey',
    name: 'Turkish Adhan',
    nameDari: 'اذان ترکی',
    downloadUrl: 'https://www.islamcan.com/audio/adhan/azan4.mp3',
    description: 'Turkish style call to prayer',
  ),
];

class AdhanDownloadManager {
  static Future<Directory> _dir() async {
    final d = Directory(
      '${(await getApplicationDocumentsDirectory()).path}/adhan_sounds',
    );
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<String?> getLocalPath(String key) async {
    try {
      final f = File('${(await _dir()).path}/adhan_$key.mp3');
      if (await f.exists()) return f.path;
    } catch (_) {}
    return null;
  }

  static Future<bool> isDownloaded(String key) async =>
      (await getLocalPath(key)) != null;

  static Future<String?> download(
    String key,
    String url, {
    ValueChanged<double>? onProgress,
  }) async {
    try {
      final file = File('${(await _dir()).path}/adhan_$key.mp3');
      final client = http.Client();
      final req = http.Request('GET', Uri.parse(url));
      final res = await client.send(req);
      if (res.statusCode != 200) {
        client.close();
        return null;
      }
      final total = res.contentLength ?? 0;
      int received = 0;
      final sink = file.openWrite();
      await for (final chunk in res.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) onProgress?.call(received / total);
      }
      await sink.close();
      client.close();
      return file.path;
    } catch (e) {
      debugPrint('Download error: $e');
      return null;
    }
  }

  static Future<void> delete(String key) async {
    try {
      final f = File('${(await _dir()).path}/adhan_$key.mp3');
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}

// ── Afghanistan Events (by Gregorian month/day approximation) ─────────────

class AfghanEvent {
  final String nameDari;
  final int month, day;
  const AfghanEvent({
    required this.nameDari,
    required this.month,
    required this.day,
  });
}

const List<AfghanEvent> _allAfghanEvents = [
  AfghanEvent(nameDari: 'نوروز - آغاز سال نو افغانستان', month: 3, day: 21),
  AfghanEvent(nameDari: 'روز استرداد استقلال افغانستان', month: 8, day: 19),
  AfghanEvent(nameDari: 'یادبود قربانیان جنگ', month: 4, day: 28),
  AfghanEvent(nameDari: 'میلاد پیامبر اکرم (ص)', month: 9, day: 15),
  AfghanEvent(nameDari: 'عید سعید فطر (تقریبی)', month: 3, day: 30),
  AfghanEvent(nameDari: 'عید سعید قربان (تقریبی)', month: 6, day: 7),
  AfghanEvent(nameDari: 'عاشورای حسینی (تقریبی)', month: 7, day: 16),
];

List<AfghanEvent> eventsForDate(DateTime date) => _allAfghanEvents
    .where((e) => e.month == date.month && e.day == date.day)
    .toList();
