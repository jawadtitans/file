import 'package:shared_preferences/shared_preferences.dart';

class OnboardingLocalService {
  static const _key = "onboarding_completed";
  static const _latKey = "user_latitude";
  static const _lngKey = "user_longitude";

  Future<void> saveLocation(double lat, double lng) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_latKey, lat);
    await prefs.setDouble(_lngKey, lng);
  }

  Future<({double? lat, double? lng})> getLocation() async {
    final prefs = await SharedPreferences.getInstance();
    return (lat: prefs.getDouble(_latKey), lng: prefs.getDouble(_lngKey));
  }

  Future<bool> isCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_key) ?? false;
  }

  Future<void> setCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key, true);
  }
}
