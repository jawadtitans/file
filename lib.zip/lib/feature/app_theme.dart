import 'package:quran_app/exportfile.dart';

// Assuming this is the correct path

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    textSelectionTheme: TextSelectionThemeData(
      selectionColor: QuranColors.creamColor,
    ),

    fontFamily: const_texts.fontname,
    primaryColor: const Color.fromARGB(255, 62, 129, 62),
    brightness: Brightness.light,
    splashColor: Color(0xFFeaedf2),
    splashFactory: InkRipple.splashFactory,
    searchBarTheme: SearchBarThemeData(
      backgroundColor: WidgetStateProperty.all(Color(0xFFeaedf2)),
    ),
    scaffoldBackgroundColor: QuranColors.deepGreenColor,
    appBarTheme: AppBarTheme(
      iconTheme: IconThemeData(color: Color(0xFFeaedf2)),
      elevation: 0,
      backgroundColor: QuranColors.deepGreenColor,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
      actionsIconTheme: IconThemeData(color: Colors.white, size: 20),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: Color(0xFFe9edec),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadiusGeometry.circular(25),
      ),
      elevation: 0.0,
      dragHandleColor: Colors.grey.shade500,
    ),
    buttonTheme: ButtonThemeData(
      buttonColor: QuranColors.goldAccentColor,
      textTheme: ButtonTextTheme.primary,
    ),
    textTheme: TextTheme(
      headlineLarge: const TextStyle().copyWith(
        color: QuranColors.creamColor,
        fontSize: 32.0,
        fontWeight: FontWeight.bold,
      ),
      headlineMedium: const TextStyle().copyWith(
        fontSize: 24.0,
        fontWeight: FontWeight.w600,
      ),
      headlineSmall: const TextStyle().copyWith(
        fontSize: 18.0,

        fontWeight: FontWeight.w400,
      ),

      titleLarge: const TextStyle().copyWith(
        fontSize: 24.0,

        fontWeight: FontWeight.w600,
      ),
      titleMedium: const TextStyle().copyWith(
        fontSize: 16.0,

        fontWeight: FontWeight.w500,
      ),
      titleSmall: const TextStyle().copyWith(
        fontSize: 14.0,

        fontWeight: FontWeight.w400,
      ),

      bodyLarge: const TextStyle().copyWith(
        fontSize: 18.0,

        fontWeight: FontWeight.w700,
      ),
      bodyMedium: const TextStyle().copyWith(
        fontSize: 16.0,

        fontWeight: FontWeight.normal,
      ),
      bodySmall: const TextStyle().copyWith(
        fontSize: 14.0,

        fontWeight: FontWeight.w600,
      ),

      labelSmall: const TextStyle().copyWith(
        fontSize: 12.0,
        fontWeight: FontWeight.w400,
      ),
      labelLarge: const TextStyle().copyWith(
        fontSize: 12.0,
        fontWeight: FontWeight.w600,
      ),
      labelMedium: const TextStyle().copyWith(
        fontSize: 12.0,
        fontWeight: FontWeight.normal,
      ),

      displayLarge: const TextStyle(fontSize: 30, fontWeight: FontWeight.w400),
      displayMedium: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
    ), // BEGIN: Using TTextTheme
  );

  static ThemeData darkTheme = ThemeData(
    primaryColor: QuranColors.deepGreenColor,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: Colors.black,
    appBarTheme: AppBarTheme(
      iconTheme: IconThemeData(color: Colors.white),
      elevation: 0,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      centerTitle: false,
      scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: Colors.white,
      ),
      actionsIconTheme: IconThemeData(color: Colors.white, size: 20),
    ),
    buttonTheme: ButtonThemeData(
      buttonColor: QuranColors.goldAccentColor,
      textTheme: ButtonTextTheme.primary,
    ),
    textTheme: TextTheme(), // END: Using TTextTheme
  );
}
