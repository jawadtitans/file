import 'package:animate_do/animate_do.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:quran_app/core/constants/colors.dart';

import '../../../core/commons/onboarding/prayer_time_card.dart';
import '../../../core/commons/onboarding/progress_linear_widget.dart';
import '../../../core/commons/primary_button.dart';
import '../../../core/commons/ui_components/onboarding/onbaording_item_notification.dart';
import '../../../core/commons/ui_components/onboarding/onboarding_items_location.dart';
import '../../../generated/l10n.dart';
import '../../../providers/locationProvider.dart';
import '../../../providers/onboaring_riverpod.dart';
import '../../../providers/prayer_provider.dart';
import 'package:shimmer/shimmer.dart';

final pageIndexProvider = StateProvider<int>((ref) => 0);

class OnboardingPage extends ConsumerStatefulWidget {
  const OnboardingPage({super.key});

  @override
  ConsumerState<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends ConsumerState<OnboardingPage> {
  late final PageController _controller;
  final TextEditingController _nameController = TextEditingController();

  String? _selectedAge;
  String? _selectedVision;
  String? _selectedSource;
  final Set<String> _selectedGoals = <String>{};

  static const _ageOptions = [
    '13–17',
    '18–24',
    '25–34',
    '35–44',
    '45–54',
    '55+',
  ];

  static const _goalOptions = [
    ('🌅', "Start my day with Allah's words"),
    ('📖', 'Build a daily scripture habit'),
    ('🤍', 'Deepen my relationship with Allah'),
    ('🕊️', 'Find peace in difficult moments'),
    ('🧠', 'Memorize verses that matter'),
    ('🤝', 'Share my faith with others'),
  ];

  static const _visionOptions = [
    ('🙏', 'Unshakeable trust in Allah’s path'),
    ('✨', 'Faith that shines in my daily actions'),
    ('❤️', 'Loving others as Allah loves me'),
    ('⚓', 'Anchored deeply in the Truth'),
    ('💪', 'Staying strong through every storm'),
    ('🕊️', 'A constant sense of Allah’s presence'),
  ];

  static const _socialOptions = [
    ('google-play', 'Google Play'),
    ('facebook', 'Facebook'),
    ('telegram', 'Telegram'),
    ('youtub', 'YouTube'),
    ('insagram', 'Instagram'),
    ('chatgpt', 'ChatGPT'),
    ('linkdin', 'LinkedIn'),
  ];

  @override
  void initState() {
    super.initState();
    _controller = PageController(initialPage: 0);
    Future.microtask(() {
      ref.read(pageIndexProvider.notifier).state = 0;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _nextPage() async {
    if (!mounted) return;
    await _controller.nextPage(
      duration: const Duration(milliseconds: 200),
      curve: Curves.easeInOut,
    );
  }

  double? _progressFor(int index) {
    if (index <= 4) return null;
    const progressMap = {
      5: 0.14,
      6: 0.28,
      7: 0.42,
      8: 0.58,
      9: 0.74,
      10: 0.87,
      11: 1.0,
    };
    return progressMap[index] ?? 1.0;
  }

  String _buttonLabel(BuildContext context, int index) {
    final s = S.of(context)!;
    return switch (index) {
      2 => 'Continue',
      3 => 'Continue',
      5 => 'Continue',
      6 => 'Continue',
      7 => 'Continue',
      8 => 'Continue',
      9 => s.enable_location,
      10 => s.see_prayer_times,
      11 => s.enable_notifications_and_finish,
      _ => 'Continue',
    };
  }

  bool _isButtonEnabled(int index) {
    return switch (index) {
      2 => _nameController.text.trim().isNotEmpty,
      3 => _selectedAge != null,
      5 => _selectedSource != null,
      6 => _selectedGoals.isNotEmpty,
      7 => _selectedVision != null,
      _ => true,
    };
  }

  Future<void> _handleContinue(int index) async {
    final s = S.of(context)!;
    if (index == 2 && _nameController.text.trim().isNotEmpty) {
      await _nextPage();
      return;
    }
    if (index == 3 && _selectedAge != null) {
      await _nextPage();
      return;
    }
    if (index == 5 && _selectedSource != null) {
      await _nextPage();
      return;
    }
    if (index == 6 && _selectedGoals.isNotEmpty) {
      await _nextPage();
      return;
    }
    if (index == 7 && _selectedVision != null) {
      await _nextPage();
      return;
    }
    if (index == 8) {
      await _nextPage();
      return;
    }

    if (index == 9) {
      final loc = await ref
          .read(locationProvider.notifier)
          .getCurrentLocation();
      if (loc == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(s.location_permission_denied_message)),
          );
        }
        return;
      }

      await ref
          .read(userLocationCoordsProvider.notifier)
          .setCoords(loc.latitude, loc.longitude);
      await _nextPage();
      return;
    }

    if (index == 10) {
      await _nextPage();
      return;
    }

    if (index == 11) {
      final status = await Permission.notification.request();
      await ref
          .read(onboardingControllerProvider.notifier)
          .completeOnboarding();
      if (status.isPermanentlyDenied) {
        await openAppSettings();
      }
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final index = ref.watch(pageIndexProvider);
    final progress = _progressFor(index);
    final canContinue = _isButtonEnabled(index);
    final enteredName = _nameController.text.trim().isEmpty
        ? 'friend'
        : _nameController.text.trim();

    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              QuranColors.deepGreenColor,
              QuranColors.cardColors,
              QuranColors.prayer_cardColor,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              if (progress != null)
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 30, 22, 8),
                  child: AnimatedShimmerProgress(value: progress),
                )
              else
                const SizedBox(height: 16),
              Expanded(
                child: PageView(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: _controller,
                  onPageChanged: (value) =>
                      ref.read(pageIndexProvider.notifier).state = value,
                  children: [
                    const _WelcomePage(),
                    _StoryTextPage(
                      title:
                          'Ever feel like you unlock\nyour phone 100 times a\nday...\nbut barely open your\nQuran once?',
                      highlightedWords: const ['100 times a\nday...', 'Quran'],
                      body:
                          'You’re not alone. Distractions are everywhere, and it’s easy to lose sight of what truly matters.\n\nWhat if every time you checked your phone, Allah’s words were right there waiting?',
                      onTap: _nextPage,
                    ),
                    _NamePage(
                      controller: _nameController,
                      onChanged: (_) => setState(() {}),
                    ),
                    _AgePage(
                      name: enteredName,
                      selectedAge: _selectedAge,
                      ages: _ageOptions,
                      onSelect: (value) => setState(() => _selectedAge = value),
                    ),
                    _AnimatedStoryPage(onTap: _nextPage),
                    _SocialSourcePage(
                      selectedSource: _selectedSource,
                      onSelect: (value) =>
                          setState(() => _selectedSource = value),
                    ),
                    _GoalsPage(
                      selectedGoals: _selectedGoals,
                      onToggle: (goal) {
                        setState(() {
                          if (_selectedGoals.contains(goal)) {
                            _selectedGoals.remove(goal);
                          } else {
                            _selectedGoals.add(goal);
                          }
                        });
                      },
                    ),
                    _VisionPage(
                      selectedVision: _selectedVision,
                      onSelect: (vision) =>
                          setState(() => _selectedVision = vision),
                    ),
                    _SummaryPage(
                      name: enteredName,
                      selectedVision:
                          _selectedVision ?? _visionOptions.first.$2,
                      selectedGoals: _selectedGoals.toList(),
                    ),
                    OnboardingPageItem(
                      title: S.of(context)!.location_required,
                      child: Consumer(
                        builder: (context, ref, _) {
                          final locationState = ref.watch(locationProvider);
                          final isSuccess = locationState.value != null;

                          return Container(
                            width: 300,
                            height: 300,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: QuranColors.cardColors,
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                if (locationState.isLoading)
                                  const CupertinoActivityIndicator(
                                    radius: 40,
                                    color: QuranColors.creamColor,
                                  )
                                else if (isSuccess)
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(
                                        Icons.check_circle,
                                        size: 100,
                                        color: QuranColors.greenPrimary,
                                      ),
                                      const SizedBox(height: 12),
                                      Text(
                                        S.of(context)!.location_success,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: QuranColors.creamColor,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  )
                                else
                                  const Icon(
                                    Icons.location_on,
                                    size: 100,
                                    color: QuranColors.greenPrimary,
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    OnboardingPageItem(
                      title: S.of(context)!.see_prayer_times,
                      child: const Align(
                        alignment: Alignment.topCenter,
                        child: PrayerTimesOnboardingWidget(),
                      ),
                    ),
                    OnboardingPageItem(
                      title: S.of(context)!.notification_desc,
                      child: const NotificationAdhan(),
                    ),
                  ],
                ),
              ),
              if (index == 0 || index == 1 || index == 4)
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: index == 0
                        ? FadeIn(
                            duration: const Duration(seconds: 2),
                            delay: const Duration(milliseconds: 4700),
                            child: GestureDetector(
                              onTap: _nextPage,
                              child: Shimmer.fromColors(
                                baseColor: Colors.white38,
                                highlightColor: Colors.white,
                                period: const Duration(milliseconds: 3000),
                                child: const Text(
                                  'Tap to continue →',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                          )
                        : GestureDetector(
                            onTap: _nextPage,
                            child: const Text(
                              'Tap to continue  →',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 28,
                  ),
                  child: Opacity(
                    opacity: canContinue ? 1 : 0.55,
                    child: IgnorePointer(
                      ignoring: !canContinue,
                      child: PrimaryButton(
                        borderRadius: BorderRadius.circular(30),
                        color: const Color(0xFFD2C2A6),
                        textStyle: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w700,
                        ),
                        text: _buttonLabel(context, index),
                        onPressed: () => _handleContinue(index),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _WelcomePage extends StatelessWidget {
  const _WelcomePage();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 28),
        child: Column(
          children: [
            const Spacer(),
            FadeIn(
              duration: const Duration(seconds: 6),
              delay: const Duration(milliseconds: 1000),
              child: const Text(
                'Hey!👋',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: "new_time",
                  fontSize: 50,
                  fontWeight: FontWeight.w700,
                  color: QuranColors.creamColor,
                ),
              ),
            ),
            const SizedBox(height: 6),
            FadeIn(
              duration: const Duration(seconds: 3),
              delay: const Duration(milliseconds: 3000),
              child: const Text(
                'Welcome to Hedaya!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: QuranColors.creamColor,
                ),
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}

class _StoryTextPage extends StatelessWidget {
  const _StoryTextPage({
    required this.title,
    required this.highlightedWords,
    required this.body,
    required this.onTap,
  });

  final String title;
  final List<String> highlightedWords;
  final String body;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final spans = <TextSpan>[];
    var remaining = title;

    while (remaining.isNotEmpty) {
      int? bestIndex;
      String? bestMatch;
      for (final word in highlightedWords) {
        final idx = remaining.indexOf(word);
        if (idx != -1 && (bestIndex == null || idx < bestIndex)) {
          bestIndex = idx;
          bestMatch = word;
        }
      }
      if (bestIndex == null || bestMatch == null) {
        spans.add(TextSpan(text: remaining));
        break;
      }
      if (bestIndex > 0) {
        spans.add(TextSpan(text: remaining.substring(0, bestIndex)));
      }
      spans.add(
        TextSpan(
          text: bestMatch,
          style: const TextStyle(color: Color(0xFFD2A45D)),
        ),
      );
      remaining = remaining.substring(bestIndex + bestMatch.length);
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Spacer(),
            FadeIn(
              duration: const Duration(seconds: 3),
              delay: const Duration(milliseconds: 700),
              child: Text.rich(
                TextSpan(
                  style: const TextStyle(
                    fontFamily: "new_time",
                    fontSize: 32,
                    height: 1.22,
                    fontWeight: FontWeight.w900,
                    color: QuranColors.creamColor,
                  ),
                  children: spans,
                ),
              ),
            ),
            const SizedBox(height: 28),
            FadeIn(
              duration: const Duration(seconds: 3),
              delay: const Duration(milliseconds: 1500),
              child: Text(
                body,
                style: TextStyle(
                  height: 1.65,
                  fontSize: 16,
                  color: Colors.white.withOpacity(0.65),
                ),
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}

class _NamePage extends StatelessWidget {
  const _NamePage({required this.controller, required this.onChanged});

  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 30, 22, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'First things first',
            style: TextStyle(
              color: Colors.white.withOpacity(0.55),
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Who are we praying\nwith?',
            style: TextStyle(
              fontFamily: "new_time",
              color: QuranColors.creamColor,
              fontSize: 32,
              height: 1.05,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 30),
          Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(58),
              border: Border.all(color: Colors.white.withOpacity(0.06)),
            ),
            child: TextField(
              cursorWidth: 1.3,
              cursorHeight: 21,
              cursorOpacityAnimates: true,
              controller: controller,
              onChanged: onChanged,
              style: const TextStyle(
                color: QuranColors.creamColor,
                fontSize: 18,
              ),
              cursorColor: QuranColors.greenPrimary,
              decoration: InputDecoration(
                hintText: 'Enter your full name',
                hintStyle: TextStyle(
                  color: Colors.white.withOpacity(0.28),
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 18,
                ),
                border: InputBorder.none,
              ),
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}

class _AgePage extends StatelessWidget {
  const _AgePage({
    required this.name,
    required this.selectedAge,
    required this.ages,
    required this.onSelect,
  });
  final String? name;
  final String? selectedAge;
  final List<String> ages;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'How old is $name?',
            style: const TextStyle(
              fontFamily: "new_time",
              color: QuranColors.creamColor,
              fontSize: 32,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 18),
          ...ages.map(
            (age) => Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: _ChoiceTile(
                title: age,
                selected: selectedAge == age,
                onTap: () => onSelect(age),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AnimatedStoryPage extends StatelessWidget {
  const _AnimatedStoryPage({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Spacer(),
            FadeIn(
              duration: const Duration(seconds: 4),
              delay: const Duration(milliseconds: 900),
              child: const Text.rich(
                TextSpan(
                  style: TextStyle(
                    fontFamily: "new_time",
                    fontSize: 34,
                    height: 1.2,
                    fontWeight: FontWeight.w900,
                    color: QuranColors.creamColor,
                  ),
                  children: [
                    TextSpan(text: 'Imagine if even '),
                    TextSpan(
                      text: '5\nminutes',
                      style: TextStyle(color: Color(0xFFD2A45D)),
                    ),
                    TextSpan(text: '\nbrought you closer to\n'),
                    TextSpan(
                      text: 'Allah...',
                      style: TextStyle(color: Color(0xFFD2A45D)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 26),
            FadeIn(
              duration: const Duration(seconds: 3),
              delay: const Duration(milliseconds: 4000),
              child: Text(
                'Let’s build that habit together.',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Colors.white.withOpacity(0.62),
                ),
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}

class _SocialSourcePage extends StatelessWidget {
  const _SocialSourcePage({
    required this.selectedSource,
    required this.onSelect,
  });

  final String? selectedSource;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 30, 22, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          const Text(
            'Where did you hear\nabout Safaryar?',
            style: TextStyle(
              fontFamily: "new_time",
              color: QuranColors.creamColor,
              fontSize: 32,
              height: 1.08,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: ListView.separated(
              padding: EdgeInsets.zero,
              itemCount: _OnboardingPageState._socialOptions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = _OnboardingPageState._socialOptions[index];
                final selected = selectedSource == item.$2;
                return _SocialOptionTile(
                  assetName: item.$1,
                  title: item.$2,
                  selected: selected,
                  onTap: () => onSelect(item.$2),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _GoalsPage extends StatelessWidget {
  const _GoalsPage({required this.selectedGoals, required this.onToggle});

  final Set<String> selectedGoals;
  final ValueChanged<String> onToggle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 20, 22, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text.rich(
            TextSpan(
              style: TextStyle(
                color: QuranColors.creamColor,
                fontSize: 30,
                height: 1.1,
                fontWeight: FontWeight.w700,
              ),
              children: [
                TextSpan(
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontFamily: "new_time",
                  ),
                  text: 'What do you want to\nachieve with the ',
                ),
                TextSpan(
                  text: 'Hedaya widget ',
                  style: TextStyle(
                    fontFamily: "new_time",
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFD2A45D),
                  ),
                ),
                TextSpan(text: '?'),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: ListView.separated(
              padding: EdgeInsets.zero,
              itemCount: _OnboardingPageState._goalOptions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = _OnboardingPageState._goalOptions[index];
                final selected = selectedGoals.contains(item.$2);
                return _OptionCard(
                  emoji: item.$1,
                  title: item.$2,
                  selected: selected,
                  onTap: () => onToggle(item.$2),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _VisionPage extends StatelessWidget {
  const _VisionPage({required this.selectedVision, required this.onSelect});

  final String? selectedVision;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 20, 22, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text.rich(
            TextSpan(
              style: TextStyle(
                color: QuranColors.creamColor,
                fontSize: 30,
                height: 1.1,
                fontWeight: FontWeight.w700,
              ),
              children: [
                TextSpan(
                  style: TextStyle(
                    fontFamily: "new_time",
                    fontWeight: FontWeight.w900,
                  ),
                  text: 'When you imagine your\nwalk with Allah ',
                ),
                TextSpan(
                  text: 'flourishing',
                  style: TextStyle(
                    fontFamily: "new_time",
                    fontWeight: FontWeight.w900,
                    color: Color(0xFFD2A45D),
                  ),
                ),
                TextSpan(
                  text: ', what do\nyou see?',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontFamily: "new_time",
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: ListView.separated(
              padding: EdgeInsets.zero,
              itemCount: _OnboardingPageState._visionOptions.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final item = _OnboardingPageState._visionOptions[index];
                return _OptionCard(
                  emoji: item.$1,
                  title: item.$2,
                  selected: selectedVision == item.$2,
                  onTap: () => onSelect(item.$2),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryPage extends StatelessWidget {
  const _SummaryPage({
    required this.name,
    required this.selectedGoals,
    required this.selectedVision,
  });

  final String name;
  final List<String> selectedGoals;
  final String selectedVision;

  @override
  Widget build(BuildContext context) {
    final visibleGoals = selectedGoals.take(2).toList();
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ...List.generate(visibleGoals.length, (index) {
            final goal = visibleGoals[index];
            final item = _OnboardingPageState._goalOptions.firstWhere(
              (e) => e.$2 == goal,
            );
            return FadeInUp(
              duration: const Duration(milliseconds: 550),
              delay: Duration(milliseconds: 140 * index),
              child: Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: _InsightCard(
                  emoji: item.$1,
                  title: item.$2,
                  description: index == 0
                      ? 'We’ll gently place meaningful reminders throughout your day so your worship stays close.'
                      : 'You’ll build small, steady momentum with scripture and prayer prompts that fit your routine.',
                ),
              ),
            );
          }),
          FadeInUp(
            duration: const Duration(milliseconds: 550),
            delay: const Duration(milliseconds: 350),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: const Color(0xFFD2A45D), width: 1.4),
                color: Colors.white.withOpacity(0.03),
              ),
              child: Column(
                children: [
                  Text(
                    'WHERE YOU\'RE HEADED',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.55),
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.1,
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    selectedVision,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: QuranColors.creamColor,
                    ),
                  ),
                  const SizedBox(height: 7),
                  const Text(
                    'Thousands of believers use Hedaya to stay steady with prayer, Quran, and daily remembrance.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      height: 1.2,
                      fontSize: 15,
                      color: Color(0xFFD2A45D),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 30),
          FadeInUp(
            duration: const Duration(milliseconds: 600),
            delay: const Duration(milliseconds: 500),
            child: Text(
              'You’re in the right place, $name jan!',
              style: const TextStyle(
                fontFamily: "new_time",
                color: Color(0xFFD2A45D),
                fontSize: 30,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 12),
          FadeInUp(
            duration: const Duration(milliseconds: 600),
            delay: const Duration(milliseconds: 650),
            child: Text(
              'We’ll now tailor the rest of your setup for prayer times, reminders, and a peaceful daily Islamic experience.',
              style: TextStyle(
                height: 1.55,
                fontSize: 16,
                color: Colors.white.withOpacity(0.68),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChoiceTile extends StatelessWidget {
  const _ChoiceTile({
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: selected
                ? const Color(0xFFD2A45D)
                : Colors.white.withOpacity(0.06),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  fontFamily: "new_time",
                  color: QuranColors.creamColor,
                  fontSize: 17,
                ),
              ),
            ),
            _CircleSelection(selected: selected),
          ],
        ),
      ),
    );
  }
}

class _OptionCard extends StatelessWidget {
  const _OptionCard({
    required this.emoji,
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String emoji;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(56),
          border: Border.all(
            color: selected
                ? const Color(0xFFD2A45D)
                : Colors.white.withOpacity(0.06),
            width: 1.2,
          ),
        ),
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 24)),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: QuranColors.creamColor,
                  fontSize: 16,
                  height: 1.25,
                ),
              ),
            ),
            _CircleSelection(selected: selected, squared: true),
          ],
        ),
      ),
    );
  }
}

class _SocialOptionTile extends StatelessWidget {
  const _SocialOptionTile({
    required this.assetName,
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String assetName;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
        decoration: BoxDecoration(
          color: selected
              ? QuranColors.greenPrimary
              : Colors.white.withOpacity(0.04),
          borderRadius: BorderRadius.circular(58),
          border: Border.all(
            color: selected
                ? QuranColors.greenPrimary
                : const Color(0xFF3A2D21).withOpacity(0.65),
            width: 1.2,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: const BoxDecoration(
                color: Color(0xFFE7E7E7),
                shape: BoxShape.circle,
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Image.asset(
                  width: 40,
                  height: 40,
                  'assets/webp/$assetName.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Icon(
                    Icons.public,
                    color: selected ? Colors.black : Colors.black54,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  color: selected ? Colors.black : QuranColors.creamColor,
                  fontSize: 17,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CircleSelection extends StatelessWidget {
  const _CircleSelection({required this.selected, this.squared = false});

  final bool selected;
  final bool squared;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      width: 24,
      height: 24,
      decoration: BoxDecoration(
        shape: squared ? BoxShape.rectangle : BoxShape.circle,
        borderRadius: squared ? BorderRadius.circular(7) : null,
        color: selected
            ? const Color(0xFFD2A45D).withOpacity(0.16)
            : Colors.transparent,
        border: Border.all(
          color: selected
              ? const Color(0xFFD2A45D)
              : Colors.white.withOpacity(0.12),
          width: 1.2,
        ),
      ),
      child: selected
          ? const Icon(Icons.check, size: 14, color: Color(0xFFD2A45D))
          : null,
    );
  }
}

class _InsightCard extends StatelessWidget {
  const _InsightCard({
    required this.emoji,
    required this.title,
    required this.description,
  });

  final String emoji;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: QuranColors.creamColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            description,
            style: TextStyle(
              height: 1.45,
              fontSize: 15,
              color: Colors.white.withOpacity(0.64),
            ),
          ),
        ],
      ),
    );
  }
}
