import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:animate_do/animate_do.dart';
import 'package:flutter_riverpod/legacy.dart';

import '../../../core/commons/primary_button.dart';
import '../../../core/commons/ui_components/onboarding/goal_button_welcome_page.dart';
import '../../../core/constants/colors.dart';
import '../../../generated/l10n.dart';
import '../../../routes/app_route.dart';

final selectedGoalProvider = StateProvider<int>((ref) => 0);

class WelcomePage extends ConsumerWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(selectedGoalProvider);
    final s = S.of(context)!;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Full screen background image
          Image.asset('assets/webp/bg_intro.jpg', fit: BoxFit.cover),

          // Dark overlay so text is readable
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x66000000),
                  Color(0x33000000),
                  Color(0xB3000000),
                ],
                stops: [0.0, 0.45, 1.0],
              ),
            ),
          ),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 80),

                  FadeInUp(
                    duration: const Duration(milliseconds: 600),
                    child: Text(
                      s.welcome_title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: QuranColors.creamColor,
                        height: 1.3,
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),
                  const Spacer(),

                  FadeInUp(
                    duration: const Duration(milliseconds: 700),
                    delay: const Duration(milliseconds: 400),
                    child: Text(
                      s.welcome_goal_question,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 16,
                        color: QuranColors.creamColor,
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  FadeInUp(
                    duration: const Duration(milliseconds: 700),
                    delay: const Duration(milliseconds: 500),
                    child: GoalButton(
                      title: s.welcome_goal_pray_consistently,
                      icon: Icons.mosque,
                      selected: selected == 0,
                      onTap: () =>
                          ref.read(selectedGoalProvider.notifier).state = 0,
                    ),
                  ),

                  const SizedBox(height: 16),

                  FadeInUp(
                    duration: const Duration(milliseconds: 700),
                    delay: const Duration(milliseconds: 600),
                    child: GoalButton(
                      title: s.welcome_goal_read_more_quran,
                      icon: Icons.menu_book,
                      selected: selected == 1,
                      onTap: () =>
                          ref.read(selectedGoalProvider.notifier).state = 1,
                    ),
                  ),

                  FadeInUp(
                    duration: const Duration(milliseconds: 700),
                    delay: const Duration(milliseconds: 700),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Text(
                        s.welcome_description,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                          color: QuranColors.creamColor.withOpacity(0.88),
                          height: 1.5,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  FadeInUp(
                    duration: const Duration(milliseconds: 700),
                    delay: const Duration(milliseconds: 800),
                    child: PrimaryButton(
                      borderRadius: BorderRadius.circular(30),
                      color: QuranColors.greenPrimary,
                      textStyle: const TextStyle(
                        fontSize: 14,
                        color: QuranColors.creamColor,
                      ),
                      text: s.welcome_start_button,
                      onPressed: () {
                        Navigator.pushNamed(context, AppRoutes.onboarding);
                      },
                    ),
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
