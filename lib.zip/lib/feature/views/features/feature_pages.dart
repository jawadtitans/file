import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';
import '../../../generated/l10n.dart';

// ── Tasbih Page ────────────────────────────────────────────────────────────

class TasbihPage extends StatefulWidget {
  const TasbihPage({super.key});

  @override
  State<TasbihPage> createState() => _TasbihPageState();
}

class _TasbihPageState extends State<TasbihPage> {
  int _count = 0;
  int _total = 0;
  int _limit = 33;
  String _selectedZikr = 'subhanallah';

  static const List<Map<String, String>> _zikrList = [
    {
      'id': 'subhanallah',
      'arabic': 'سُبْحَانَ ٱللَّٰهِ',
      'fa': 'سبحان الله',
      'count': '33',
    },
    {
      'id': 'alhamdulillah',
      'arabic': 'ٱلْحَمْدُ لِلَّٰهِ',
      'fa': 'الحمد لله',
      'count': '33',
    },
    {
      'id': 'allahuakbar',
      'arabic': 'ٱللَّٰهُ أَكْبَرُ',
      'fa': 'الله اکبر',
      'count': '34',
    },
    {
      'id': 'lailahaillallah',
      'arabic': 'لَا إِلَٰهَ إِلَّا ٱللَّٰهُ',
      'fa': 'لا اله الا الله',
      'count': '100',
    },
    {
      'id': 'astaghfirullah',
      'arabic': 'ٱسْتَغْفِرُ ٱللَّٰهَ',
      'fa': 'استغفر الله',
      'count': '100',
    },
  ];

  void _tap() {
    setState(() {
      _count++;
      _total++;
      if (_count >= _limit) _count = 0;
    });
  }

  void _reset() {
    setState(() {
      _count = 0;
      _total = 0;
    });
  }

  void _selectZikr(Map<String, String> z) {
    setState(() {
      _selectedZikr = z['id']!;
      _count = 0;
      _limit = int.tryParse(z['count'] ?? '33') ?? 33;
    });
  }

  @override
  void initState() {
    super.initState();
    final first = _zikrList.first;
    _selectedZikr = first['id']!;
    _limit = int.tryParse(first['count'] ?? '33') ?? 33;
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final progress = _count / _limit;
    final selected = _zikrList.firstWhere((z) => z['id'] == _selectedZikr);

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new,
                        color: QuranColors.creamColor,
                        size: 18,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    s.tasbih_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: _reset,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.refresh,
                        color: QuranColors.greenPrimary,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 44,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _zikrList.length,
                itemBuilder: (context, i) {
                  final z = _zikrList[i];
                  final isSel = _selectedZikr == z['id'];

                  return GestureDetector(
                    onTap: () => _selectZikr(z),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: isSel
                            ? QuranColors.greenPrimary
                            : QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        z['fa']!,
                        style: TextStyle(
                          color: isSel ? Colors.white : Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 30),
            Text(
              selected['arabic']!,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: const TextStyle(
                color: QuranColors.creamColor,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 40),
            GestureDetector(
              onTap: _tap,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 220,
                    height: 220,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 12,
                      backgroundColor: QuranColors.cardColors,
                      valueColor: const AlwaysStoppedAnimation(
                        QuranColors.greenPrimary,
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Text(
                        '$_count',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 72,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '/ $_limit',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Text(
              s.tasbih_total(_total),
              style: TextStyle(
                color: Colors.white.withOpacity(0.6),
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              s.tasbih_tap_hint,
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Qibla Page ─────────────────────────────────────────────────────────────

class QiblaPage extends ConsumerWidget {
  const QiblaPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          child: Column(
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new,
                        color: QuranColors.creamColor,
                        size: 18,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    s.qibla_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
              const Expanded(child: SizedBox()),
              Center(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 32,
                  ),
                  decoration: BoxDecoration(
                    color: QuranColors.cardColors,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 82,
                        height: 82,
                        decoration: BoxDecoration(
                          color: QuranColors.greenPrimary.withOpacity(0.12),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.explore,
                          size: 40,
                          color: QuranColors.greenPrimary,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        s.qibla_title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        s.qibla_coming_desc,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                          height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: QuranColors.greenPrimary.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(
                          s.coming_soon,
                          style: const TextStyle(
                            color: QuranColors.greenPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const Expanded(child: SizedBox()),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Duas Page ──────────────────────────────────────────────────────────────

class DuasPage extends StatelessWidget {
  const DuasPage({super.key});

  List<Map<String, String>> _duas(S s) => [
    {
      'title': s.dua_title_morning,
      'arabic': 'اللهم انت ربي لا اله الا انت...',
      'category': s.dua_category_morning,
    },
    {
      'title': s.dua_title_before_sleep,
      'arabic': 'باسمک اللهم احیا و اموت',
      'category': s.dua_category_night,
    },
    {
      'title': s.dua_title_after_prayer,
      'arabic': 'سبحان الله والحمد لله والله اکبر',
      'category': s.dua_category_prayer,
    },
    {
      'title': s.dua_title_istighfar,
      'arabic': 'اللهم انت ربي استغفرک و اتوب الیک',
      'category': s.dua_category_istighfar,
    },
    {
      'title': s.dua_title_parents,
      'arabic': 'ربی ارحمهما کما ربیانی صغیرا',
      'category': s.dua_category_family,
    },
    {
      'title': s.dua_title_trust,
      'arabic': 'حسبنا الله و نعم الوکیل',
      'category': s.dua_category_trust,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final duas = _duas(s);

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new,
                        color: QuranColors.creamColor,
                        size: 18,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    s.duas_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: duas.length,
                itemBuilder: (context, i) {
                  final dua = duas[i];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: QuranColors.cardColors,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.04)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: QuranColors.greenPrimary.withOpacity(
                                  0.20,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                dua['category']!,
                                style: const TextStyle(
                                  color: QuranColors.greenPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Text(
                                dua['title']!,
                                textAlign: TextAlign.right,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          dua['arabic']!,
                          textAlign: TextAlign.right,
                          textDirection: TextDirection.rtl,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.75),
                            fontSize: 14,
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Khatam Page ────────────────────────────────────────────────────────────

class KhatamPage extends StatefulWidget {
  const KhatamPage({super.key});

  @override
  State<KhatamPage> createState() => _KhatamPageState();
}

class _KhatamPageState extends State<KhatamPage> {
  int _completedJuz = 7;
  final int _totalJuz = 30;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final progress = _completedJuz / _totalJuz;
    final percent = (progress * 100).round();

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new,
                        color: QuranColors.creamColor,
                        size: 18,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    s.khatam_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
            ),
            const SizedBox(height: 30),
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 180,
                  height: 180,
                  child: CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 14,
                    backgroundColor: QuranColors.cardColors,
                    valueColor: const AlwaysStoppedAnimation(
                      QuranColors.greenPrimary,
                    ),
                  ),
                ),
                Column(
                  children: [
                    Text(
                      '$_completedJuz/$_totalJuz',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      s.juz,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.6),
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              s.khatam_completed_percent(percent),
              style: const TextStyle(
                color: QuranColors.greenPrimary,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 30),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 6,
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  childAspectRatio: 1,
                ),
                itemCount: _totalJuz,
                itemBuilder: (context, i) {
                  final isDone = i < _completedJuz;

                  return GestureDetector(
                    onTap: () => setState(() => _completedJuz = i + 1),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      decoration: BoxDecoration(
                        color: isDone
                            ? QuranColors.greenPrimary
                            : QuranColors.cardColors,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isDone
                              ? QuranColors.greenPrimary
                              : Colors.white.withOpacity(0.05),
                        ),
                      ),
                      child: Center(
                        child: Text(
                          '${i + 1}',
                          style: TextStyle(
                            color: isDone ? Colors.white : Colors.white60,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
