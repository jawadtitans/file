import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';

import '../../../../providers/bookmark_provider.dart';

import '../../../../feature/views/reader/reader.dart';
import '../../../core/commons/ui_components/bookmark/tabs.dart';
import '../../../core/commons/ui_components/home/listitems.dart';
import '../../../generated/l10n.dart';
import '../../../providers/home_provider.dart';

class BookmarkPage extends ConsumerWidget {
  const BookmarkPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final surahs = ref.watch(surahProvider);
    final juz = ref.watch(juzProvider);
    final bookmarkedSurahs = ref.watch(bookmarkedSurahsProvider);
    final bookmarkedJuz = ref.watch(bookmarkedJuzProvider);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(S.of(context)!.bookmar_title),
          centerTitle: true,
          bottom: _tabBar(),
        ),
        body: TabBarView(
          children: [
            surahs.when(
              data: (list) =>
                  SurahTab(surahs: list, bookmarked: bookmarkedSurahs),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (_, __) => const Center(
                child: Text(
                  'Error loading data',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            juz.when(
              data: (list) => JuzTab(juz: list, bookmarked: bookmarkedJuz),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (_, __) => const Center(child: Text('Error loading data')),
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _tabBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(46),
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        height: 38,
        width: 220,
        decoration: BoxDecoration(
          color: QuranColors.cardColors,
          borderRadius: BorderRadius.circular(20),
        ),
        child: TabBar(
          dividerColor: Colors.transparent,
          labelColor: QuranColors.creamColor,
          labelStyle: TextStyle(fontWeight: FontWeight.w600),
          padding: EdgeInsetsGeometry.symmetric(horizontal: 4, vertical: 4),
          indicatorSize: TabBarIndicatorSize.tab,
          unselectedLabelColor: QuranColors.creamColor,
          indicator: BoxDecoration(
            color: QuranColors.greenPrimary,
            borderRadius: BorderRadius.circular(20),
          ),
          tabs: [
            Tab(text: S.current.tab_surah),
            Tab(text: S.current.tab_juz),
          ],
        ),
      ),
    );
  }
}

// =============================
// SURAH TAB WIDGET
// =============================

// =============================
// JUZ TAB WIDGET
// =============================
