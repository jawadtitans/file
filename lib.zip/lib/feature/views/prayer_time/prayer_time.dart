import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/providers/prayer_provider.dart';
import 'package:quran_app/services/prayer_times_service.dart';
import '../../../generated/l10n.dart';

class PrayerTime extends ConsumerStatefulWidget {
  const PrayerTime({super.key});

  @override
  ConsumerState<PrayerTime> createState() => _PrayerTimeState();
}

class _PrayerTimeState extends ConsumerState<PrayerTime> {
  late DateTime _selectedDate;
  bool _useHijri = false;
  Timer? _ticker;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _selectedDate = _strip(DateTime.now());
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() => _now = DateTime.now());
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  DateTime _strip(DateTime d) => DateTime(d.year, d.month, d.day);

  String _fmt(DateTime dt) {
    final h = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m ${dt.hour >= 12 ? "PM" : "AM"}';
  }

  // ── Gregorian / Miladi helpers ──────────────────────────────────────────

  List<String> _gregorianMonths(S s) => [
    s.month_january,
    s.month_february,
    s.month_march,
    s.month_april,
    s.month_may,
    s.month_june,
    s.month_july,
    s.month_august,
    s.month_september,
    s.month_october,
    s.month_november,
    s.month_december,
  ];

  String _gregorianHeader(DateTime dt, S s) {
    final months = _gregorianMonths(s);
    return '${months[dt.month - 1]} ${dt.year}';
  }

  String _gregorianDateStr(DateTime dt, S s) {
    final months = _gregorianMonths(s);
    return '${dt.day} ${months[dt.month - 1]} ${dt.year}';
  }

  // ── Hijri helpers ──────────────────────────────────────────────────────

  List<String> _hijriMonths(S s) => [
    s.hijri_muharram,
    s.hijri_safar,
    s.hijri_rabi_al_awwal,
    s.hijri_rabi_al_thani,
    s.hijri_jumada_al_awwal,
    s.hijri_jumada_al_thani,
    s.hijri_rajab,
    s.hijri_shaban,
    s.hijri_ramadan,
    s.hijri_shawwal,
    s.hijri_dhul_qadah,
    s.hijri_dhul_hijjah,
  ];

  String _hijriHeader(DateTime dt, S s) {
    final h = HijriCalendar.fromDate(dt);
    final months = _hijriMonths(s);
    return '${months[h.hMonth - 1]} ${h.hYear}';
  }

  String _hijriDateStr(DateTime dt, S s) {
    final h = HijriCalendar.fromDate(dt);
    final months = _hijriMonths(s);
    return '${h.hDay} ${months[h.hMonth - 1]} ${h.hYear}';
  }

  int _hijriDay(DateTime dt) => HijriCalendar.fromDate(dt).hDay;

  String _remaining(DateTime t, S s) {
    final d = t.difference(_now);
    if (d.isNegative) return '';
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final sec = d.inSeconds % 60;
    if (h > 0) return s.time_hours_minutes(h, m);
    return s.time_minutes_seconds(m, sec);
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final madhab = ref.watch(selectedMadhabProvider);
    final coords = ref.watch(userLocationCoordsProvider);
    final prayed = ref.watch(prayedPrayersProvider);
    final today = _strip(DateTime.now());
    final isToday = _selectedDate == today;
    final times = prayerTimesForDate(coords, madhab, _selectedDate);

    final pl = [
      (s.prayer_fajr_local, 'Fajr', '✦', times.fajr),
      (s.prayer_dhuhr_local, 'Dhuhr', '☀️', times.dhuhr),
      (s.prayer_asr_local, 'Asr', '⛅', times.asr),
      (s.prayer_maghrib_local, 'Maghrib', '🌆', times.maghrib),
      (s.prayer_isha_local, "Isha'a", '🌙', times.isha),
    ];

    int active = -1;
    int next = -1;

    if (isToday) {
      for (int i = 0; i < pl.length; i++) {
        if (_now.isAfter(pl[i].$4)) active = i;
      }
      if (active >= 0 && active + 1 < pl.length) next = active + 1;
      if (active == -1 && _now.isBefore(pl[0].$4)) next = 0;
    }

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
              child: Row(
                children: [
                  Text(
                    s.prayer_times_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  const SizedBox(width: 40),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                child: Column(
                  children: [
                    _CalendarCard(
                      selectedDate: _selectedDate,
                      useHijri: _useHijri,
                      now: _now,
                      onToggle: (v) => setState(() => _useHijri = v),
                      onDateChange: (d) =>
                          setState(() => _selectedDate = _strip(d)),
                      gregorianHeader: (d) => _gregorianHeader(d, s),
                      gregorianDateStr: (d) => _gregorianDateStr(d, s),
                      hijriHeader: (d) => _hijriHeader(d, s),
                      hijriDateStr: (d) => _hijriDateStr(d, s),
                      hijriDay: _hijriDay,
                    ),
                    const SizedBox(height: 14),
                    if (isToday) ...[
                      Row(
                        children: [
                          Expanded(
                            child: _NowNextCard(
                              pl: pl,
                              active: active,
                              next: next,
                              rem: next >= 0 ? _remaining(pl[next].$4, s) : '',
                              fmt: _fmt,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: _PrayedCard(prayed: prayed)),
                        ],
                      ),
                      const SizedBox(height: 14),
                    ],
                    const SizedBox(height: 14),
                    ...List.generate(pl.length, (i) {
                      final p = pl[i];
                      final done = prayed.contains(p.$2);
                      final isActive = isToday && i == active;
                      final isNext = isToday && i == next;
                      final canCheck = isToday && i <= active;

                      return _PrayerRow(
                        nameDari: p.$1,
                        nameEn: p.$2,
                        icon: p.$3,
                        time: _fmt(p.$4),
                        isActive: isActive,
                        isNext: isNext,
                        isDone: done,
                        canCheck: canCheck,
                        remainStr: isNext ? _remaining(p.$4, s) : '',
                        onToggle: canCheck
                            ? () => ref
                                  .read(prayedPrayersProvider.notifier)
                                  .toggle(p.$2)
                            : null,
                      );
                    }),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CalendarCard extends StatelessWidget {
  final DateTime selectedDate, now;
  final bool useHijri;
  final ValueChanged<bool> onToggle;
  final ValueChanged<DateTime> onDateChange;
  final String Function(DateTime) gregorianHeader,
      gregorianDateStr,
      hijriHeader,
      hijriDateStr;
  final int Function(DateTime) hijriDay;

  const _CalendarCard({
    required this.selectedDate,
    required this.now,
    required this.useHijri,
    required this.onToggle,
    required this.onDateChange,
    required this.gregorianHeader,
    required this.gregorianDateStr,
    required this.hijriHeader,
    required this.hijriDateStr,
    required this.hijriDay,
  });

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final m = selectedDate;
    final days = DateUtils.getDaysInMonth(m.year, m.month);
    final firstWd = DateTime(m.year, m.month, 1).weekday % 7;

    final header = useHijri
        ? hijriHeader(selectedDate)
        : gregorianHeader(selectedDate);
    final sub = useHijri
        ? hijriDateStr(selectedDate)
        : gregorianDateStr(selectedDate);

    final weekHeaders = [
      s.weekday_short_sat,
      s.weekday_short_sun,
      s.weekday_short_mon,
      s.weekday_short_tue,
      s.weekday_short_wed,
      s.weekday_short_thu,
      s.weekday_short_fri,
    ];

    return Container(
      decoration: BoxDecoration(
        color: QuranColors.cardColors,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: QuranColors.deepGreenColor,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Row(
              children: [
                _Tab(
                  label: s.calendar_gregorian,
                  active: !useHijri,
                  onTap: () => onToggle(false),
                ),
                _Tab(
                  label: s.calendar_hijri,
                  active: useHijri,
                  onTap: () => onToggle(true),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              GestureDetector(
                onTap: () => onDateChange(
                  DateTime(m.year, m.month - 1, m.day.clamp(1, 28)),
                ),
                child: const Icon(
                  Icons.arrow_back_ios,
                  color: QuranColors.greenPrimary,
                  size: 18,
                ),
              ),
              const Spacer(),
              Column(
                children: [
                  Text(
                    header,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    sub,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.45),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              GestureDetector(
                onTap: () => onDateChange(
                  DateTime(m.year, m.month + 1, m.day.clamp(1, 28)),
                ),
                child: const Icon(
                  Icons.arrow_forward_ios,
                  color: QuranColors.greenPrimary,
                  size: 18,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: weekHeaders
                .map(
                  (d) => Expanded(
                    child: Center(
                      child: Text(
                        d,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 8),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              childAspectRatio: 1,
            ),
            itemCount: days + firstWd,
            itemBuilder: (ctx, idx) {
              if (idx < firstWd) return const SizedBox();

              final day = idx - firstWd + 1;
              final thisDate = DateTime(m.year, m.month, day);
              final isToday =
                  thisDate.year == now.year &&
                  thisDate.month == now.month &&
                  thisDate.day == now.day;
              final isSel = thisDate == selectedDate;
              final isFri = thisDate.weekday == DateTime.friday;
              final hasEvent = eventsForDate(thisDate).isNotEmpty;
              final cellLabel = useHijri ? '${hijriDay(thisDate)}' : '$day';

              return GestureDetector(
                onTap: () => onDateChange(thisDate),
                child: Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: isSel && !isToday
                              ? QuranColors.greenPrimary
                              : Colors.transparent,
                          shape: BoxShape.circle,
                          border: isToday
                              ? Border.all(
                                  color: QuranColors.greenPrimary,
                                  width: 2,
                                )
                              : null,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          cellLabel,
                          style: TextStyle(
                            color: isFri
                                ? const Color(0xFFFF6B6B)
                                : isSel
                                ? Colors.white
                                : Colors.white.withOpacity(0.85),
                            fontSize: useHijri ? 10 : 13,
                            fontWeight: (isToday || isSel)
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                        ),
                      ),
                      if (hasEvent)
                        Positioned(
                          bottom: 2,
                          child: Container(
                            width: 4,
                            height: 4,
                            decoration: const BoxDecoration(
                              color: Color(0xFFFF6B6B),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _Tab({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext ctx) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? QuranColors.greenPrimary : Colors.transparent,
            borderRadius: BorderRadius.circular(30),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              color: active ? Colors.white : Colors.white54,
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }
}

class _NowNextCard extends StatelessWidget {
  final List<(String, String, String, DateTime)> pl;
  final int active, next;
  final String rem;
  final String Function(DateTime) fmt;

  const _NowNextCard({
    required this.pl,
    required this.active,
    required this.next,
    required this.rem,
    required this.fmt,
  });

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final isNow = active >= 0;
    final p = isNow ? pl[active] : (next >= 0 ? pl[next] : null);
    if (p == null) return const SizedBox(height: 160);

    return Container(
      height: 160,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: QuranColors.prayer_cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isNow
              ? QuranColors.greenPrimary.withOpacity(0.5)
              : Colors.white.withOpacity(0.08),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: (isNow ? QuranColors.greenPrimary : Colors.white)
                  .withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isNow) ...[
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: QuranColors.greenPrimary,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 5),
                ],
                Text(
                  isNow ? s.prayer_now : s.prayer_next,
                  style: TextStyle(
                    color: isNow ? QuranColors.greenPrimary : Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(p.$3, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text(
                p.$1,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            fmt(p.$4),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w800,
            ),
          ),
          const Spacer(),
          if (!isNow && rem.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                s.prayer_in(rem),
                style: const TextStyle(color: Colors.white60, fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }
}

class _PrayedCard extends StatelessWidget {
  final Set<String> prayed;

  const _PrayedCard({required this.prayed});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final count = prayed.length;

    return Container(
      height: 160,
      decoration: BoxDecoration(
        color: QuranColors.prayer_cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: CustomPaint(
              painter: _ArcPainter(count / 5),
              child: const SizedBox.expand(),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$count/5',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                s.prayer_completed_count,
                style: const TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ArcPainter extends CustomPainter {
  final double progress;

  const _ArcPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) / 2 - 8;

    final bg = Paint()
      ..color = Colors.white.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;

    final fg = Paint()
      ..color = QuranColors.greenPrimary
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;

    const start = -math.pi / 2 + 0.25;
    const sweep = math.pi * 2 - 0.5;

    canvas.drawArc(
      Rect.fromCircle(center: c, radius: r),
      start,
      sweep,
      false,
      bg,
    );

    if (progress > 0) {
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: r),
        start,
        sweep * progress,
        false,
        fg,
      );
    }
  }

  @override
  bool shouldRepaint(_ArcPainter o) => o.progress != progress;
}

class _PrayerRow extends StatelessWidget {
  final String nameDari, nameEn, icon, time, remainStr;
  final bool isActive, isNext, isDone, canCheck;
  final VoidCallback? onToggle;

  const _PrayerRow({
    required this.nameDari,
    required this.nameEn,
    required this.icon,
    required this.time,
    required this.isActive,
    required this.isNext,
    required this.isDone,
    required this.canCheck,
    required this.remainStr,
    this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: isDone
            ? QuranColors.greenPrimary
            : isActive
            ? QuranColors.greenPrimary.withOpacity(0.16)
            : QuranColors.cardColors,
        borderRadius: BorderRadius.circular(36),
        border: Border.all(
          color: isDone
              ? QuranColors.greenPrimary
              : isActive
              ? QuranColors.greenPrimary.withOpacity(0.9)
              : Colors.white.withOpacity(0.06),
          width: (isDone || isActive) ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onToggle,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDone ? Colors.white : Colors.transparent,
                border: Border.all(
                  color: isDone
                      ? QuranColors.greenPrimary
                      : canCheck
                      ? Colors.white54
                      : Colors.white24,
                  width: 2,
                ),
              ),
              child: isDone
                  ? const Icon(Icons.check, color: Colors.black, size: 14)
                  : null,
            ),
          ),
          const SizedBox(width: 12),
          Text(icon, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nameDari,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          if (isNext && remainStr.isNotEmpty)
            Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: QuranColors.greenPrimary.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                remainStr,
                style: const TextStyle(
                  color: QuranColors.creamColor,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          if (isActive && !isNext)
            Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: QuranColors.greenPrimary,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                s.prayer_now_badge,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          const SizedBox(width: 13),
          Text(
            time,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
