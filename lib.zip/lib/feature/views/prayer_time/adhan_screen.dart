import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/providers/prayer_provider.dart';
import 'package:quran_app/services/prayer_times_service.dart';

const List<Map<String, String>> _adhanLines = [
  {'arabic': 'ٱللَّٰهُ أَكْبَرُ',                              'dari': 'خداوند بزرگ‌ترین است'},
  {'arabic': 'ٱللَّٰهُ أَكْبَرُ',                              'dari': 'خداوند بزرگ‌ترین است'},
  {'arabic': 'أَشْهَدُ أَن لَّا إِلَٰهَ إِلَّا ٱللَّٰهُ',    'dari': 'شهادت می‌دهم که معبودی جز الله نیست'},
  {'arabic': 'أَشْهَدُ أَنَّ مُحَمَّدًا رَّسُولُ ٱللَّٰهِ',  'dari': 'شهادت می‌دهم که محمد فرستاده‌ی الله است'},
  {'arabic': 'حَيَّ عَلَى ٱلصَّلَاةِ',                        'dari': 'به سوی نماز بشتابید'},
  {'arabic': 'حَيَّ عَلَى ٱلْفَلَاحِ',                        'dari': 'به سوی رستگاری بشتابید'},
  {'arabic': 'ٱللَّٰهُ أَكْبَرُ',                              'dari': 'خداوند بزرگ‌ترین است'},
  {'arabic': 'لَا إِلَٰهَ إِلَّا ٱللَّٰهُ',                   'dari': 'معبودی جز الله نیست'},
];

class AdhanScreen extends ConsumerStatefulWidget {
  final String prayerName;
  final String prayerTime;

  const AdhanScreen({super.key, required this.prayerName, required this.prayerTime});

  @override
  ConsumerState<AdhanScreen> createState() => _AdhanScreenState();
}

class _AdhanScreenState extends ConsumerState<AdhanScreen> with SingleTickerProviderStateMixin {
  int _currentLine = 0;
  bool _isPlaying = true;
  Timer? _lineTimer;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
    _fadeController.forward();
    _startAdhan();
  }

  void _startAdhan() {
    _lineTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!_isPlaying) { timer.cancel(); return; }
      if (_currentLine < _adhanLines.length - 1) {
        _fadeController.reverse().then((_) {
          if (mounted) { setState(() => _currentLine++); _fadeController.forward(); }
        });
      } else {
        timer.cancel();
        setState(() => _isPlaying = false);
      }
    });
  }

  void _stopAdhan() {
    _lineTimer?.cancel();
    setState(() => _isPlaying = false);
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _lineTimer?.cancel();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provinceIdx   = ref.watch(selectedProvinceProvider);
    final province      = afghanProvinces[provinceIdx];
    final currentLine   = _adhanLines[_currentLine];

    return Scaffold(
      backgroundColor: const Color(0xFFF5E6C8),
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFF5E6C8), Color(0xFFE8D4A0)],
                ),
              ),
            ),
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: _stopAdhan,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(color: Colors.black.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                          child: const Icon(Icons.close, color: Color(0xFF2D5A4A), size: 20),
                        ),
                      ),
                      const Spacer(),
                      Text('اذان ${widget.prayerName}',
                          style: const TextStyle(color: Color(0xFF1A3A2A), fontSize: 16, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      const SizedBox(width: 36),
                    ],
                  ),
                ),

                Expanded(
                  flex: 3,
                  child: Center(
                    child: CustomPaint(size: const Size(220, 180), painter: _MosquePainter()),
                  ),
                ),

                Expanded(
                  flex: 3,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FadeTransition(
                          opacity: _fadeAnim,
                          child: Text(
                            currentLine['arabic']!,
                            textAlign: TextAlign.center,
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(fontFamily: 'Scheherazade', fontSize: 34, fontWeight: FontWeight.bold, color: Color(0xFF1A3A2A), height: 1.6),
                          ),
                        ),
                        const SizedBox(height: 18),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                          decoration: BoxDecoration(color: const Color(0xFF1A3A2A), borderRadius: BorderRadius.circular(16)),
                          child: Column(
                            children: [
                              Text(currentLine['dari']!, textAlign: TextAlign.center,
                                  style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.5)),
                              const Divider(color: Colors.white24, height: 20),
                              Text('${province.nameDari} • ${widget.prayerTime}',
                                  style: const TextStyle(color: Colors.white60, fontSize: 13)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Progress dots
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_adhanLines.length, (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: i == _currentLine ? 20 : 6, height: 6,
                    decoration: BoxDecoration(
                      color: i == _currentLine ? const Color(0xFF1A3A2A) : const Color(0xFF1A3A2A).withOpacity(0.3),
                      borderRadius: BorderRadius.circular(3),
                    ),
                  )),
                ),
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: _SlideToStop(onStop: _stopAdhan),
                ),
                const SizedBox(height: 30),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SlideToStop extends StatefulWidget {
  final VoidCallback onStop;
  const _SlideToStop({required this.onStop});
  @override
  State<_SlideToStop> createState() => _SlideToStopState();
}

class _SlideToStopState extends State<_SlideToStop> {
  double _dragX = 0;
  static const double _maxDrag = 200;

  @override
  Widget build(BuildContext context) => Container(
    height: 60,
    decoration: BoxDecoration(color: const Color(0xFF1A3A2A), borderRadius: BorderRadius.circular(30)),
    child: Stack(
      alignment: Alignment.centerLeft,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 50),
          width: 70 + _dragX, height: 60,
          decoration: BoxDecoration(color: const Color(0xFF22C55E).withOpacity(0.3), borderRadius: BorderRadius.circular(30)),
        ),
        Center(child: Text('برای توقف به راست بکشید', style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13, fontWeight: FontWeight.w600))),
        Positioned(
          left: 6 + _dragX,
          child: GestureDetector(
            onHorizontalDragUpdate: (d) {
              setState(() => _dragX = (_dragX + d.delta.dx).clamp(0.0, _maxDrag));
              if (_dragX >= _maxDrag) widget.onStop();
            },
            onHorizontalDragEnd: (_) => setState(() => _dragX = 0),
            child: Container(
              width: 48, height: 48,
              decoration: const BoxDecoration(color: Color(0xFF22C55E), shape: BoxShape.circle),
              child: const Icon(Icons.chevron_right, color: Colors.white, size: 28),
            ),
          ),
        ),
      ],
    ),
  );
}

class _MosquePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final teal  = Paint()..color = const Color(0xFF2A8A7A);
    final cream = Paint()..color = const Color(0xFFF5E6C8);
    final dark  = Paint()..color = const Color(0xFF2A3A34);
    final w = size.width; final h = size.height;

    canvas.drawPath(Path()..moveTo(w*.35,h*.5)..quadraticBezierTo(w*.5,h*.05,w*.65,h*.5)..close(), teal);
    canvas.drawRect(Rect.fromLTWH(w*.25,h*.5,w*.5,h*.45), cream);
    canvas.drawRRect(RRect.fromRectAndCorners(Rect.fromLTWH(w*.4,h*.6,w*.2,h*.35), topLeft: const Radius.circular(20), topRight: const Radius.circular(20)), dark);
    canvas.drawRect(Rect.fromLTWH(w*.15,h*.3,w*.08,h*.65), teal);
    canvas.drawPath(Path()..moveTo(w*.15,h*.3)..quadraticBezierTo(w*.19,h*.1,w*.23,h*.3)..close(), teal);
    canvas.drawRect(Rect.fromLTWH(w*.77,h*.3,w*.08,h*.65), teal);
    canvas.drawPath(Path()..moveTo(w*.77,h*.3)..quadraticBezierTo(w*.81,h*.1,w*.85,h*.3)..close(), teal);
    canvas.drawRect(Rect.fromLTWH(w*.3,h*.55,w*.08,h*.12), dark);
    canvas.drawRect(Rect.fromLTWH(w*.62,h*.55,w*.08,h*.12), dark);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
