import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/providers/reading_progress_provider.dart';
import '../../../core/commons/ui_components/reading_page/speedcontroller_bottomsheet.dart';
import '../../../providers/reader_provider.dart';

class ReaderPage extends ConsumerStatefulWidget {
  final int? surahNumber;
  final String? surahName;
  final int? initialAyah;
  final int? juzNumber;

  const ReaderPage({
    super.key,
    this.surahNumber,
    this.surahName,
    this.initialAyah,
    this.juzNumber,
  });

  @override
  ConsumerState<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends ConsumerState<ReaderPage>
    with SingleTickerProviderStateMixin {
  // ── Scroll ────────────────────────────────────────────────────────────────
  final ScrollController _scrollCtrl = ScrollController();
  bool _isAutoScroll = false;
  double _scrollSpeed = 40.0; // px per second
  bool _userScrolling = false;

  // ── Page mode ─────────────────────────────────────────────────────────────
  bool _isPageMode = false;
  PageController? _pageCtrl;
  List<List<dynamic>> _pages = [];
  bool _pagesBuilt = false;

  // ── Overlay ───────────────────────────────────────────────────────────────
  bool _showOverlay = false;
  Timer? _overlayTimer;
  late AnimationController _overlayAnim;
  late Animation<double> _fadeAnim;

  double _pageWidth = 0, _pageHeight = 0;
  static const double _pagePadH = 24.0, _pagePadV = 80.0;

  // For progress tracking
  Timer? _progressTimer;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _overlayAnim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _fadeAnim = CurvedAnimation(parent: _overlayAnim, curve: Curves.easeInOut);

    final reader = ref.read(readerProvider.notifier);
    reader.loadFontSize();
    reader.loadContent(
      surahNumber: widget.surahNumber,
      juzNumber: widget.juzNumber,
    );

    // Track scroll for progress
    _scrollCtrl.addListener(_onScroll);
  }

  void _onScroll() {
    if (!_scrollCtrl.hasClients) return;
    final max = _scrollCtrl.position.maxScrollExtent;
    if (max <= 0) return;
    final progress = _scrollCtrl.offset / max;
    final key = widget.surahNumber != null
        ? 'surah_${widget.surahNumber}'
        : 'juz_${widget.juzNumber}';
    ref.read(readingProgressProvider.notifier).updateProgress(key, progress);

    // If user scrolls manually, stop auto scroll
    if (_isAutoScroll &&
        _scrollCtrl.position.isScrollingNotifier.value == false) {
      // will handle via pointer events
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _scrollToHighlighted();
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _stopAutoScroll();
    _overlayTimer?.cancel();
    _progressTimer?.cancel();
    _overlayAnim.dispose();
    _pageCtrl?.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _scrollToHighlighted() {
    if (widget.initialAyah == null || _isPageMode) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Small delay to ensure list is laid out
      Future.delayed(const Duration(milliseconds: 350), () {
        if (!mounted) return;
        final state = ref.read(readerProvider);
        if (state.loading || state.verses.isEmpty) return;
        final index = state.verses.indexWhere(
          (v) => v['ayah'] == widget.initialAyah,
        );
        if (index == -1 || !_scrollCtrl.hasClients) return;
        // Estimate position: average verse height ~85px + padding
        final estimatedPos = (index * 85.0).clamp(
          0.0,
          _scrollCtrl.position.maxScrollExtent,
        );
        _scrollCtrl.animateTo(
          estimatedPos,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
        );
        // Set highlight
        ref.read(readerProvider.notifier).setHighlight(widget.initialAyah);
      });
    });
  }

  // ── SMOOTH Auto Scroll ────────────────────────────────────────────────────
  void _toggleAutoScroll() {
    if (_isAutoScroll) {
      _stopAutoScroll();
    } else {
      setState(() => _isAutoScroll = true);
      _startSmoothScroll();
    }
  }

  void _startSmoothScroll() {
    if (!mounted || !_scrollCtrl.hasClients) return;
    final remaining = _scrollCtrl.position.maxScrollExtent - _scrollCtrl.offset;
    if (remaining <= 0) {
      setState(() => _isAutoScroll = false);
      return;
    }
    // Calculate duration: pixels / (pixels per second) = seconds
    final durationMs = ((remaining / _scrollSpeed) * 1000).round().clamp(
      100,
      36000000,
    );
    _scrollCtrl
        .animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: Duration(milliseconds: durationMs),
          curve: Curves.linear,
        )
        .then((_) {
          if (mounted && _isAutoScroll) setState(() => _isAutoScroll = false);
        });
  }

  void _stopAutoScroll() {
    if (_scrollCtrl.hasClients) {
      // Jump to current position to interrupt animation
      final pos = _scrollCtrl.offset;
      _scrollCtrl.jumpTo(pos);
    }
    if (mounted) setState(() => _isAutoScroll = false);
  }

  void _onPointerDown(PointerDownEvent _) {
    if (_isAutoScroll) _stopAutoScroll();
  }

  void _toggleOverlay() {
    _overlayTimer?.cancel();
    if (_showOverlay) {
      _overlayAnim.reverse().then(
        (_) => mounted ? setState(() => _showOverlay = false) : null,
      );
    } else {
      setState(() => _showOverlay = true);
      _overlayAnim.forward();
      _overlayTimer = Timer(const Duration(seconds: 3), () {
        if (mounted && _showOverlay) {
          _overlayAnim.reverse().then(
            (_) => mounted ? setState(() => _showOverlay = false) : null,
          );
        }
      });
    }
  }

  // ── Page splitting ────────────────────────────────────────────────────────
  List<List<dynamic>> _splitIntoPages(
    List<dynamic> verses,
    double fontSize,
    double pageWidth,
    double pageHeight,
  ) {
    if (verses.isEmpty) return [];
    final textWidth = pageWidth - _pagePadH * 2;
    const lineHeight = 2.0;
    TextPainter measure(String text, double fs) {
      final tp = TextPainter(
        text: TextSpan(
          text: text,
          style: TextStyle(
            fontFamily: 'Quran',
            fontSize: fs,
            height: lineHeight,
          ),
        ),
        textDirection: TextDirection.rtl,
        maxLines: null,
      )..layout(maxWidth: textWidth);
      return tp;
    }

    final pages = <List<dynamic>>[];
    var cur = <dynamic>[];
    double used = 0;
    bool firstPage = true;
    double bismH = widget.surahNumber != null && widget.surahNumber != 9
        ? 90.0
        : 0.0;
    double hdrH = widget.surahName != null ? 70.0 : 0.0;
    double avail = pageHeight - (firstPage ? bismH + hdrH : 0);

    for (final verse in verses) {
      final arabic = "${verse['text_ar']} ﴿${verse['ayah']}﴾ ";
      final h = measure(arabic, fontSize).height + 8;
      if (used + h > avail && cur.isNotEmpty) {
        pages.add(List.from(cur));
        cur = [];
        used = 0;
        firstPage = false;
        avail = pageHeight;
      }
      cur.add(verse);
      used += h;
    }
    if (cur.isNotEmpty) pages.add(cur);
    return pages;
  }

  void _buildPages(ReaderState state) {
    if (_pageWidth == 0 || _pageHeight == 0) return;
    final p = _splitIntoPages(
      state.verses,
      state.fontSize,
      _pageWidth,
      _pageHeight - _pagePadV,
    );
    setState(() {
      _pages = p;
      _pagesBuilt = true;
      _pageCtrl?.dispose();
      _pageCtrl = PageController();
    });
  }

  void _switchToPageMode(ReaderState state) {
    _pagesBuilt = false;
    WidgetsBinding.instance.addPostFrameCallback((_) => _buildPages(state));
  }

  List<TextSpan> _buildSpans(List<dynamic> verses, ReaderState state) {
    return verses.expand((ayah) {
      final highlight =
          state.highlightAyah != null && ayah['ayah'] == state.highlightAyah;
      final bg = highlight ? const Color(0xFF004d00).withOpacity(0.3) : null;
      return [
        TextSpan(
          text: "${ayah['text_ar']} ",
          style: TextStyle(color: Colors.black87, backgroundColor: bg),
        ),
        TextSpan(
          text: "﴿${ayah['ayah']}﴾ ",
          style: TextStyle(
            fontSize: 22,
            color: Colors.black54,
            backgroundColor: bg,
          ),
        ),
      ];
    }).toList();
  }

  String _title() {
    if (widget.surahName != null) return widget.surahName!;
    if (widget.surahNumber != null) return 'Surah ${widget.surahNumber}';
    if (widget.juzNumber != null) return 'Juz ${widget.juzNumber}';
    return 'Quran';
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(readerProvider);
    return LayoutBuilder(
      builder: (context, constraints) {
        if (_pageWidth == 0) {
          _pageWidth = constraints.maxWidth;
          _pageHeight = constraints.maxHeight;
        }
        return Scaffold(
          backgroundColor: const Color(0xFFF5F0E8),
          body: GestureDetector(
            onTap: _toggleOverlay,
            child: Stack(
              children: [
                // Content
                if (state.loading)
                  const Center(child: CircularProgressIndicator())
                else if (_isPageMode)
                  _buildPageView(state)
                else
                  _buildScrollView(state),

                // Overlay AppBar
                if (_showOverlay)
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: FadeTransition(
                      opacity: _fadeAnim,
                      child: _AppBarOverlay(
                        title: _title(),
                        isAutoScroll: _isAutoScroll,
                        isPageMode: _isPageMode,
                        onBack: () => Navigator.pop(context),
                        onToggleMode: () {
                          setState(() {
                            _isPageMode = !_isPageMode;
                            if (_isPageMode) {
                              _stopAutoScroll();
                              _switchToPageMode(state);
                            }
                          });
                        },
                        onAutoScroll: _isPageMode ? null : _toggleAutoScroll,
                        onSpeed: _isPageMode
                            ? null
                            : () => showModalBottomSheet(
                                context: context,
                                isScrollControlled: true,
                                backgroundColor: const Color(0xFFe9edec),
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(24),
                                  ),
                                ),
                                builder: (_) => SpeedControlBottomSheet(
                                  speed: _scrollSpeed,
                                  onChanged: (v) {
                                    setState(() {
                                      _scrollSpeed = v;
                                    });
                                    if (_isAutoScroll) {
                                      _stopAutoScroll();
                                      Future.delayed(
                                        const Duration(milliseconds: 50),
                                        () {
                                          if (mounted &&
                                              _isAutoScroll == false) {
                                            setState(
                                              () => _isAutoScroll = true,
                                            );
                                            _startSmoothScroll();
                                          }
                                        },
                                      );
                                    }
                                  },
                                ),
                              ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildScrollView(ReaderState state) {
    return Listener(
      onPointerDown: _onPointerDown,
      child: SingleChildScrollView(
        controller: _scrollCtrl,
        padding: const EdgeInsets.fromLTRB(_pagePadH, 72, _pagePadH, 80),
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Column(
            children: [
              if (widget.surahName != null)
                _SurahHeader(
                  surahName: widget.surahName!,
                  surahNumber: widget.surahNumber,
                ),
              if (widget.surahName != null) const SizedBox(height: 16),
              if (widget.surahNumber != null && widget.surahNumber != 9)
                Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: Image.asset(
                    'assets/webp/bismillah.webp',
                    fit: BoxFit.cover,
                    width: 260,
                    height: 80,
                  ),
                ),
              RichText(
                textAlign: TextAlign.justify,
                text: TextSpan(
                  children: _buildSpans(state.verses, state),
                  style: TextStyle(
                    color: Colors.black87,
                    fontFamily: 'Quran',
                    fontSize: state.fontSize,
                    height: 2.0,
                  ),
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPageView(ReaderState state) {
    if (!_pagesBuilt) return const Center(child: CircularProgressIndicator());
    if (_pages.isEmpty) return const Center(child: Text('No content'));
    return PageView.builder(
      controller: _pageCtrl,
      itemCount: _pages.length,
      itemBuilder: (context, pageIdx) => _QuranPage(
        verses: _pages[pageIdx],
        state: state,
        spans: _buildSpans(_pages[pageIdx], state),
        showBismillah:
            pageIdx == 0 &&
            widget.surahNumber != null &&
            widget.surahNumber != 9,
        showHeader: pageIdx == 0 && widget.surahName != null,
        surahName: widget.surahName,
        surahNumber: widget.surahNumber,
        pageIndex: pageIdx,
        totalPages: _pages.length,
      ),
    );
  }
}

// ── Quran Page ─────────────────────────────────────────────────────────────

class _QuranPage extends StatelessWidget {
  final List<dynamic> verses;
  final ReaderState state;
  final List<TextSpan> spans;
  final bool showBismillah, showHeader;
  final String? surahName;
  final int? surahNumber;
  final int pageIndex, totalPages;

  const _QuranPage({
    required this.verses,
    required this.state,
    required this.spans,
    required this.showBismillah,
    required this.showHeader,
    this.surahName,
    this.surahNumber,
    required this.pageIndex,
    required this.totalPages,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF5F0E8),
      child: Column(
        children: [
          const SizedBox(height: 72),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (showHeader && surahName != null) ...[
                      _SurahHeader(
                        surahName: surahName!,
                        surahNumber: surahNumber,
                      ),
                      const SizedBox(height: 12),
                    ],
                    if (showBismillah) ...[
                      Image.asset(
                        'assets/webp/bismillah.webp',
                        fit: BoxFit.cover,
                        width: 240,
                        height: 90,
                      ),
                      const SizedBox(height: 12),
                    ],
                    Expanded(
                      child: RichText(
                        textAlign: TextAlign.justify,
                        text: TextSpan(
                          children: spans,
                          style: TextStyle(
                            color: Colors.black87,
                            fontFamily: 'Quran',
                            fontSize: state.fontSize,
                            height: 2.0,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16, top: 8),
                      child: Center(
                        child: Text(
                          '${pageIndex + 1} / $totalPages',
                          style: const TextStyle(
                            color: Colors.black38,
                            fontSize: 12,
                            fontFamily: 'Quran',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Overlay AppBar ─────────────────────────────────────────────────────────

class _AppBarOverlay extends StatelessWidget {
  final String title;
  final bool isAutoScroll, isPageMode;
  final VoidCallback onBack, onToggleMode;
  final VoidCallback? onAutoScroll, onSpeed;

  const _AppBarOverlay({
    required this.title,
    required this.isAutoScroll,
    required this.isPageMode,
    required this.onBack,
    required this.onToggleMode,
    this.onAutoScroll,
    this.onSpeed,
  });

  Widget _btn({
    required IconData icon,
    required VoidCallback? onTap,
    bool active = false,
    bool disabled = false,
  }) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: active
            ? QuranColors.greenPrimary.withOpacity(0.85)
            : disabled
            ? Colors.white.withOpacity(0.06)
            : Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(
        icon,
        color: disabled ? Colors.white38 : Colors.white,
        size: 18,
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.black.withOpacity(0.65), Colors.transparent],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              _btn(icon: Icons.arrow_back_ios_new, onTap: onBack),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 10),
              _btn(
                icon: isPageMode ? Icons.view_stream : Icons.menu_book,
                onTap: onToggleMode,
                active: isPageMode,
              ),
              const SizedBox(width: 8),
              _btn(
                icon: isAutoScroll ? Icons.pause : Icons.play_arrow,
                onTap: onAutoScroll,
                active: isAutoScroll,
                disabled: isPageMode,
              ),
              const SizedBox(width: 8),
              _btn(icon: Icons.speed, onTap: onSpeed, disabled: isPageMode),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Surah Header ───────────────────────────────────────────────────────────

class _SurahHeader extends StatelessWidget {
  final String surahName;
  final int? surahNumber;
  const _SurahHeader({required this.surahName, this.surahNumber});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: Divider(color: Colors.black26, thickness: 0.5)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                surahNumber != null ? '$surahNumber' : '',
                style: const TextStyle(
                  color: Colors.black38,
                  fontSize: 12,
                  fontFamily: 'Quran',
                ),
              ),
            ),
            Expanded(child: Divider(color: Colors.black26, thickness: 0.5)),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          surahName,
          style: const TextStyle(
            fontFamily: 'Quran',
            fontSize: 28,
            color: Colors.black87,
            fontWeight: FontWeight.bold,
          ),
          textDirection: TextDirection.rtl,
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: Divider(color: Colors.black26, thickness: 0.5)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Icon(Icons.star_border, size: 12, color: Colors.black26),
            ),
            Expanded(child: Divider(color: Colors.black26, thickness: 0.5)),
          ],
        ),
      ],
    );
  }
}
