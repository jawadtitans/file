import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/constants/colors.dart';
import '../../../generated/l10n.dart';
import '../../../providers/bookmark_provider.dart';
import '../../../providers/reading_progress_provider.dart';
import '../reader/reader.dart';
import '../search/search.dart';

// ── Recent Reading Model ───────────────────────────────────────────────────

class RecentItem {
  final String name, nameAr, type;
  final int number, lastAyah;
  final DateTime timestamp;

  const RecentItem({
    required this.name,
    required this.nameAr,
    required this.type,
    required this.number,
    required this.lastAyah,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'nameAr': nameAr,
    'type': type,
    'number': number,
    'lastAyah': lastAyah,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };

  factory RecentItem.fromJson(Map<String, dynamic> j) => RecentItem(
    name: j['name'],
    nameAr: j['nameAr'],
    type: j['type'],
    number: j['number'],
    lastAyah: j['lastAyah'],
    timestamp: DateTime.fromMillisecondsSinceEpoch(j['timestamp']),
  );
}

// ── Recent Reading Provider ────────────────────────────────────────────────

class RecentReadingNotifier extends StateNotifier<List<RecentItem>> {
  static const _key = 'recent_quran_items';

  RecentReadingNotifier() : super([]) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    state = raw.map((e) => RecentItem.fromJson(json.decode(e))).toList();
  }

  Future<void> add(RecentItem item) async {
    final updated = [
      item,
      ...state.where((e) => !(e.type == item.type && e.number == item.number)),
    ].take(10).toList();

    state = updated;
    final prefs = await SharedPreferences.getInstance();
    prefs.setStringList(
      _key,
      updated.map((e) => json.encode(e.toJson())).toList(),
    );
  }
}

final recentReadingProvider =
    StateNotifierProvider<RecentReadingNotifier, List<RecentItem>>(
      (ref) => RecentReadingNotifier(),
    );

// ── View Mode ──────────────────────────────────────────────────────────────

enum QuranViewMode { sura, juz }

final quranViewModeProvider = StateProvider<QuranViewMode>(
  (ref) => QuranViewMode.sura,
);

// ── Quran Tab Index ────────────────────────────────────────────────────────

final quranTabProvider = StateProvider<int>((ref) => 0);

// ── Main Quran View ────────────────────────────────────────────────────────

class QuranView extends ConsumerWidget {
  const QuranView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: QuranColors.prayer_cardColor,
        appBar: const _QuranAppBar(),
        body: const TabBarView(children: [_ReadTab(), _ProgressTab()]),
      ),
    );
  }
}

// ── AppBar ─────────────────────────────────────────────────────────────────

class _QuranAppBar extends ConsumerWidget implements PreferredSizeWidget {
  const _QuranAppBar();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight + 48);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;

    return AppBar(
      backgroundColor: QuranColors.prayer_cardColor,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(
          Icons.arrow_back_ios_new,
          color: Colors.white,
          size: 20,
        ),
        onPressed: () => Navigator.maybePop(context),
      ),
      title: Text(
        s.nav_Quran,
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search, color: Colors.white, size: 26),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SearchPage()),
          ),
        ),
        const SizedBox(width: 10),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Container(
          padding: const EdgeInsets.all(4),
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          decoration: BoxDecoration(
            color: QuranColors.cardColors,
            borderRadius: BorderRadius.circular(30),
          ),
          child: TabBar(
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white54,
            indicator: BoxDecoration(
              color: QuranColors.greenPrimary,
              borderRadius: BorderRadius.circular(30),
            ),
            tabs: [
              Tab(text: s.quran_read_tab),
              Tab(text: s.quran_progress_tab),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Read Tab ───────────────────────────────────────────────────────────────

class _ReadTab extends ConsumerStatefulWidget {
  const _ReadTab();

  @override
  ConsumerState<_ReadTab> createState() => _ReadTabState();
}

class _ReadTabState extends ConsumerState<_ReadTab> {
  List<Map<String, dynamic>> _surahs = [];
  List<Map<String, dynamic>> _juzList = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sd = await rootBundle.loadString('assets/json/surah.json');
    final jd = await rootBundle.loadString('assets/json/quran_juzs.json');

    if (mounted) {
      setState(() {
        _surahs = List<Map<String, dynamic>>.from(json.decode(sd));
        _juzList = List<Map<String, dynamic>>.from(json.decode(jd));
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final viewMode = ref.watch(quranViewModeProvider);
    final recents = ref.watch(recentReadingProvider);
    final locale = Localizations.localeOf(context).languageCode;
    final isPersian = locale == 'fa';

    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: QuranColors.greenPrimary),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (recents.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              children: [
                Text(
                  s.quran_recents,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 6),
                const Icon(Icons.info_outline, color: Colors.white38, size: 16),
              ],
            ),
          ),
          SizedBox(
            height: 65,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 13),
              itemCount: recents.length,
              itemBuilder: (context, i) => _RecentCard(item: recents[i]),
            ),
          ),
          const SizedBox(height: 8),
        ] else ...[
          const SizedBox(height: 16),
        ],
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              Text(
                viewMode == QuranViewMode.sura
                    ? s.quran_sura_list
                    : s.quran_juz_list,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              _ViewModeDropdown(current: viewMode),
            ],
          ),
        ),
        Expanded(
          child: viewMode == QuranViewMode.sura
              ? _SurahList(
                  surahs: _surahs,
                  isPersian: isPersian,
                  onTap: _onSurahTap,
                )
              : _JuzListView(
                  juzList: _juzList,
                  isPersian: isPersian,
                  onTap: _onJuzTap,
                ),
        ),
      ],
    );
  }

  void _onSurahTap(Map<String, dynamic> s, String name, int number) {
    ref
        .read(recentReadingProvider.notifier)
        .add(
          RecentItem(
            name: name,
            nameAr: s['nameAr'] ?? '',
            type: 'surah',
            number: number,
            lastAyah: 1,
            timestamp: DateTime.now(),
          ),
        );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ReaderPage(surahNumber: number, surahName: name),
      ),
    );
  }

  void _onJuzTap(Map<String, dynamic> j, String name, int number) {
    ref
        .read(recentReadingProvider.notifier)
        .add(
          RecentItem(
            name: name,
            nameAr: j['name_ar'] ?? '',
            type: 'juz',
            number: number,
            lastAyah: 1,
            timestamp: DateTime.now(),
          ),
        );

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ReaderPage(juzNumber: number)),
    );
  }
}

// ── View Mode Dropdown ─────────────────────────────────────────────────────

class _ViewModeDropdown extends ConsumerWidget {
  final QuranViewMode current;

  const _ViewModeDropdown({required this.current});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;
    final type = current == QuranViewMode.sura
        ? s.quran_view_sura
        : s.quran_view_juz;

    return GestureDetector(
      onTap: () => _showMenu(context, ref),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white24),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              s.quran_view_label(type),
              style: const TextStyle(color: Colors.white, fontSize: 13),
            ),
            const SizedBox(width: 4),
            const Icon(
              Icons.keyboard_arrow_down,
              color: Colors.white,
              size: 18,
            ),
          ],
        ),
      ),
    );
  }

  void _showMenu(BuildContext context, WidgetRef ref) {
    final box = context.findRenderObject() as RenderBox;
    final offset = box.localToGlobal(Offset.zero);

    showMenu<QuranViewMode>(
      context: context,
      color: QuranColors.cardColors,
      position: RelativeRect.fromLTRB(
        offset.dx,
        offset.dy + box.size.height,
        0,
        0,
      ),
      items: [
        PopupMenuItem(
          value: QuranViewMode.sura,
          child: Text(
            S.of(context)!.quran_view_sura,
            style: const TextStyle(color: Colors.white),
          ),
        ),
        PopupMenuItem(
          value: QuranViewMode.juz,
          child: Text(
            S.of(context)!.quran_view_juz,
            style: const TextStyle(color: Colors.white),
          ),
        ),
      ],
    ).then((v) {
      if (v != null) {
        ref.read(quranViewModeProvider.notifier).state = v;
      }
    });
  }
}

// ── Surah List ─────────────────────────────────────────────────────────────

class _SurahList extends ConsumerWidget {
  final List<Map<String, dynamic>> surahs;
  final bool isPersian;
  final void Function(Map<String, dynamic>, String, int) onTap;

  const _SurahList({
    required this.surahs,
    required this.isPersian,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sLoc = S.of(context)!;
    final bookmarks = ref.watch(bookmarkedSurahsProvider);

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100),
      itemCount: surahs.length,
      itemBuilder: (context, i) {
        final s = surahs[i];
        final number = int.parse(s['number'].toString());
        final name = isPersian
            ? (s['nameAr'] ?? s['nameEn'])
            : (s['nameEn'] ?? '');
        final sub = s['type'] ?? '';

        return _QuranListItem(
          number: '$number',
          nameAr: s['nameAr'] ?? '',
          nameEn: name,
          subtitle: sub,
          extra: sLoc.quran_ayah_count('${s['ayahs']}'),
          isBookmarked: bookmarks.contains(number),
          onTap: () => onTap(s, name, number),
          onBookmark: () =>
              ref.read(bookmarkedSurahsProvider.notifier).toggle(number),
        );
      },
    );
  }
}

// ── Juz List with headers ──────────────────────────────────────────────────

class _JuzListView extends ConsumerWidget {
  final List<Map<String, dynamic>> juzList;
  final bool isPersian;
  final void Function(Map<String, dynamic>, String, int) onTap;

  const _JuzListView({
    required this.juzList,
    required this.isPersian,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;
    final bookmarks = ref.watch(bookmarkedJuzProvider);

    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 100),
      itemCount: juzList.length * 2,
      itemBuilder: (context, i) {
        final juzIdx = i ~/ 2;
        final j = juzList[juzIdx];
        final number = j['number'] as int;
        final name = isPersian
            ? (j['name_ar'] ?? j['name'])
            : (j['name'] ?? '');

        if (i.isEven) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(
              s.quran_juz_header(number),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          );
        }

        return _QuranListItem(
          number: '$number',
          nameAr: j['name_ar'] ?? '',
          nameEn: name,
          subtitle: '',
          extra: '',
          isBookmarked: bookmarks.contains(number),
          onTap: () => onTap(j, name, number),
          onBookmark: () =>
              ref.read(bookmarkedJuzProvider.notifier).toggle(number),
          showNumber: false,
        );
      },
    );
  }
}

// ── Quran List Item ────────────────────────────────────────────────────────

class _QuranListItem extends StatelessWidget {
  final String number, nameAr, nameEn, subtitle, extra;
  final bool isBookmarked;
  final bool showNumber;
  final VoidCallback onTap;
  final VoidCallback? onBookmark;

  const _QuranListItem({
    required this.number,
    required this.nameAr,
    required this.nameEn,
    required this.subtitle,
    required this.extra,
    required this.isBookmarked,
    required this.onTap,
    this.onBookmark,
    this.showNumber = true,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: QuranColors.cardColors,
          borderRadius: BorderRadius.circular(35),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Row(
          children: [
            if (showNumber) ...[
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                  color: QuranColors.deepGreenColor,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  number,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 14),
            ],
            Text(
              nameAr,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontFamily: 'Quran',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    nameEn,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (subtitle.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            if (extra.isNotEmpty)
              Text(
                extra,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 12,
                ),
              ),
            if (onBookmark != null) ...[
              const SizedBox(width: 8),
              GestureDetector(
                onTap: onBookmark,
                child: Icon(
                  isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                  color: isBookmarked
                      ? QuranColors.greenPrimary
                      : Colors.white38,
                  size: 22,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ── Recent Card ────────────────────────────────────────────────────────────

class _RecentCard extends StatelessWidget {
  final RecentItem item;

  const _RecentCard({required this.item});

  String _timeAgo() {
    final diff = DateTime.now().difference(item.timestamp);
    if (diff.inDays > 0) return '${diff.inDays}d';
    if (diff.inHours > 0) return '${diff.inHours}h';
    return '${diff.inMinutes}m';
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => item.type == 'juz'
              ? ReaderPage(juzNumber: item.number)
              : ReaderPage(surahNumber: item.number, surahName: item.name),
        ),
      ),
      child: SizedBox(
        width: 70,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 70,
              height: 50,
              margin: const EdgeInsets.only(right: 10),
              decoration: BoxDecoration(
                color: QuranColors.cardColors,
                borderRadius: BorderRadius.circular(16),
              ),
              alignment: Alignment.center,
              child: Text(
                item.nameAr.isNotEmpty ? item.nameAr : item.name,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontFamily: 'Quran',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Progress Tab ───────────────────────────────────────────────────────────

class _ProgressTab extends ConsumerStatefulWidget {
  const _ProgressTab();

  @override
  ConsumerState<_ProgressTab> createState() => _ProgressTabState();
}

class _ProgressTabState extends ConsumerState<_ProgressTab> {
  bool _showKhatam = false;
  int _readMinutes = 0;
  Set<int> _completedJuz = {};

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final juzList = prefs.getStringList('completed_juz') ?? [];

    if (mounted) {
      setState(() {
        _readMinutes = prefs.getInt('read_minutes_today') ?? 0;
        _completedJuz = juzList.map(int.parse).toSet();
      });
    }
  }

  Future<void> _toggleJuz(int juz) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (_completedJuz.contains(juz)) {
        _completedJuz.remove(juz);
      } else {
        _completedJuz.add(juz);
      }
    });

    prefs.setStringList(
      'completed_juz',
      _completedJuz.map((e) => '$e').toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final recents = ref.watch(recentReadingProvider);
    final lastRead = recents.isNotEmpty ? recents.first : null;
    final now = DateTime.now();
    final weekDays = List.generate(
      7,
      (i) => now.subtract(Duration(days: 6 - i)),
    );

    final progressMap = ref.watch(readingProgressProvider);
    final completedFromScroll = progressMap.entries
        .where((e) => e.value.isComplete)
        .map((e) => e.key)
        .toSet();

    for (final key in completedFromScroll) {
      if (key.startsWith('juz_')) {
        final n = int.tryParse(key.split('_').last);
        if (n != null) _completedJuz.add(n);
      }
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
          child: Row(
            children: [
              _SubTab(
                label: s.reading,
                active: !_showKhatam,
                onTap: () => setState(() => _showKhatam = false),
              ),
              const SizedBox(width: 12),
              _SubTab(
                label: s.quran_khatam_tab,
                active: _showKhatam,
                onTap: () => setState(() => _showKhatam = true),
              ),
            ],
          ),
        ),
        Expanded(
          child: _showKhatam
              ? _KhatamView(
                  completedJuz: _completedJuz,
                  completedSurahKeys: completedFromScroll
                      .where((k) => k.startsWith('surah_'))
                      .toSet(),
                  onToggleJuz: _toggleJuz,
                )
              : _ReadingView(
                  lastRead: lastRead,
                  readMinutes: _readMinutes,
                  weekDays: weekDays,
                ),
        ),
      ],
    );
  }
}

// ── Khatam View ────────────────────────────────────────────────────────────

class _KhatamView extends ConsumerStatefulWidget {
  final Set<int> completedJuz;
  final Set<String> completedSurahKeys;
  final void Function(int) onToggleJuz;

  const _KhatamView({
    required this.completedJuz,
    required this.completedSurahKeys,
    required this.onToggleJuz,
  });

  @override
  ConsumerState<_KhatamView> createState() => _KhatamViewState();
}

class _KhatamViewState extends ConsumerState<_KhatamView>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<Map<String, dynamic>> _surahs = [];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _loadSurahs();
  }

  Future<void> _loadSurahs() async {
    final data = await rootBundle.loadString('assets/json/surah.json');
    if (mounted) {
      setState(() {
        _surahs = List<Map<String, dynamic>>.from(json.decode(data));
      });
    }
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final totalJuz = 30;
    final totalSurah = 114;
    final doneJuz = widget.completedJuz.length;
    final doneSurah = widget.completedSurahKeys.length;
    final pct = (doneJuz / totalJuz * 100).round();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 110,
                    height: 110,
                    child: CircularProgressIndicator(
                      value: doneJuz / totalJuz,
                      strokeWidth: 10,
                      backgroundColor: Colors.white.withOpacity(0.1),
                      color: QuranColors.greenPrimary,
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '$pct%',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '$doneJuz/$totalJuz ${s.juz}',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(width: 32),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _StatChip(
                    label: s.quran_juz_done,
                    value: '$doneJuz / $totalJuz',
                  ),
                  const SizedBox(height: 8),
                  _StatChip(
                    label: s.quran_surah_done,
                    value: '$doneSurah / $totalSurah',
                  ),
                ],
              ),
            ],
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: QuranColors.deepGreenColor,
            borderRadius: BorderRadius.circular(30),
          ),
          child: TabBar(
            controller: _tabCtrl,
            dividerColor: Colors.transparent,
            indicatorSize: TabBarIndicatorSize.tab,
            indicator: BoxDecoration(
              color: QuranColors.greenPrimary,
              borderRadius: BorderRadius.circular(30),
            ),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white54,
            tabs: [
              Tab(text: s.surah),
              Tab(text: s.juz),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: TabBarView(
            controller: _tabCtrl,
            children: [
              _completedSurahKeys().isEmpty
                  ? _EmptyKhatam(message: s.quran_complete_surah_message)
                  : ListView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      children: _completedSurahKeys().map((key) {
                        final num = int.tryParse(key.split('_').last) ?? 0;
                        final surah = _surahs.firstWhere(
                          (s) => int.parse(s['number'].toString()) == num,
                          orElse: () => {},
                        );
                        if (surah.isEmpty) return const SizedBox();
                        return _CompletedSurahCard(surah: surah, number: num);
                      }).toList(),
                    ),
              SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 6,
                    childAspectRatio: 1,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: 30,
                  itemBuilder: (ctx, i) {
                    final juz = i + 1;
                    final done = widget.completedJuz.contains(juz);

                    return GestureDetector(
                      onTap: () {},
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          color: done
                              ? QuranColors.greenPrimary
                              : QuranColors.cardColors,
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: done
                                ? QuranColors.greenPrimary
                                : Colors.white.withOpacity(0.1),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: done
                            ? const Icon(
                                Icons.check,
                                color: Colors.white,
                                size: 18,
                              )
                            : Text(
                                '$juz',
                                style: const TextStyle(
                                  color: Colors.white60,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Set<String> _completedSurahKeys() => widget.completedSurahKeys;
}

class _StatChip extends StatelessWidget {
  final String label, value;

  const _StatChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: QuranColors.cardColors,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _EmptyKhatam extends StatelessWidget {
  final String message;

  const _EmptyKhatam({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.auto_stories_outlined,
            color: Colors.white.withOpacity(0.25),
            size: 48,
          ),
          const SizedBox(height: 12),
          Text(
            message,
            style: TextStyle(
              color: Colors.white.withOpacity(0.4),
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _CompletedSurahCard extends StatelessWidget {
  final Map<String, dynamic> surah;
  final int number;

  const _CompletedSurahCard({required this.surah, required this.number});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final nameAr = surah['nameAr'] ?? '';
    final nameEn = surah['nameEn'] ?? s.quran_surah_label(number);
    final type = surah['type'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: QuranColors.cardColors,
        borderRadius: BorderRadius.circular(46),
        border: Border.all(color: QuranColors.greenPrimary.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: const BoxDecoration(
              color: QuranColors.greenPrimary,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: const Icon(Icons.check, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      nameEn,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                  ],
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: QuranColors.greenPrimary.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        s.quran_completed,
                        style: const TextStyle(
                          color: QuranColors.greenPrimary,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (type.isNotEmpty)
                      Text(
                        type,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 11,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          Text(
            nameAr,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontFamily: 'Quran',
            ),
          ),
        ],
      ),
    );
  }
}

// ── Sub Tab ────────────────────────────────────────────────────────────────

class _SubTab extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _SubTab({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: active ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
          border: active ? null : Border.all(color: Colors.white24),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.black : Colors.white70,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}

// ── Reading Progress View ──────────────────────────────────────────────────

class _ReadingView extends ConsumerWidget {
  final RecentItem? lastRead;
  final int readMinutes;
  final List<DateTime> weekDays;

  const _ReadingView({
    required this.lastRead,
    required this.readMinutes,
    required this.weekDays,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;
    final progressMap = ref.watch(readingProgressProvider);

    final progressItems =
        progressMap.entries.where((e) => !e.value.isExpired).toList()
          ..sort((a, b) => b.value.lastUpdated.compareTo(a.value.lastUpdated));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: QuranColors.cardColors,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                SizedBox(
                  width: 80,
                  height: 80,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(
                        value: readMinutes > 0
                            ? (readMinutes / 30).clamp(0.0, 1.0)
                            : 0,
                        strokeWidth: 6,
                        backgroundColor: Colors.white.withOpacity(0.1),
                        color: const Color(0xFF00CED4),
                      ),
                      const Icon(
                        Icons.menu_book_rounded,
                        color: Color(0xFF00CED4),
                        size: 24,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (lastRead != null) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            s.quran_last_read,
                            style: const TextStyle(
                              color: Colors.white60,
                              fontSize: 11,
                            ),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          lastRead!.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          '${lastRead!.number}:${lastRead!.lastAyah}',
                          style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 4),
                        GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => lastRead!.type == 'juz'
                                  ? ReaderPage(juzNumber: lastRead!.number)
                                  : ReaderPage(
                                      surahNumber: lastRead!.number,
                                      surahName: lastRead!.name,
                                    ),
                            ),
                          ),
                          child: Row(
                            children: [
                              Text(
                                s.continue_reading,
                                style: const TextStyle(
                                  color: QuranColors.greenPrimary,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Icon(
                                Icons.arrow_forward,
                                color: QuranColors.greenPrimary,
                                size: 14,
                              ),
                            ],
                          ),
                        ),
                      ] else ...[
                        Text(
                          s.quran_no_reading_yet,
                          style: const TextStyle(color: Colors.white60),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$readMinutes',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          s.quran_minute_read,
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (progressItems.isNotEmpty) ...[
            const SizedBox(height: 20),
            Text(
              s.quran_reading_progress_title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              s.quran_reading_progress_subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 12),
            ...progressItems.map((entry) {
              final key = entry.key;
              final progress = entry.value.progress;
              final isSurah = key.startsWith('surah_');
              final num = int.tryParse(key.split('_').last) ?? 0;
              final label = isSurah
                  ? s.quran_surah_label(num)
                  : s.quran_juz_label(num);
              final pct = (progress * 100).round();
              final isComplete = entry.value.isComplete;

              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: QuranColors.cardColors,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: isComplete
                        ? QuranColors.greenPrimary.withOpacity(0.4)
                        : Colors.white.withOpacity(0.05),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: isComplete
                            ? QuranColors.greenPrimary
                            : QuranColors.deepGreenColor,
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: isComplete
                          ? const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 18,
                            )
                          : Text(
                              '$num',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                              ),
                            ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                label,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const Spacer(),
                              Text(
                                isComplete ? s.quran_completed : '$pct%',
                                style: TextStyle(
                                  color: isComplete
                                      ? QuranColors.greenPrimary
                                      : Colors.white60,
                                  fontSize: 12,
                                  fontWeight: isComplete
                                      ? FontWeight.w700
                                      : FontWeight.normal,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: LinearProgressIndicator(
                              borderRadius: BorderRadiusGeometry.circular(30),
                              value: progress.clamp(0.0, 1.0),
                              minHeight: 6,
                              backgroundColor: Colors.white.withOpacity(0.1),
                              valueColor: AlwaysStoppedAnimation(
                                isComplete
                                    ? QuranColors.greenPrimary
                                    : const Color(0xFF00CED4),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => isSurah
                              ? ReaderPage(surahNumber: num)
                              : ReaderPage(juzNumber: num),
                        ),
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          color: QuranColors.greenPrimary.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: const Icon(
                          Iconsax.play_circle,
                          color: QuranColors.greenPrimary,
                          size: 16,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
          ] else ...[
            const SizedBox(height: 100),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: QuranColors.cardColors,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.import_contacts_rounded,
                    color: Colors.white.withOpacity(0.3),
                    size: 40,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    s.quran_start_reading_progress,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 102),
        ],
      ),
    );
  }
}
