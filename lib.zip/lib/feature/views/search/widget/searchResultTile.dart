import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import '../../../../core/constants/colors.dart';

class SearchResultTile extends StatelessWidget {
  final String leadingText;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const SearchResultTile({
    super.key,
    required this.leadingText,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: QuranColors.deepGreenColor.withOpacity(0.3),
        child: Text(
          leadingText,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle, style: const TextStyle(fontFamily: "Quran")),
      onTap: onTap,
    );
  }
}
