import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/commons/ui_components/home/listitems.dart';
import '../../../core/constants/colors.dart';
import '../../../feature/views/reader/reader.dart';
import '../../../generated/l10n.dart';

enum SearchType { surah, ayah }

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage>
    with SingleTickerProviderStateMixin {
  Set<int> _bookmarkedSurahs = {};
  final TextEditingController _ctrl = TextEditingController();
  SearchType _type = SearchType.surah;
  List<Map<String, dynamic>> _chapters = [];
  List<Map<String, dynamic>> _verses = [];
  List<Map<String, dynamic>> _results = [];
  final Map<int, Map<String, dynamic>> _surahMap = {};
  bool _loading = true;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _loadQuran();
    _loadBookmarks();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _bookmarkedSurahs = (prefs.getStringList('bookmarked_surahs') ?? [])
          .map(int.parse)
          .toSet();
    });
  }

  bool _isBookmarked(int n) => _bookmarkedSurahs.contains(n);

  Future<void> _toggleBookmark(int n) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('bookmarked_surahs') ?? [];
    if (list.contains('$n')) {
      list.remove('$n');
    } else {
      list.add('$n');
    }
    await prefs.setStringList('bookmarked_surahs', list);
    setState(() {
      if (_bookmarkedSurahs.contains(n)) {
        _bookmarkedSurahs.remove(n);
      } else {
        _bookmarkedSurahs.add(n);
      }
    });
  }

  Future<void> _loadQuran() async {
    final data = await rootBundle.loadString('assets/json/quran.json');
    final j = json.decode(data);
    final chapters = List<Map<String, dynamic>>.from(j['chapters'] ?? []);
    final verses = List<Map<String, dynamic>>.from(j['verses'] ?? []);
    for (var c in chapters) {
      _surahMap[c['surah_number']] = c;
    }
    setState(() {
      _chapters = chapters;
      _verses = verses;
      _loading = false;
    });
  }

  void _filter(String query) {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        _results = [];
        _fadeCtrl.reset();
      });
      return;
    }

    final lower = q.toLowerCase();
    final num = int.tryParse(q);
    List<Map<String, dynamic>> res;

    if (_type == SearchType.surah) {
      res = _chapters.where((c) {
        final en = c['name_en']?.toString().toLowerCase() ?? '';
        final ar = c['name_ar']?.toString().toLowerCase() ?? '';
        return en.contains(lower) ||
            ar.contains(lower) ||
            (num != null && c['surah_number'] == num);
      }).toList();
    } else {
      res = _verses
          .where((v) {
            final text = v['text_ar'] ?? '';
            final vk = v['verse_key'] ?? '';
            final ayah = v['ayah'] as int;
            final surah = v['surah'] as int;
            if (q.contains(':')) return vk == q;
            return text.contains(q) ||
                (num != null && (ayah == num || surah == num));
          })
          .take(100)
          .toList();
    }

    setState(() => _results = res);
    if (res.isNotEmpty) {
      _fadeCtrl.reset();
      _fadeCtrl.forward();
    }
  }

  void _changeType(SearchType t) {
    setState(() {
      _type = t;
      _results = [];
      _ctrl.clear();
    });
    Navigator.pop(context);
  }

  void _showFilterSheet() {
    final s = S.of(context)!;

    showModalBottomSheet(
      context: context,
      backgroundColor: QuranColors.prayer_cardColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              s.search_by_type_title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _FilterCard(
                    icon: Iconsax.book_copy,
                    title: s.search_surah_short,
                    subtitle: s.search_surah_subtitle,
                    active: _type == SearchType.surah,
                    onTap: () => _changeType(SearchType.surah),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _FilterCard(
                    icon: Iconsax.quote_up_circle_copy,
                    title: s.search_ayah_short,
                    subtitle: s.search_ayah_filter_subtitle,
                    active: _type == SearchType.ayah,
                    onTap: () => _changeType(SearchType.ayah),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    final placeholder = _type == SearchType.surah
        ? s.search_surah
        : s.search_ayah_example;

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      appBar: AppBar(
        backgroundColor: QuranColors.prayer_cardColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new,
            color: QuranColors.creamColor,
            size: 18,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          decoration: BoxDecoration(
            color: QuranColors.cardColors,
            borderRadius: BorderRadius.circular(30),
          ),
          child: TextField(
            controller: _ctrl,
            onChanged: _filter,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Quran',
            ),
            decoration: InputDecoration(
              hintText: placeholder,
              hintStyle: TextStyle(
                color: Colors.white.withOpacity(0.35),
                fontFamily: 'Quran',
                fontSize: 13,
              ),
              prefixIcon: const Icon(
                Iconsax.search_status_copy,
                color: Colors.white54,
                size: 20,
              ),
              suffixIcon: GestureDetector(
                onTap: _showFilterSheet,
                child: Container(
                  margin: const EdgeInsets.all(5),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: QuranColors.greenPrimary.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: QuranColors.greenPrimary.withOpacity(0.3),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Iconsax.filter_copy,
                        size: 14,
                        color: QuranColors.greenPrimary,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        _type == SearchType.surah
                            ? s.search_surah_short
                            : s.search_ayah_short,
                        style: const TextStyle(
                          color: QuranColors.greenPrimary,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 13,
              ),
            ),
          ),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: QuranColors.greenPrimary),
            )
          : _ctrl.text.isEmpty
          ? _SearchHintView(type: _type)
          : _results.isEmpty
          ? _EmptyResultsView(query: _ctrl.text)
          : FadeTransition(
              opacity: _fadeAnim,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                itemCount: _results.length,
                itemBuilder: (ctx, i) => _buildItem(ctx, _results[i]),
              ),
            ),
    );
  }

  Widget _buildItem(BuildContext ctx, Map<String, dynamic> item) {
    final s = S.of(ctx)!;
    final locale = Localizations.localeOf(ctx).languageCode;
    final isPersian = locale == 'fa';

    if (_type == SearchType.surah) {
      final num = item['surah_number'] as int;
      final name = isPersian
          ? (item['name_ar'] ?? '')
          : (item['name_en'] ?? '');

      return BuildQuranItem(
        is_visible_icon: false,
        is_juz: false,
        isBookmarked: _isBookmarked(num),
        number: '$num',
        nameEn: name,
        nameAr: item['name_ar'] ?? '',
        ayahs: s.quran_ayah_count(item['verses_count'] ?? 0),
        revelationType: item['revelation_type'] ?? '',
        onTap: () => Navigator.push(
          ctx,
          MaterialPageRoute(
            builder: (_) => ReaderPage(surahNumber: num, surahName: name),
          ),
        ),
        onBookmark: () => _toggleBookmark(num),
      );
    }

    final surahNum = item['surah'] as int;
    final ayahNum = item['ayah'] as int;
    final surahData = _surahMap[surahNum];
    final surahName = isPersian
        ? (surahData?['name_ar'] ?? '')
        : (surahData?['name_en'] ?? 'Surah $surahNum');
    final arabicText = item['text_ar'] as String? ?? '';
    final verseKey = item['verse_key'] as String? ?? '$surahNum:$ayahNum';

    return _AyahResultCard(
      surahNum: surahNum,
      ayahNum: ayahNum,
      surahName: surahName,
      arabicText: arabicText,
      verseKey: verseKey,
      isBookmarked: _isBookmarked(surahNum),
      onTap: () => Navigator.push(
        ctx,
        MaterialPageRoute(
          builder: (_) => ReaderPage(
            surahNumber: surahNum,
            surahName: surahName,
            initialAyah: ayahNum,
          ),
        ),
      ),
      onBookmark: () => _toggleBookmark(surahNum),
    );
  }
}

// ── Ayah Result Card ───────────────────────────────────────────────────────

class _AyahResultCard extends StatelessWidget {
  final int surahNum, ayahNum;
  final String surahName, arabicText, verseKey;
  final bool isBookmarked;
  final VoidCallback onTap, onBookmark;

  const _AyahResultCard({
    required this.surahNum,
    required this.ayahNum,
    required this.surahName,
    required this.arabicText,
    required this.verseKey,
    required this.isBookmarked,
    required this.onTap,
    required this.onBookmark,
  });

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: QuranColors.cardColors,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: onBookmark,
                  child: Icon(
                    isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                    color: isBookmarked
                        ? QuranColors.greenPrimary
                        : Colors.white38,
                    size: 20,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: QuranColors.greenPrimary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    verseKey,
                    style: const TextStyle(
                      color: QuranColors.greenPrimary,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  surahName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: QuranColors.deepGreenColor,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: QuranColors.greenPrimary.withOpacity(0.2),
                ),
              ),
              child: Text(
                '$arabicText  ﴿$ayahNum﴾',
                textAlign: TextAlign.right,
                textDirection: TextDirection.rtl,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontFamily: 'Quran',
                  fontSize: 17,
                  height: 1.9,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  s.search_go_to_ayah,
                  style: TextStyle(
                    color: QuranColors.greenPrimary.withOpacity(0.8),
                    fontSize: 11,
                  ),
                ),
                const SizedBox(width: 4),
                Icon(
                  Icons.arrow_forward_ios,
                  color: QuranColors.greenPrimary.withOpacity(0.8),
                  size: 10,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ── Filter Card ────────────────────────────────────────────────────────────

class _FilterCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool active;
  final VoidCallback onTap;

  const _FilterCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: active
              ? QuranColors.greenPrimary.withOpacity(0.15)
              : QuranColors.cardColors,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: active
                ? QuranColors.greenPrimary.withOpacity(0.5)
                : Colors.white.withOpacity(0.08),
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: active ? QuranColors.greenPrimary : Colors.white60,
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                color: active ? QuranColors.greenPrimary : Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.45),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Empty / Hint Views ─────────────────────────────────────────────────────

class _SearchHintView extends StatelessWidget {
  final SearchType type;

  const _SearchHintView({required this.type});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            type == SearchType.surah
                ? Icons.auto_stories_outlined
                : Icons.format_quote_outlined,
            color: Colors.white.withOpacity(0.2),
            size: 56,
          ),
          const SizedBox(height: 14),
          Text(
            type == SearchType.surah
                ? s.search_enter_surah_name
                : s.search_enter_ayah_text_or_number,
            style: TextStyle(
              color: Colors.white.withOpacity(0.4),
              fontSize: 15,
            ),
          ),
          if (type == SearchType.ayah) ...[
            const SizedBox(height: 8),
            Text(
              s.search_ayah_example,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                color: Colors.white.withOpacity(0.25),
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _EmptyResultsView extends StatelessWidget {
  final String query;

  const _EmptyResultsView({required this.query});

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.search_off,
            color: Colors.white.withOpacity(0.2),
            size: 52,
          ),
          const SizedBox(height: 12),
          Text(
            s.search_no_result_for(query),
            textDirection: TextDirection.rtl,
            style: TextStyle(
              color: Colors.white.withOpacity(0.45),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class card_filter extends StatelessWidget {
  final String icon_path, title, subtitle;
  final VoidCallback? onTap;

  const card_filter({
    super.key,
    required this.icon_path,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: QuranColors.cardColors,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(icon_path, height: 40, fit: BoxFit.contain),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
