import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/colors.dart';
import '../../../providers/splash_controller.dart';
import '../../../routes/app_route.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoController;
  late Animation<double> _logoFade;
  late Animation<double> _logoScale;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.easeInOut),
    );

    _logoScale = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _logoController, curve: Curves.elasticOut),
    );

    Future.delayed(const Duration(milliseconds: 500), () {
      _logoController.forward();
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    /// WATCH to trigger provider
    final splashState = ref.watch(splashProvider);

    /// LISTEN must be inside build
    ref.listen<AsyncValue<bool>>(splashProvider, (previous, next) {
      next.whenOrNull(
        data: (completed) {
          Future.microtask(() {
            if (!mounted) return;
            Navigator.pushReplacementNamed(
              context,
              completed ? AppRoutes.home : AppRoutes.welcome,
            );
          });
        },
      );
    });

    return Scaffold(
      backgroundColor: QuranColors.deepGreenColor,
      body: Center(
        child: AnimatedBuilder(
          animation: _logoController,
          builder: (context, child) {
            return Opacity(
              opacity: _logoFade.value,
              child: Transform.scale(
                scale: _logoScale.value,
                child: ClipRRect(
                  borderRadius: BorderRadiusGeometry.circular(100),
                  child: Image.asset(
                    fit: BoxFit.cover,
                    "assets/webp/android_12.png",
                    width: 130,
                    height: 130,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
