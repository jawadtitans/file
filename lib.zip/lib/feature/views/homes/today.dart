import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/commons/ui_components/home/appbar.dart';
import 'package:quran_app/core/commons/ui_components/home/avatar_card.dart';
import 'package:quran_app/core/commons/ui_components/home/features_card.dart';
import 'package:quran_app/core/commons/ui_components/home/monthly_deed_card.dart';
import 'package:quran_app/core/commons/ui_components/home/header.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/data/datamodels/days_data.dart';
import 'package:quran_app/data/datamodels/features_model.dart';
import 'package:quran_app/providers/prayer_provider.dart';
import 'package:quran_app/routes/app_route.dart';
import '../../../core/commons/ui_components/home/header_widget.dart';
import '../../../data/datamodels/weeks_events_model.dart' hide weekDays;
import '../../../generated/l10n.dart';
import '../prayer_time/adhan_screen.dart';

class Today extends ConsumerStatefulWidget {
  const Today({super.key});

  @override
  ConsumerState<Today> createState() => _TodayState();
}

class _TodayState extends ConsumerState<Today> {
  final AdhanScheduler _scheduler = AdhanScheduler();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _setupAdhanTimer());
  }

  void _setupAdhanTimer() {
    final times = ref.read(prayerTimesProvider);
    _scheduler.schedule(
      times: times,
      onAdhan: (name, time) {
        if (!mounted) return;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => AdhanScreen(prayerName: name, prayerTime: time),
          ),
        );
        Future.delayed(const Duration(seconds: 2), _setupAdhanTimer);
      },
    );
  }

  @override
  void dispose() {
    _scheduler.cancel();
    super.dispose();
  }

  void _onFeatureTap(int index) {
    final routes = [
      AppRoutes.prayerTimePage,
      AppRoutes.quranPage,
      AppRoutes.tasbihPage,
      AppRoutes.qiblaPage,
      AppRoutes.duasPage,
      AppRoutes.khatamPage,
    ];

    if (index < routes.length) {
      Navigator.pushNamed(context, routes[index]);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final days = weekDays(s);
    final features = deenFeatures(s);

    return Scaffold(
      appBar: custom_appbar(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: days.length,
                itemBuilder: (context, i) => DayAvatar(
                  day: days[i],
                  onTap: () => Navigator.pushNamed(
                    context,
                    AppRoutes.story_view,
                    arguments: days[i],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: _LivePrayerCards(),
            ),
            const SizedBox(height: 26),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text(
                    s.today_features_title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: QuranColors.cardColors,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      s.today_assistant_tools,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: features.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 2.6,
              ),
              itemBuilder: (context, i) => FeatureCard(
                title: features[i].title,
                emoji: features[i].emoji,
                onTap: () => _onFeatureTap(i),
              ),
            ),
            const SizedBox(height: 30),
            header(
              title: s.today_monthly_deeds_title,
              subtitle: s.today_monthly_deeds_subtitle,
              is_month_header: true,
            ),
            const SizedBox(height: 16),
            const MonthlyDeedsCard(),
            const SizedBox(height: 150),
          ],
        ),
      ),
    );
  }
}

// ── Live Prayer Cards (self-ticking) ──────────────────────────────────────

class _LivePrayerCards extends ConsumerStatefulWidget {
  const _LivePrayerCards();

  @override
  ConsumerState<_LivePrayerCards> createState() => _LivePrayerCardsState();
}

class _LivePrayerCardsState extends ConsumerState<_LivePrayerCards> {
  Timer? _ticker;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() => _now = DateTime.now());
      }
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  String _fmt(DateTime dt) {
    final h = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m ${dt.hour >= 12 ? "pm" : "am"}';
  }

  String _remaining(DateTime t, S s) {
    final d = t.difference(_now);
    if (d.isNegative) return '';
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final sec = d.inSeconds % 60;

    if (h > 0) return s.today_in_hours_minutes(h, m);
    return s.today_in_minutes_seconds(m, sec);
  }

  String _localizeCardLabel(S s, String key) {
    switch (key) {
      case 'now':
        return s.today_now;
      case 'next':
        return s.today_next;
      case 'upcoming':
        return s.upcoming;
      default:
        return key;
    }
  }

  String _localizePrayerName(S s, String key) {
    switch (key) {
      case 'fajr':
        return s.fajr;
      case 'dhuhr':
        return s.dhuhr;
      case 'asr':
        return s.asr;
      case 'maghrib':
        return s.maghrib;
      case 'isha':
        return s.isha;
      default:
        return key;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;
    final cards = ref.watch(prayerCardsProvider);
    final left = cards.left;
    final right = cards.right;
    final isLeftCurrent = left.status == PrayerCardStatus.current;

    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => Navigator.pushNamed(context, AppRoutes.prayerTimePage),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: QuranColors.prayer_cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: isLeftCurrent
                      ? QuranColors.greenPrimary.withOpacity(0.45)
                      : Colors.white.withOpacity(0.07),
                  width: isLeftCurrent ? 1.5 : 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (isLeftCurrent) ...[
                        const _PulseDot(),
                        const SizedBox(width: 6),
                      ],
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          _localizeCardLabel(s, left.label),
                          style: TextStyle(
                            color: isLeftCurrent
                                ? QuranColors.greenPrimary
                                : Colors.white60,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${left.prayerEmoji} ${_localizePrayerName(s, left.prayerNameKey)}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _fmt(left.time),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (!isLeftCurrent)
                    _AnimatedCountdown(remaining: _remaining(left.time, s)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: GestureDetector(
            onTap: () => Navigator.pushNamed(context, AppRoutes.prayerTimePage),
            child: Container(
              padding: const EdgeInsets.all(21),
              decoration: BoxDecoration(
                color: QuranColors.prayer_cardColor,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white.withOpacity(0.07)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 4,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          _localizeCardLabel(s, right.label),
                          style: const TextStyle(
                            color: Colors.white60,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Text(
                        _fmt(right.time),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        right.prayerEmoji,
                        style: const TextStyle(fontSize: 18),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _localizePrayerName(s, right.prayerNameKey),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// ── Pulsing green dot ──────────────────────────────────────────────────────

class _PulseDot extends StatefulWidget {
  const _PulseDot();

  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _anim = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(
          color: QuranColors.greenPrimary,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// ── Animated countdown text ────────────────────────────────────────────────

class _AnimatedCountdown extends StatelessWidget {
  final String remaining;

  const _AnimatedCountdown({required this.remaining});

  @override
  Widget build(BuildContext context) {
    if (remaining.isEmpty) return const SizedBox();

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (child, anim) => FadeTransition(
        opacity: anim,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.3),
            end: Offset.zero,
          ).animate(anim),
          child: child,
        ),
      ),
      child: Text(
        remaining,
        key: ValueKey(remaining),
        style: TextStyle(
          color: Colors.white.withOpacity(0.55),
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
