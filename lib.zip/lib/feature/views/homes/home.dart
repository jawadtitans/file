import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/feature/views/Quran/Quran_view.dart';
import 'package:quran_app/feature/views/homes/today.dart';

import '../../../core/commons/ui_components/home/bottom_nav_section.dart';
import '../../../core/constants/texts_string.dart';
import '../../../generated/l10n.dart';
import '../bookmark/bookmark.dart';
import '../prayer_time/prayer_time.dart';
import '../setting/setting.dart';

class HomePage extends ConsumerStatefulWidget {
  final int initialSelectedIndex;

  const HomePage({super.key, this.initialSelectedIndex = 2});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  late int selectedIndex;
  DateTime? _lastBackPressed;

  OverlayEntry? _overlayEntry;
  Timer? _overlayTimer;

  @override
  void initState() {
    super.initState();
    selectedIndex = widget.initialSelectedIndex;
  }

  @override
  void dispose() {
    _removeExitMessage();
    super.dispose();
  }

  Widget _buildPage(int index) {
    switch (index) {
      case 0:
        return const Today();
      case 1:
        return const PrayerTime();
      case 2:
        return const QuranView();
      case 3:
        return const BookmarkPage();
      case 4:
        return const SettingPage();
      default:
        return const QuranView();
    }
  }

  void _showExitMessage() {
    final s = S.of(context)!;

    _removeExitMessage();

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: 24,
        right: 24,
        bottom: 110,
        child: IgnorePointer(
          child: Material(
            color: Colors.transparent,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: QuranColors.greenPrimary.withOpacity(0.92),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.18),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Text(
                  s.exit_app_message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);

    _overlayTimer = Timer(const Duration(seconds: 2), () {
      _removeExitMessage();
    });
  }

  void _removeExitMessage() {
    _overlayTimer?.cancel();
    _overlayTimer = null;
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  void _handleBackPress() {
    if (selectedIndex != 2) {
      setState(() {
        selectedIndex = 2;
      });
      return;
    }

    final now = DateTime.now();

    if (_lastBackPressed == null ||
        now.difference(_lastBackPressed!) > const Duration(seconds: 2)) {
      _lastBackPressed = now;
      _showExitMessage();
      return;
    }

    SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final items = const_texts.getBottomNavItems(context);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (didPop) return;
        _handleBackPress();
      },
      child: Scaffold(
        extendBody: true,
        body: KeyedSubtree(
          key: ValueKey(selectedIndex),
          child: _buildPage(selectedIndex),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: FloatingActionButton(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            backgroundColor: selectedIndex == 2
                ? QuranColors.creamColor
                : Colors.white,
            onPressed: () {
              setState(() {
                selectedIndex = 2;
              });
            },
            child: Image.asset(
              items[2].icon,
              fit: BoxFit.cover,
              width: 35,
              height: 35,
              scale: 24,
              color: QuranColors.deepGreenColor,
            ),
          ),
        ),
        bottomNavigationBar: BottomNav(
          items: items,
          selectedIndex: selectedIndex,
          onTap: (index) {
            setState(() {
              selectedIndex = index;
            });
          },
        ),
      ),
    );
  }
}
