import 'package:flutter/material.dart';
import '../../../data/datamodels/days_data.dart';
import '../../../generated/l10n.dart';

class StoryViewScreen extends StatefulWidget {
  final DayData dayData;
  final int initialStoryIndex;

  const StoryViewScreen({
    super.key,
    required this.dayData,
    this.initialStoryIndex = 0,
  });

  @override
  State<StoryViewScreen> createState() => _StoryViewScreenState();
}

class _StoryViewScreenState extends State<StoryViewScreen>
    with TickerProviderStateMixin {
  late int _currentIndex;
  late AnimationController _progressController;

  static const Duration _storyDuration = Duration(seconds: 40);

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialStoryIndex;
    _progressController = AnimationController(
      vsync: this,
      duration: _storyDuration,
    );
    _startProgress();
  }

  void _startProgress() {
    _progressController
      ..reset()
      ..forward().whenComplete(() {
        if (mounted) _nextStory();
      });
  }

  void _nextStory() {
    if (_currentIndex < widget.dayData.stories.length - 1) {
      setState(() {
        _currentIndex++;
      });

      _startProgress();
    } else {
      Navigator.pop(context);
    }
  }

  void _prevStory() {
    if (_currentIndex > 0) {
      setState(() {
        _currentIndex--;
      });

      _startProgress();
    } else {
      Navigator.pop(context);
    }
  }

  void _pauseOrResume() {
    if (_progressController.isAnimating) {
      _progressController.stop();
    } else {
      _progressController.forward().whenComplete(() {
        if (mounted) _nextStory();
      });
    }
  }

  @override
  void dispose() {
    _progressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stories = widget
        .dayData
        .stories; // used for the lenght of the stories in the pageview and this is bery important for the content section of the :
    final story = stories[_currentIndex];
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapDown: (details) {
          final width = MediaQuery.of(context).size.width;
          if (details.globalPosition.dx < width / 3) {
            _prevStory();
          } else if (details.globalPosition.dx > width * 2 / 3) {
            _nextStory();
          } else {
            _pauseOrResume();
          }
        },
        child: Stack(
          children: [
            /// FADE STORY TRANSITION
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 700),
              transitionBuilder: (child, animation) {
                return FadeTransition(
                  alwaysIncludeSemantics: true,
                  opacity: animation,
                  child: child,
                );
              },
              child: SizedBox(
                key: ValueKey(_currentIndex),
                width: double.infinity,
                height: double.infinity,
                child: Stack(
                  children: [
                    /// Background Gradient
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: story.bgGradient,
                        ),
                      ),
                    ),

                    /// Mosque Painter
                    Positioned.fill(
                      child: CustomPaint(painter: _MosquePainter()),
                    ),

                    /// Overlay
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.black.withOpacity(0.3),
                            Colors.transparent,
                            Colors.transparent,
                            Colors.black.withOpacity(0.6),
                          ],
                          stops: const [0.0, 0.2, 0.6, 1.0],
                        ),
                      ),
                    ),

                    SafeArea(
                      child: Column(
                        children: [
                          /// Progress Bars
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 8,
                            ),
                            child: Row(
                              children: List.generate(stories.length, (i) {
                                return Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 2,
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(12),
                                      child: SizedBox(
                                        height: 5,
                                        child: i < _currentIndex
                                            ? Container(color: Colors.white)
                                            : i == _currentIndex
                                            ? AnimatedBuilder(
                                                animation: _progressController,
                                                builder: (_, __) =>
                                                    LinearProgressIndicator(
                                                      value: _progressController
                                                          .value,
                                                      backgroundColor: Colors
                                                          .white
                                                          .withOpacity(0.35),
                                                      valueColor:
                                                          const AlwaysStoppedAnimation<
                                                            Color
                                                          >(Colors.white),
                                                    ),
                                              )
                                            : Container(
                                                color: Colors.white.withOpacity(
                                                  0.35,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                );
                              }),
                            ),
                          ),

                          /// Header
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 4,
                            ),
                            child: Row(
                              children: [
                                /// Avatar
                                Container(
                                  width: 38,
                                  height: 38,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(
                                      colors: widget.dayData.avatarGradient,
                                    ),
                                    border: Border.all(
                                      color: Colors.white,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      widget.dayData.letter,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),

                                const SizedBox(width: 10),

                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      widget.dayData.dayName,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      S.of(context)!.amal_adia,
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(0.75),
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),

                                const Spacer(),

                                GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: const Icon(
                                    Icons.close,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const Spacer(flex: 1),

                          /// Center Content
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 28),
                            child: Column(
                              children: [
                                /// Title
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.18),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: Colors.white.withOpacity(0.3),
                                    ),
                                  ),
                                  child: Text(
                                    story.amalTitle,
                                    textDirection: TextDirection.rtl,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),

                                const SizedBox(height: 20),

                                Text(
                                  story.icon,
                                  style: const TextStyle(fontSize: 48),
                                ),

                                const SizedBox(height: 18),

                                Text(
                                  story.verseRef,
                                  textDirection: TextDirection.rtl,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),

                                const SizedBox(height: 18),

                                Text(
                                  story.arabicText,
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.rtl,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    height: 1.8,
                                  ),
                                ),

                                const SizedBox(height: 18),

                                Text(
                                  story.translation,
                                  textAlign: TextAlign.center,
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.9),
                                    height: 1.6,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const Spacer(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Mosque Decoration
class _MosquePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.04)
      ..style = PaintingStyle.fill;

    final path = Path();
    final w = size.width;
    final h = size.height;

    final cx = w / 2;
    final baseY = h * 0.72;

    path.moveTo(cx - w * 0.28, baseY);
    path.quadraticBezierTo(
      cx - w * 0.28,
      baseY - h * 0.18,
      cx,
      baseY - h * 0.22,
    );
    path.quadraticBezierTo(
      cx + w * 0.28,
      baseY - h * 0.18,
      cx + w * 0.28,
      baseY,
    );
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
