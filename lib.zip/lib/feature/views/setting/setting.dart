import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/feature/localization/local_provider.dart';
import '../../../generated/l10n.dart';

class SettingPage extends ConsumerStatefulWidget {
  const SettingPage({super.key});

  @override
  ConsumerState<SettingPage> createState() => _SettingPageState();
}

class _SettingPageState extends ConsumerState<SettingPage> {
  bool _allowNotifications = true;
  bool _autoScroll = false;
  double _fontSize = 20;

  @override
  Widget build(BuildContext context) {
    final s = S.of(context)!;

    return Scaffold(
      backgroundColor: QuranColors.prayer_cardColor,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  Text(
                    s.settings_title,
                    style: const TextStyle(
                      color: QuranColors.creamColor,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Iconsax.setting_2,
                    color: QuranColors.greenPrimary,
                    size: 24,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _GeneralTab(
                allowNotifications: _allowNotifications,
                autoScroll: _autoScroll,
                fontSize: _fontSize,
                onNotifChange: (v) => setState(() => _allowNotifications = v),
                onScrollChange: (v) => setState(() => _autoScroll = v),
                onFontChange: (v) => setState(() => _fontSize = v),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── General Tab ────────────────────────────────────────────────────────────

class _GeneralTab extends ConsumerWidget {
  final bool allowNotifications;
  final bool autoScroll;
  final double fontSize;
  final ValueChanged<bool> onNotifChange;
  final ValueChanged<bool> onScrollChange;
  final ValueChanged<double> onFontChange;

  const _GeneralTab({
    required this.allowNotifications,
    required this.autoScroll,
    required this.fontSize,
    required this.onNotifChange,
    required this.onScrollChange,
    required this.onFontChange,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context)!;
    final locale = ref.watch(appLanguageProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          _SectionCard(
            title: s.settings_notifications_section,
            icon: Iconsax.notification,
            child: _SwitchRow(
              label: s.settings_allow_notifications,
              value: allowNotifications,
              onChanged: onNotifChange,
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: s.settings_reading_section,
            icon: Iconsax.book_1,
            child: Column(
              children: [
                _SwitchRow(
                  label: s.settings_auto_scroll,
                  value: autoScroll,
                  onChanged: onScrollChange,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Icon(
                      Iconsax.text,
                      color: QuranColors.greenPrimary,
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      s.settings_font_size,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    const Spacer(),
                    Text(
                      '${fontSize.round()}',
                      style: const TextStyle(
                        color: QuranColors.greenPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: fontSize,
                  min: 14,
                  max: 36,
                  divisions: 11,
                  activeColor: QuranColors.greenPrimary,
                  inactiveColor: Colors.white.withOpacity(0.15),
                  onChanged: onFontChange,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _SectionCard(
            title: s.settings_app_language_section,
            icon: Iconsax.language_circle,
            child: DropdownButtonHideUnderline(
              child: DropdownButton<Locale>(
                value: locale,
                isExpanded: true,
                dropdownColor: QuranColors.deepGreenColor,
                style: const TextStyle(color: Colors.white, fontSize: 14),
                icon: const Icon(
                  Icons.keyboard_arrow_down,
                  color: QuranColors.greenPrimary,
                ),
                items: [
                  DropdownMenuItem(
                    value: const Locale('en'),
                    child: Row(
                      children: [
                        const Text('🇺🇸  '),
                        Text(s.settings_language_english),
                      ],
                    ),
                  ),
                  DropdownMenuItem(
                    value: const Locale('fa'),
                    child: Row(
                      children: [
                        const Text('🇦🇫  '),
                        Text(s.settings_language_dari),
                      ],
                    ),
                  ),
                ],
                onChanged: (l) {
                  if (l != null) {
                    ref.read(appLanguageProvider.notifier).changeLanguage(l);
                  }
                },
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

// ── Reusable Section Card ──────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: QuranColors.cardColors,
        borderRadius: BorderRadius.circular(20),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: QuranColors.greenPrimary, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.55),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: QuranColors.greenPrimary,
        ),
      ],
    );
  }
}
