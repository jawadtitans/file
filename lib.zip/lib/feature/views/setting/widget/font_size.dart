import 'package:flutter/material.dart';
import 'package:quran_app/core/constants/colors.dart';

import '../../../../generated/l10n.dart';

class FontSizeItem extends StatelessWidget {
  final double fontSize;
  final ValueChanged<double> onChanged;

  const FontSizeItem({required this.fontSize, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: QuranColors.cardColors,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            S.of(context)!.quran_font_size,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: QuranColors.creamColor,
            ),
          ),
          Slider(
            activeColor: QuranColors.greenPrimary,
            min: 14,

            max: 40,
            divisions: 13,
            value: fontSize,
            label: fontSize.round().toString(),
            onChanged: onChanged,
          ),
          Center(
            child: Text(
              S.of(context)!.preview_text,
              style: TextStyle(
                fontSize: fontSize,
                color: QuranColors.creamColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
