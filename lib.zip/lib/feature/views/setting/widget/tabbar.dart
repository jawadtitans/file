import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../../generated/l10n.dart';
import '../../../localization/local_provider.dart';

class TopBar extends ConsumerWidget {
  final VoidCallback onToggleDark;

  const TopBar({super.key, required this.onToggleDark});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Container(
      color: Colors.white,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        bottom: 12,
        right: 12,
        left: 12,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: Row(
          children: [
            Consumer(
              builder: (context, ref, _) {
                final locale = ref.watch(appLanguageProvider);

                return DropdownButton<Locale>(
                  icon: Icon(Iconsax.arrow_down_1_copy, size: 17),
                  alignment: AlignmentGeometry.center,

                  borderRadius: BorderRadius.circular(15),
                  dropdownColor: Theme.of(context).scaffoldBackgroundColor,
                  value: locale,
                  onChanged: (value) {
                    if (value != null) {
                      ref
                          .read(appLanguageProvider.notifier)
                          .changeLanguage(value);
                    }
                  },
                  items: const [
                    DropdownMenuItem(
                      value: Locale('en'),
                      child: Text("English"),
                    ),
                    DropdownMenuItem(value: Locale('fa'), child: Text("فارسی")),
                  ],
                );
              },
            ),

            Expanded(
              child: Text(
                S.of(context)!.settings_title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
            ),

            // Language Dropdown (Right Side)
          ],
        ),
      ),
    );
  }
}
