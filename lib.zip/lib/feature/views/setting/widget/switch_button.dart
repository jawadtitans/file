import 'package:flutter/material.dart';

import '../../../../core/constants/colors.dart';

class SwitchItem extends StatelessWidget {
  final String title;
  final bool value;
  final IconData icon;
  final ValueChanged<bool> onChanged;

  const SwitchItem({
    required this.title,
    required this.value,
    required this.onChanged,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: QuranColors.cardColors,
      padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 10),
      child: Row(
        children: [
          Icon(icon, size: 25, color: QuranColors.greenPrimary),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w500,
                color: QuranColors.creamColor,
              ),
            ),
          ),
          Switch(
            activeThumbColor: QuranColors.greenPrimary,
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
