// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Persian (`fa`).
class AppLocalizationsFa extends AppLocalizations {
  AppLocalizationsFa([String locale = 'fa']) : super(locale);

  @override
  String get splash_text => 'هدایه';

  @override
  String get header_date => 'تاریخ امروز';

  @override
  String get header_location => 'موقعیت شما';

  @override
  String get header_time => 'ساعت';

  @override
  String get header_fajr => 'زمان باقی‌مانده تا فجر';

  @override
  String get al_quran => 'القرآن';

  @override
  String get tab_surah => 'سوره';

  @override
  String get tab_juz => 'جزء';

  @override
  String get tab_Ayah => 'آیه';

  @override
  String get no_surahs => 'هیچ سوره‌ای یافت نشد';

  @override
  String get no_ayah => 'هیچ آیه‌ای ذخیره نشده';

  @override
  String get no_surah => 'هیچ سوره‌ای ذخیره نشده';

  @override
  String get no_juz => 'هیچ جزئی ذخیره نشده';

  @override
  String get bookmar_title => 'ذخیره‌شده‌ها';

  @override
  String get today_zikr => 'ذکر امروز';

  @override
  String get nav_home => 'خانه';

  @override
  String get nav_Quran => 'قرآن';

  @override
  String get nav_prayer => 'اوقات نماز';

  @override
  String get nav_islam => 'خانه';

  @override
  String get nav_search => 'جستجو';

  @override
  String get nav_settings => 'تنظیمات';

  @override
  String get search_hint => 'جستجو';

  @override
  String get no_results => 'نتیجه‌ای یافت نشد';

  @override
  String get settings_title => 'تنظیمات';

  @override
  String get recent_downloads => 'دانلودهای اخیر';

  @override
  String get share_apps => 'اشتراک‌گذاری برنامه';

  @override
  String get my_network => 'شبکه من';

  @override
  String get payments => 'پرداخت‌ها';

  @override
  String get support => 'صداها';

  @override
  String get allow_notifications => 'اجازه اعلان‌ها';

  @override
  String get auto_scroll => 'اسکرول خودکار هنگام قرائت';

  @override
  String get preview_text => 'پیش‌نمایش متن';

  @override
  String get quran_font_size => 'اندازه قلم قرآن';

  @override
  String get account_admin => 'مدیریت حساب';

  @override
  String get login => 'ورود';

  @override
  String get quran_app => 'اپلیکیشن قرآن کریم';

  @override
  String get share => 'اشتراک‌گذاری';

  @override
  String get about_app => 'درباره برنامه';

  @override
  String get filter => 'فیلتر';

  @override
  String get search_ayah => 'جستجوی آیه';

  @override
  String get search_surah => 'جستجوی سوره';

  @override
  String get search_surah_subtitle => 'می‌توانید سوره‌ها را با نام جستجو کنید';

  @override
  String get search_ayah_subtitle => 'می‌توانید آیه‌ها را با متن جستجو کنید';

  @override
  String get prayer_times => 'اوقات نماز';

  @override
  String get fajr => 'صبح';

  @override
  String get sunrise => 'طلوع';

  @override
  String get dhuhr => 'ظهر';

  @override
  String get asr => 'عصر';

  @override
  String get maghrib => 'مغرب';

  @override
  String get isha => 'عشاء';

  @override
  String get now => 'الان';

  @override
  String get next => 'بعدی';

  @override
  String get upcoming => 'آینده';

  @override
  String get location_permission => 'فعال‌سازی موقعیت';

  @override
  String get location_required =>
      'برای دریافت اوقات نماز دقیق، موقعیت را فعال کنید';

  @override
  String get location_success => 'موقعیت شما دریافت شد';

  @override
  String get enable_notification => 'فعال‌سازی اعلان‌ها';

  @override
  String get notification_desc => 'با یادآوری اذان وقت نماز را از دست ندهید';

  @override
  String get done => 'اتمام';

  @override
  String get skip => 'رد کردن';

  @override
  String get enable_location => 'اجازه موقعیت';

  @override
  String get see_prayer_times => 'دیدم تشکر';

  @override
  String get events_of_day => 'مناسبت‌های این روز';

  @override
  String get hijri => 'هجری';

  @override
  String get shamsi => 'شمسی';

  @override
  String get bookmark => 'ذخیره';

  @override
  String get reading => 'قرائت';

  @override
  String get continue_reading => 'ادامه قرائت';

  @override
  String get surah => 'سوره';

  @override
  String get juz => 'جزء';

  @override
  String get verse => 'آیه';

  @override
  String get font_size => 'اندازه قلم';

  @override
  String get theme => 'پوسته';

  @override
  String get language => 'زبان';

  @override
  String get dark_mode => 'حالت تاریک';

  @override
  String get light_mode => 'حالت روشن';

  @override
  String get welcome_title => 'سلام!\nبه هدایه خوش آمدید 🌙';

  @override
  String get welcome_goal_question =>
      'بیشتر می‌خواهید روی کدام هدف تمرکز کنید؟';

  @override
  String get welcome_goal_pray_consistently => 'نماز را پیوسته بخوانم';

  @override
  String get welcome_goal_read_more_quran => 'بیشتر قرآن بخوانم';

  @override
  String get welcome_description =>
      'یک دقیقه وقت بگذارید تا برنامه را تنظیم کنید و در نمازهایتان منظم بمانید.';

  @override
  String get welcome_start_button => 'بسم الله، شروع کنیم';

  @override
  String get onboarding_close => 'بستن';

  @override
  String get location_permission_denied_message =>
      'لطفاً مجوز موقعیت و GPS را فعال کنید';

  @override
  String get enable_notifications_and_finish => 'فعال‌سازی اعلان‌ها و اتمام';

  @override
  String get quran_read_tab => 'مطالعه';

  @override
  String get quran_progress_tab => 'پیشرفت من';

  @override
  String get quran_recents => 'اخیر';

  @override
  String get quran_sura_list => 'فهرست سوره‌ها';

  @override
  String get quran_juz_list => 'فهرست جزءها';

  @override
  String quran_view_label(Object type) {
    return 'نمایش: $type';
  }

  @override
  String get quran_view_sura => 'سوره';

  @override
  String get quran_view_juz => 'جزء';

  @override
  String quran_ayah_count(Object count) {
    return '$count آیه';
  }

  @override
  String quran_juz_header(Object number) {
    return 'جزء $number';
  }

  @override
  String quran_aya_short(Object number) {
    return 'آیه $number';
  }

  @override
  String get quran_khatam_tab => 'ختم';

  @override
  String get quran_juz_done => 'جزء تکمیل‌شده';

  @override
  String get quran_surah_done => 'سوره تکمیل‌شده';

  @override
  String get quran_complete_surah_message =>
      'برای نمایش این بخش، یک سوره را کامل کنید';

  @override
  String get quran_completed => '✓ تکمیل شد';

  @override
  String get quran_last_read => 'آخرین مطالعه';

  @override
  String get quran_no_reading_yet => 'هنوز چیزی نخوانده‌اید';

  @override
  String get quran_minute_read => 'دقیقه مطالعه';

  @override
  String get quran_reading_progress_title => 'پیشرفت مطالعه';

  @override
  String get quran_reading_progress_subtitle =>
      'پیشرفت بر اساس اسکرول برای سوره و جزء';

  @override
  String quran_surah_label(Object number) {
    return 'سوره $number';
  }

  @override
  String quran_juz_label(Object number) {
    return 'جزء $number';
  }

  @override
  String get quran_start_reading_progress =>
      'برای ثبت پیشرفت، مطالعه را شروع کنید';

  @override
  String get prayer_times_title => 'اوقات نماز';

  @override
  String get calendar_gregorian => 'میلادی';

  @override
  String get calendar_hijri => 'هجری';

  @override
  String get prayer_now => 'حالا';

  @override
  String get prayer_next => 'بعدی';

  @override
  String prayer_in(Object time) {
    return 'در $time';
  }

  @override
  String get prayer_completed_count => 'خوانده شد';

  @override
  String get prayer_now_badge => 'حالا';

  @override
  String get prayer_fajr_local => 'صبح';

  @override
  String get prayer_dhuhr_local => 'ظهر';

  @override
  String get prayer_asr_local => 'عصر';

  @override
  String get prayer_maghrib_local => 'مغرب';

  @override
  String get prayer_isha_local => 'عشاء';

  @override
  String time_hours_minutes(Object hours, Object minutes) {
    return '$hoursس $minutesد';
  }

  @override
  String time_minutes_seconds(Object minutes, Object seconds) {
    return '$minutesد $secondsث';
  }

  @override
  String get month_january => 'جنوری';

  @override
  String get month_february => 'فبروری';

  @override
  String get month_march => 'مارچ';

  @override
  String get month_april => 'اپریل';

  @override
  String get month_may => 'می';

  @override
  String get month_june => 'جون';

  @override
  String get month_july => 'جولای';

  @override
  String get month_august => 'آگست';

  @override
  String get month_september => 'سپتامبر';

  @override
  String get month_october => 'اکتبر';

  @override
  String get month_november => 'نوامبر';

  @override
  String get month_december => 'دسامبر';

  @override
  String get weekday_short_sat => 'ش';

  @override
  String get weekday_short_sun => 'ی';

  @override
  String get weekday_short_mon => 'د';

  @override
  String get weekday_short_tue => 'س';

  @override
  String get weekday_short_wed => 'چ';

  @override
  String get weekday_short_thu => 'پ';

  @override
  String get weekday_short_fri => 'ج';

  @override
  String get hijri_muharram => 'محرم';

  @override
  String get hijri_safar => 'صفر';

  @override
  String get hijri_rabi_al_awwal => 'ربیع الاول';

  @override
  String get hijri_rabi_al_thani => 'ربیع الثانی';

  @override
  String get hijri_jumada_al_awwal => 'جمادی الاول';

  @override
  String get hijri_jumada_al_thani => 'جمادی الثانی';

  @override
  String get hijri_rajab => 'رجب';

  @override
  String get hijri_shaban => 'شعبان';

  @override
  String get hijri_ramadan => 'رمضان';

  @override
  String get hijri_shawwal => 'شوال';

  @override
  String get hijri_dhul_qadah => 'ذالقعده';

  @override
  String get hijri_dhul_hijjah => 'ذالحجه';

  @override
  String get tasbih_title => 'تسبیح';

  @override
  String get tasbih_reset => 'بازنشانی';

  @override
  String tasbih_total(Object count) {
    return 'مجموع: $count';
  }

  @override
  String get tasbih_tap_hint => 'برای شمارش ضربه بزنید';

  @override
  String get qibla_title => 'قبله‌نما';

  @override
  String get qibla_coming_desc =>
      'این بخش در حال توسعه است و در نسخه بعدی برنامه در دسترس قرار خواهد گرفت.';

  @override
  String get coming_soon => 'به زودی';

  @override
  String get duas_title => 'دعاها';

  @override
  String get dua_category_morning => 'صبح';

  @override
  String get dua_category_night => 'شب';

  @override
  String get dua_category_prayer => 'نماز';

  @override
  String get dua_category_istighfar => 'استغفار';

  @override
  String get dua_category_family => 'خانواده';

  @override
  String get dua_category_trust => 'توکل';

  @override
  String get dua_title_morning => 'دعای صباح';

  @override
  String get dua_title_before_sleep => 'دعای قبل از خواب';

  @override
  String get dua_title_after_prayer => 'دعای بعد از نماز';

  @override
  String get dua_title_istighfar => 'دعای استغفار';

  @override
  String get dua_title_parents => 'دعای برای والدین';

  @override
  String get dua_title_trust => 'دعای توکل';

  @override
  String get khatam_title => 'ختم قرآن';

  @override
  String khatam_completed_percent(Object percent) {
    return '$percent% کامل شده';
  }

  @override
  String get today_features_title => 'ویژگی‌ها';

  @override
  String get today_assistant_tools => 'ابزارهای کمکی شما';

  @override
  String get today_monthly_deeds_title => 'اعمال ماه';

  @override
  String get today_monthly_deeds_subtitle => 'فضایل و اعمال این ماه';

  @override
  String get today_now => 'حالا';

  @override
  String get today_next => 'بعدی';

  @override
  String today_in_hours_minutes(Object hours, Object minutes) {
    return 'در $hoursس $minutesد';
  }

  @override
  String today_in_minutes_seconds(Object minutes, Object seconds) {
    return 'در $minutesد $secondsث';
  }

  @override
  String get settings_notifications_section => 'اعلان‌ها';

  @override
  String get settings_reading_section => 'قرائت';

  @override
  String get settings_app_language_section => 'زبان برنامه';

  @override
  String get settings_allow_notifications => 'اجازه اعلان‌ها';

  @override
  String get settings_auto_scroll => 'پیمایش خودکار';

  @override
  String get settings_font_size => 'اندازه فونت';

  @override
  String get settings_language_english => 'English';

  @override
  String get settings_language_dari => 'دری / فارسی';

  @override
  String get monthly_deeds_rajab_title => 'اعمال ماه رجب';

  @override
  String get monthly_deeds_rajab_deed_1 => 'روزه گرفتن در روزهای مستحب';

  @override
  String get monthly_deeds_rajab_deed_2 => 'خواندن دعای یا من ارجوه';

  @override
  String get monthly_deeds_rajab_deed_3 => 'استغفار زیاد';

  @override
  String get monthly_deeds_shaban_title => 'اعمال ماه شعبان';

  @override
  String get monthly_deeds_shaban_deed_1 => 'صلوات شعبانیه';

  @override
  String get monthly_deeds_shaban_deed_2 => 'روزه مستحب';

  @override
  String get monthly_deeds_shaban_deed_3 => 'صدقه دادن';

  @override
  String get monthly_deeds_ramadan_title => 'اعمال ماه رمضان';

  @override
  String get monthly_deeds_ramadan_deed_1 => 'روزه گرفتن';

  @override
  String get monthly_deeds_ramadan_deed_2 => 'تلاوت قرآن';

  @override
  String get monthly_deeds_ramadan_deed_3 => 'دعای افتتاح';

  @override
  String get monthly_deeds_ramadan_deed_4 => 'احیای شب‌های قدر';

  @override
  String get weekday_saturday => 'شنبه';

  @override
  String get day_name_saturday => 'اعمال روز شنبه';

  @override
  String get weekday_letter_saturday => 'ش';

  @override
  String get weekday_sunday => 'یکشنبه';

  @override
  String get day_name_sunday => 'اعمال روز یکشنبه';

  @override
  String get weekday_letter_sunday => 'ی';

  @override
  String get weekday_monday => 'دوشنبه';

  @override
  String get day_name_monday => 'اعمال روز دوشنبه';

  @override
  String get weekday_letter_monday => 'د';

  @override
  String get weekday_tuesday => 'سه‌شنبه';

  @override
  String get day_name_tuesday => 'اعمال روز سه‌شنبه';

  @override
  String get weekday_letter_tuesday => 'س';

  @override
  String get weekday_wednesday => 'چهارشنبه';

  @override
  String get day_name_wednesday => 'اعمال روز چهارشنبه';

  @override
  String get weekday_letter_wednesday => 'چ';

  @override
  String get weekday_thursday => 'پنج‌شنبه';

  @override
  String get day_name_thursday => 'اعمال روز پنج‌شنبه';

  @override
  String get weekday_letter_thursday => 'پ';

  @override
  String get weekday_friday => 'جمعه';

  @override
  String get day_name_friday => 'اعمال روز جمعه';

  @override
  String get weekday_letter_friday => 'ج';

  @override
  String get story_sat_1_title => 'خواندن سوره کهف';

  @override
  String get story_sat_1_translation =>
      'ستایش خداوندی را که این کتاب را بر بنده‌اش نازل کرد و هیچ کجی در آن قرار نداد.';

  @override
  String get story_sat_2_title => 'دعای روز شنبه';

  @override
  String get story_sat_2_translation =>
      'پروردگارا، از نزد خود به ما رحمت عطا کن و کار ما را به راه راست هدایت فرما.';

  @override
  String get story_sat_3_title => 'اقامه نمازهای پنج‌گانه';

  @override
  String get story_sat_3_translation =>
      'نماز را از زوال آفتاب تا تاریکی شب و نماز صبح به پا دار.';

  @override
  String get story_sat_4_title => 'صدقه دادن در روز شنبه';

  @override
  String get story_sat_4_translation =>
      'نماز به پا دارید و زکات بدهید و با رکوع‌کنندگان رکوع کنید.';

  @override
  String get story_sat_5_title => 'استغفار و توبه';

  @override
  String get story_sat_5_translation =>
      'پس پروردگارت را تسبیح و حمد گو و از او آمرزش بخواه که او همواره توبه‌پذیر است.';

  @override
  String get story_sun_1_title => 'دعا و مناجات در یکشنبه';

  @override
  String get story_sun_1_translation =>
      'و چون بندگانم از تو درباره من بپرسند، بگو من نزدیکم. دعای دعاکننده را اجابت می‌کنم.';

  @override
  String get story_sun_2_title => 'ذکر و تسبیح';

  @override
  String get story_sun_2_translation =>
      'آگاه باشید که تنها با یاد خدا دل‌ها آرامش می‌یابد.';

  @override
  String get story_sun_3_title => 'روزه مستحبی یکشنبه';

  @override
  String get story_sun_3_translation =>
      'ای کسانی که ایمان آورده‌اید، روزه بر شما واجب شده است همان‌گونه که بر پیشینیان واجب شده بود.';

  @override
  String get story_sun_4_title => 'تلاوت قرآن کریم';

  @override
  String get story_sun_4_translation =>
      'این قرآن به راهی که استوارترین راه‌هاست هدایت می‌کند.';

  @override
  String get story_sun_5_title => 'صلوات بر پیامبر';

  @override
  String get story_sun_5_translation =>
      'خداوند و فرشتگانش بر پیامبر درود می‌فرستند. ای مؤمنان شما نیز بر او درود و سلام بفرستید.';

  @override
  String get story_mon_1_title => 'شتاب در اعمال خیر';

  @override
  String get story_mon_1_translation =>
      'و بشتابید به سوی مغفرت پروردگارتان و بهشتی که پهنایش آسمان‌ها و زمین است.';

  @override
  String get story_mon_2_title => 'حمد و شکر خداوند';

  @override
  String get story_mon_2_translation =>
      'ستایش مخصوص خداوند پروردگار جهانیان است.';

  @override
  String get story_mon_3_title => 'توبه و استغفار دوشنبه';

  @override
  String get story_mon_3_translation =>
      'همانا خداوند توبه‌کاران و پاکیزگان را دوست دارد.';

  @override
  String get story_mon_4_title => 'صداقت و راستی';

  @override
  String get story_mon_4_translation =>
      'ای مؤمنان، تقوای خدا پیشه کنید و با راستگویان باشید.';

  @override
  String get story_mon_5_title => 'انفاق در راه خدا';

  @override
  String get story_mon_5_translation =>
      'و کسانی که در اموالشان حق معلومی برای سائل و محروم است.';

  @override
  String get story_tue_1_title => 'صبر و شکیبایی';

  @override
  String get story_tue_1_translation =>
      'خداوند هیچ کس را جز به اندازه توانش تکلیف نمی‌کند. آنچه کسب کرده به سودش و آنچه مرتکب شده به زیانش است.';

  @override
  String get story_tue_2_title => 'قرائت سوره اخلاص';

  @override
  String get story_tue_2_translation =>
      'بگو خداوند یکتاست، خداوند بی‌نیاز است.';

  @override
  String get story_tue_3_title => 'تواضع و فروتنی';

  @override
  String get story_tue_3_translation =>
      'بندگان خداوند رحمان کسانی‌اند که با فروتنی بر زمین راه می‌روند.';

  @override
  String get story_tue_4_title => 'صبر و استقامت';

  @override
  String get story_tue_4_translation => 'همانا خداوند با صابران است.';

  @override
  String get story_tue_5_title => 'توکل به خداوند';

  @override
  String get story_tue_5_translation =>
      'و هر که بر خدا توکل کند خدا او را کافی است. همانا خداوند به فرمانش دست می‌یابد.';

  @override
  String get story_wed_1_title => 'شکرگزاری از نعمت‌های الهی';

  @override
  String get story_wed_1_translation =>
      'پس کدامین نعمت‌های پروردگارتان را انکار می‌کنید؟';

  @override
  String get story_wed_2_title => 'عمل نیک در چهارشنبه';

  @override
  String get story_wed_2_translation =>
      'هر که کار نیکی انجام دهد ده برابر پاداش خواهد داشت.';

  @override
  String get story_wed_3_title => 'برادری و اصلاح ذات البین';

  @override
  String get story_wed_3_translation =>
      'مؤمنان برادر یکدیگرند، پس میان برادرانتان صلح برقرار کنید.';

  @override
  String get story_wed_4_title => 'طلب علم و دانش';

  @override
  String get story_wed_4_translation => 'و بگو پروردگارا بر علمم بیفزا.';

  @override
  String get story_wed_5_title => 'دعا و نیایش';

  @override
  String get story_wed_5_translation =>
      'و پروردگارتان فرمود مرا بخوانید تا اجابت کنم.';

  @override
  String get story_thu_1_title => 'تسبیح خداوند';

  @override
  String get story_thu_1_translation =>
      'پس منزه است آنکه فرمانروایی همه چیز در دست اوست و به سوی او بازمی‌گردید.';

  @override
  String get story_thu_2_title => 'آمادگی برای نماز جمعه';

  @override
  String get story_thu_2_translation =>
      'ای مؤمنان، هنگامی که روز جمعه برای نماز ندا داده شد به ذکر خدا بشتابید.';

  @override
  String get story_thu_3_title => 'نماز شب پنج‌شنبه';

  @override
  String get story_thu_3_translation =>
      'و پاسی از شب را بیدار باش و نماز شب بگزار که این برای تو فریضه‌ای اضافه است.';

  @override
  String get story_thu_4_title => 'عبادت و بندگی خالص';

  @override
  String get story_thu_4_translation =>
      'جن و انس را نیافریدم مگر برای اینکه مرا عبادت کنند.';

  @override
  String get story_thu_5_title => 'امید به رحمت الهی';

  @override
  String get story_thu_5_translation =>
      'بگو ای بندگان من که بر خود اسراف کرده‌اید از رحمت خداوند ناامید نشوید.';

  @override
  String get story_fri_1_title => 'نماز جمعه و طلب رزق';

  @override
  String get story_fri_1_translation =>
      'پس چون نماز گزارده شد در زمین پراکنده شوید و فضل خداوند را بجویید.';

  @override
  String get story_fri_2_title => 'خواندن سوره کهف در جمعه';

  @override
  String get story_fri_2_translation =>
      'ستایش خداوندی را که این کتاب را بر بنده‌اش نازل کرد و هیچ کجی در آن قرار نداد.';

  @override
  String get story_fri_3_title => 'کثرت صلوات در جمعه';

  @override
  String get story_fri_3_translation =>
      'خداوند و فرشتگانش بر پیامبر درود می‌فرستند. ای مؤمنان شما نیز بر او درود بفرستید.';

  @override
  String get story_fri_4_title => 'صدقه جمعه';

  @override
  String get story_fri_4_translation =>
      'از اموالشان صدقه بگیر تا آنان را پاک سازی و رشد دهی.';

  @override
  String get story_fri_5_title => 'دعا و تقرب به خداوند';

  @override
  String get story_fri_5_translation =>
      'ای مؤمنان تقوای الهی پیشه کنید و وسیله‌ای برای تقرب به او بجویید.';

  @override
  String get story_fri_6_title => 'احیاء شب جمعه';

  @override
  String get story_fri_6_translation =>
      'ما آن را در شبی مبارک نازل کردیم و ما هشداردهنده بودیم.';

  @override
  String get amal_adia => 'ادعیه و اعمال';

  @override
  String get search_by_type_title => 'جستجو بر اساس';

  @override
  String get search_surah_short => 'سوره';

  @override
  String get search_ayah_short => 'آیه';

  @override
  String get search_ayah_example => 'مثال: ۲:۲۵۵ یا الله';

  @override
  String get search_enter_surah_name => 'نام سوره را وارد کنید';

  @override
  String get search_enter_ayah_text_or_number =>
      'آیه، متن یا شماره را وارد کنید';

  @override
  String get search_go_to_ayah => 'برو به آیه';

  @override
  String search_no_result_for(Object query) {
    return 'نتیجه‌ای برای \"$query\" نیافتیم';
  }

  @override
  String get search_ayah_filter_subtitle => 'متن آیه یا شماره (مثال: ۲:۲۵۵)';

  @override
  String get exit_app_message => 'برای خروج، دوباره دکمه برگشت را فشار دهید';
}
