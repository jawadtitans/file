import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_fa.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('fa'),
  ];

  /// No description provided for @splash_text.
  ///
  /// In en, this message translates to:
  /// **'Hedaya'**
  String get splash_text;

  /// No description provided for @header_date.
  ///
  /// In en, this message translates to:
  /// **'Today\'s Date'**
  String get header_date;

  /// No description provided for @header_location.
  ///
  /// In en, this message translates to:
  /// **'Your Location'**
  String get header_location;

  /// No description provided for @header_time.
  ///
  /// In en, this message translates to:
  /// **'Time'**
  String get header_time;

  /// No description provided for @header_fajr.
  ///
  /// In en, this message translates to:
  /// **'Time remaining until Fajr'**
  String get header_fajr;

  /// No description provided for @al_quran.
  ///
  /// In en, this message translates to:
  /// **'Al-Quran'**
  String get al_quran;

  /// No description provided for @tab_surah.
  ///
  /// In en, this message translates to:
  /// **'Surah'**
  String get tab_surah;

  /// No description provided for @tab_juz.
  ///
  /// In en, this message translates to:
  /// **'Juz'**
  String get tab_juz;

  /// No description provided for @tab_Ayah.
  ///
  /// In en, this message translates to:
  /// **'Ayah'**
  String get tab_Ayah;

  /// No description provided for @no_surahs.
  ///
  /// In en, this message translates to:
  /// **'No Surahs Found'**
  String get no_surahs;

  /// No description provided for @no_ayah.
  ///
  /// In en, this message translates to:
  /// **'No saved Ayah yet'**
  String get no_ayah;

  /// No description provided for @no_surah.
  ///
  /// In en, this message translates to:
  /// **'No saved Surah yet'**
  String get no_surah;

  /// No description provided for @no_juz.
  ///
  /// In en, this message translates to:
  /// **'No saved Juz yet'**
  String get no_juz;

  /// No description provided for @bookmar_title.
  ///
  /// In en, this message translates to:
  /// **'Bookmarks'**
  String get bookmar_title;

  /// No description provided for @today_zikr.
  ///
  /// In en, this message translates to:
  /// **'Today\'s Zikr'**
  String get today_zikr;

  /// No description provided for @nav_home.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get nav_home;

  /// No description provided for @nav_Quran.
  ///
  /// In en, this message translates to:
  /// **'Quran'**
  String get nav_Quran;

  /// No description provided for @nav_prayer.
  ///
  /// In en, this message translates to:
  /// **'Prayer Times'**
  String get nav_prayer;

  /// No description provided for @nav_islam.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get nav_islam;

  /// No description provided for @nav_search.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get nav_search;

  /// No description provided for @nav_settings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get nav_settings;

  /// No description provided for @search_hint.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get search_hint;

  /// No description provided for @no_results.
  ///
  /// In en, this message translates to:
  /// **'No results found'**
  String get no_results;

  /// No description provided for @settings_title.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settings_title;

  /// No description provided for @recent_downloads.
  ///
  /// In en, this message translates to:
  /// **'Recent Downloads'**
  String get recent_downloads;

  /// No description provided for @share_apps.
  ///
  /// In en, this message translates to:
  /// **'Share App'**
  String get share_apps;

  /// No description provided for @my_network.
  ///
  /// In en, this message translates to:
  /// **'My Network'**
  String get my_network;

  /// No description provided for @payments.
  ///
  /// In en, this message translates to:
  /// **'Payments'**
  String get payments;

  /// No description provided for @support.
  ///
  /// In en, this message translates to:
  /// **'Sounds'**
  String get support;

  /// No description provided for @allow_notifications.
  ///
  /// In en, this message translates to:
  /// **'Allow Notifications'**
  String get allow_notifications;

  /// No description provided for @auto_scroll.
  ///
  /// In en, this message translates to:
  /// **'Auto Scroll During Recitation'**
  String get auto_scroll;

  /// No description provided for @preview_text.
  ///
  /// In en, this message translates to:
  /// **'Preview Text'**
  String get preview_text;

  /// No description provided for @quran_font_size.
  ///
  /// In en, this message translates to:
  /// **'Quran Font Size'**
  String get quran_font_size;

  /// No description provided for @account_admin.
  ///
  /// In en, this message translates to:
  /// **'Account Admin'**
  String get account_admin;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @quran_app.
  ///
  /// In en, this message translates to:
  /// **'Quran Mobile App'**
  String get quran_app;

  /// No description provided for @share.
  ///
  /// In en, this message translates to:
  /// **'Share App'**
  String get share;

  /// No description provided for @about_app.
  ///
  /// In en, this message translates to:
  /// **'About App'**
  String get about_app;

  /// No description provided for @filter.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get filter;

  /// No description provided for @search_ayah.
  ///
  /// In en, this message translates to:
  /// **'Search by Ayah'**
  String get search_ayah;

  /// No description provided for @search_surah.
  ///
  /// In en, this message translates to:
  /// **'Search by Surah'**
  String get search_surah;

  /// No description provided for @search_surah_subtitle.
  ///
  /// In en, this message translates to:
  /// **'Search for a Surah by its name'**
  String get search_surah_subtitle;

  /// No description provided for @search_ayah_subtitle.
  ///
  /// In en, this message translates to:
  /// **'Search for an Ayah by its text'**
  String get search_ayah_subtitle;

  /// No description provided for @prayer_times.
  ///
  /// In en, this message translates to:
  /// **'Prayer Times'**
  String get prayer_times;

  /// No description provided for @fajr.
  ///
  /// In en, this message translates to:
  /// **'Fajr'**
  String get fajr;

  /// No description provided for @sunrise.
  ///
  /// In en, this message translates to:
  /// **'Sunrise'**
  String get sunrise;

  /// No description provided for @dhuhr.
  ///
  /// In en, this message translates to:
  /// **'Dhuhr'**
  String get dhuhr;

  /// No description provided for @asr.
  ///
  /// In en, this message translates to:
  /// **'Asr'**
  String get asr;

  /// No description provided for @maghrib.
  ///
  /// In en, this message translates to:
  /// **'Maghrib'**
  String get maghrib;

  /// No description provided for @isha.
  ///
  /// In en, this message translates to:
  /// **'Isha\'a'**
  String get isha;

  /// No description provided for @now.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get now;

  /// No description provided for @next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get next;

  /// No description provided for @upcoming.
  ///
  /// In en, this message translates to:
  /// **'Upcoming'**
  String get upcoming;

  /// No description provided for @location_permission.
  ///
  /// In en, this message translates to:
  /// **'Enable Location'**
  String get location_permission;

  /// No description provided for @location_required.
  ///
  /// In en, this message translates to:
  /// **'Location is required for accurate prayer times'**
  String get location_required;

  /// No description provided for @location_success.
  ///
  /// In en, this message translates to:
  /// **'Location acquired'**
  String get location_success;

  /// No description provided for @enable_notification.
  ///
  /// In en, this message translates to:
  /// **'Enable Notifications'**
  String get enable_notification;

  /// No description provided for @notification_desc.
  ///
  /// In en, this message translates to:
  /// **'Don\'t miss prayer time with Adhan reminders'**
  String get notification_desc;

  /// No description provided for @done.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get done;

  /// No description provided for @skip.
  ///
  /// In en, this message translates to:
  /// **'Skip'**
  String get skip;

  /// No description provided for @enable_location.
  ///
  /// In en, this message translates to:
  /// **'Enable Location'**
  String get enable_location;

  /// No description provided for @see_prayer_times.
  ///
  /// In en, this message translates to:
  /// **'See Prayer Times'**
  String get see_prayer_times;

  /// No description provided for @events_of_day.
  ///
  /// In en, this message translates to:
  /// **'Events of This Day'**
  String get events_of_day;

  /// No description provided for @hijri.
  ///
  /// In en, this message translates to:
  /// **'Hijri'**
  String get hijri;

  /// No description provided for @shamsi.
  ///
  /// In en, this message translates to:
  /// **'Shamsi'**
  String get shamsi;

  /// No description provided for @bookmark.
  ///
  /// In en, this message translates to:
  /// **'Bookmark'**
  String get bookmark;

  /// No description provided for @reading.
  ///
  /// In en, this message translates to:
  /// **'Reading'**
  String get reading;

  /// No description provided for @continue_reading.
  ///
  /// In en, this message translates to:
  /// **'Continue Reading'**
  String get continue_reading;

  /// No description provided for @surah.
  ///
  /// In en, this message translates to:
  /// **'Surah'**
  String get surah;

  /// No description provided for @juz.
  ///
  /// In en, this message translates to:
  /// **'Juz'**
  String get juz;

  /// No description provided for @verse.
  ///
  /// In en, this message translates to:
  /// **'Verse'**
  String get verse;

  /// No description provided for @font_size.
  ///
  /// In en, this message translates to:
  /// **'Font Size'**
  String get font_size;

  /// No description provided for @theme.
  ///
  /// In en, this message translates to:
  /// **'Theme'**
  String get theme;

  /// No description provided for @language.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get language;

  /// No description provided for @dark_mode.
  ///
  /// In en, this message translates to:
  /// **'Dark Mode'**
  String get dark_mode;

  /// No description provided for @light_mode.
  ///
  /// In en, this message translates to:
  /// **'Light Mode'**
  String get light_mode;

  /// No description provided for @welcome_title.
  ///
  /// In en, this message translates to:
  /// **'Salaam !\nWelcome to Hedaya 🌙'**
  String get welcome_title;

  /// No description provided for @welcome_goal_question.
  ///
  /// In en, this message translates to:
  /// **'What is your Goal to More Focus on?'**
  String get welcome_goal_question;

  /// No description provided for @welcome_goal_pray_consistently.
  ///
  /// In en, this message translates to:
  /// **'Pray consistently'**
  String get welcome_goal_pray_consistently;

  /// No description provided for @welcome_goal_read_more_quran.
  ///
  /// In en, this message translates to:
  /// **'Read more Quran'**
  String get welcome_goal_read_more_quran;

  /// No description provided for @welcome_description.
  ///
  /// In en, this message translates to:
  /// **'Take a minute to Personalize your app and stay on track with your prayers and Allah.'**
  String get welcome_description;

  /// No description provided for @welcome_start_button.
  ///
  /// In en, this message translates to:
  /// **'Bismillah, let\'s start'**
  String get welcome_start_button;

  /// No description provided for @onboarding_close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get onboarding_close;

  /// No description provided for @location_permission_denied_message.
  ///
  /// In en, this message translates to:
  /// **'Please enable location permission and GPS'**
  String get location_permission_denied_message;

  /// No description provided for @enable_notifications_and_finish.
  ///
  /// In en, this message translates to:
  /// **'Enable Notifications and Finish'**
  String get enable_notifications_and_finish;

  /// No description provided for @quran_read_tab.
  ///
  /// In en, this message translates to:
  /// **'Read'**
  String get quran_read_tab;

  /// No description provided for @quran_progress_tab.
  ///
  /// In en, this message translates to:
  /// **'My Progress'**
  String get quran_progress_tab;

  /// No description provided for @quran_recents.
  ///
  /// In en, this message translates to:
  /// **'Recents'**
  String get quran_recents;

  /// No description provided for @quran_sura_list.
  ///
  /// In en, this message translates to:
  /// **'Sura list'**
  String get quran_sura_list;

  /// No description provided for @quran_juz_list.
  ///
  /// In en, this message translates to:
  /// **'Juz list'**
  String get quran_juz_list;

  /// No description provided for @quran_view_label.
  ///
  /// In en, this message translates to:
  /// **'View: {type}'**
  String quran_view_label(Object type);

  /// No description provided for @quran_view_sura.
  ///
  /// In en, this message translates to:
  /// **'Sura'**
  String get quran_view_sura;

  /// No description provided for @quran_view_juz.
  ///
  /// In en, this message translates to:
  /// **'Juz'**
  String get quran_view_juz;

  /// No description provided for @quran_ayah_count.
  ///
  /// In en, this message translates to:
  /// **'{count} Ayah'**
  String quran_ayah_count(Object count);

  /// No description provided for @quran_juz_header.
  ///
  /// In en, this message translates to:
  /// **'Juz {number}'**
  String quran_juz_header(Object number);

  /// No description provided for @quran_aya_short.
  ///
  /// In en, this message translates to:
  /// **'Aya {number}'**
  String quran_aya_short(Object number);

  /// No description provided for @quran_khatam_tab.
  ///
  /// In en, this message translates to:
  /// **'Khatam'**
  String get quran_khatam_tab;

  /// No description provided for @quran_juz_done.
  ///
  /// In en, this message translates to:
  /// **'Juz done'**
  String get quran_juz_done;

  /// No description provided for @quran_surah_done.
  ///
  /// In en, this message translates to:
  /// **'Surah done'**
  String get quran_surah_done;

  /// No description provided for @quran_complete_surah_message.
  ///
  /// In en, this message translates to:
  /// **'Complete a Surah to see it here'**
  String get quran_complete_surah_message;

  /// No description provided for @quran_completed.
  ///
  /// In en, this message translates to:
  /// **'✓ Completed'**
  String get quran_completed;

  /// No description provided for @quran_last_read.
  ///
  /// In en, this message translates to:
  /// **'Last read'**
  String get quran_last_read;

  /// No description provided for @quran_no_reading_yet.
  ///
  /// In en, this message translates to:
  /// **'No reading yet'**
  String get quran_no_reading_yet;

  /// No description provided for @quran_minute_read.
  ///
  /// In en, this message translates to:
  /// **'minute read'**
  String get quran_minute_read;

  /// No description provided for @quran_reading_progress_title.
  ///
  /// In en, this message translates to:
  /// **'Reading Progress'**
  String get quran_reading_progress_title;

  /// No description provided for @quran_reading_progress_subtitle.
  ///
  /// In en, this message translates to:
  /// **'Scroll-based progress per Surah & Juz'**
  String get quran_reading_progress_subtitle;

  /// No description provided for @quran_surah_label.
  ///
  /// In en, this message translates to:
  /// **'Surah {number}'**
  String quran_surah_label(Object number);

  /// No description provided for @quran_juz_label.
  ///
  /// In en, this message translates to:
  /// **'Juz {number}'**
  String quran_juz_label(Object number);

  /// No description provided for @quran_start_reading_progress.
  ///
  /// In en, this message translates to:
  /// **'Start reading to track progress'**
  String get quran_start_reading_progress;

  /// No description provided for @prayer_times_title.
  ///
  /// In en, this message translates to:
  /// **'Prayer Times'**
  String get prayer_times_title;

  /// No description provided for @calendar_gregorian.
  ///
  /// In en, this message translates to:
  /// **'Gregorian'**
  String get calendar_gregorian;

  /// No description provided for @calendar_hijri.
  ///
  /// In en, this message translates to:
  /// **'Hijri'**
  String get calendar_hijri;

  /// No description provided for @prayer_now.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get prayer_now;

  /// No description provided for @prayer_next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get prayer_next;

  /// No description provided for @prayer_in.
  ///
  /// In en, this message translates to:
  /// **'In {time}'**
  String prayer_in(Object time);

  /// No description provided for @prayer_completed_count.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get prayer_completed_count;

  /// No description provided for @prayer_now_badge.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get prayer_now_badge;

  /// No description provided for @prayer_fajr_local.
  ///
  /// In en, this message translates to:
  /// **'Fajr'**
  String get prayer_fajr_local;

  /// No description provided for @prayer_dhuhr_local.
  ///
  /// In en, this message translates to:
  /// **'Dhuhr'**
  String get prayer_dhuhr_local;

  /// No description provided for @prayer_asr_local.
  ///
  /// In en, this message translates to:
  /// **'Asr'**
  String get prayer_asr_local;

  /// No description provided for @prayer_maghrib_local.
  ///
  /// In en, this message translates to:
  /// **'Maghrib'**
  String get prayer_maghrib_local;

  /// No description provided for @prayer_isha_local.
  ///
  /// In en, this message translates to:
  /// **'Isha'**
  String get prayer_isha_local;

  /// No description provided for @time_hours_minutes.
  ///
  /// In en, this message translates to:
  /// **'{hours}h {minutes}m'**
  String time_hours_minutes(Object hours, Object minutes);

  /// No description provided for @time_minutes_seconds.
  ///
  /// In en, this message translates to:
  /// **'{minutes}m {seconds}s'**
  String time_minutes_seconds(Object minutes, Object seconds);

  /// No description provided for @month_january.
  ///
  /// In en, this message translates to:
  /// **'January'**
  String get month_january;

  /// No description provided for @month_february.
  ///
  /// In en, this message translates to:
  /// **'February'**
  String get month_february;

  /// No description provided for @month_march.
  ///
  /// In en, this message translates to:
  /// **'March'**
  String get month_march;

  /// No description provided for @month_april.
  ///
  /// In en, this message translates to:
  /// **'April'**
  String get month_april;

  /// No description provided for @month_may.
  ///
  /// In en, this message translates to:
  /// **'May'**
  String get month_may;

  /// No description provided for @month_june.
  ///
  /// In en, this message translates to:
  /// **'June'**
  String get month_june;

  /// No description provided for @month_july.
  ///
  /// In en, this message translates to:
  /// **'July'**
  String get month_july;

  /// No description provided for @month_august.
  ///
  /// In en, this message translates to:
  /// **'August'**
  String get month_august;

  /// No description provided for @month_september.
  ///
  /// In en, this message translates to:
  /// **'September'**
  String get month_september;

  /// No description provided for @month_october.
  ///
  /// In en, this message translates to:
  /// **'October'**
  String get month_october;

  /// No description provided for @month_november.
  ///
  /// In en, this message translates to:
  /// **'November'**
  String get month_november;

  /// No description provided for @month_december.
  ///
  /// In en, this message translates to:
  /// **'December'**
  String get month_december;

  /// No description provided for @weekday_short_sat.
  ///
  /// In en, this message translates to:
  /// **'S'**
  String get weekday_short_sat;

  /// No description provided for @weekday_short_sun.
  ///
  /// In en, this message translates to:
  /// **'S'**
  String get weekday_short_sun;

  /// No description provided for @weekday_short_mon.
  ///
  /// In en, this message translates to:
  /// **'M'**
  String get weekday_short_mon;

  /// No description provided for @weekday_short_tue.
  ///
  /// In en, this message translates to:
  /// **'T'**
  String get weekday_short_tue;

  /// No description provided for @weekday_short_wed.
  ///
  /// In en, this message translates to:
  /// **'W'**
  String get weekday_short_wed;

  /// No description provided for @weekday_short_thu.
  ///
  /// In en, this message translates to:
  /// **'T'**
  String get weekday_short_thu;

  /// No description provided for @weekday_short_fri.
  ///
  /// In en, this message translates to:
  /// **'F'**
  String get weekday_short_fri;

  /// No description provided for @hijri_muharram.
  ///
  /// In en, this message translates to:
  /// **'Muharram'**
  String get hijri_muharram;

  /// No description provided for @hijri_safar.
  ///
  /// In en, this message translates to:
  /// **'Safar'**
  String get hijri_safar;

  /// No description provided for @hijri_rabi_al_awwal.
  ///
  /// In en, this message translates to:
  /// **'Rabi al-Awwal'**
  String get hijri_rabi_al_awwal;

  /// No description provided for @hijri_rabi_al_thani.
  ///
  /// In en, this message translates to:
  /// **'Rabi al-Thani'**
  String get hijri_rabi_al_thani;

  /// No description provided for @hijri_jumada_al_awwal.
  ///
  /// In en, this message translates to:
  /// **'Jumada al-Awwal'**
  String get hijri_jumada_al_awwal;

  /// No description provided for @hijri_jumada_al_thani.
  ///
  /// In en, this message translates to:
  /// **'Jumada al-Thani'**
  String get hijri_jumada_al_thani;

  /// No description provided for @hijri_rajab.
  ///
  /// In en, this message translates to:
  /// **'Rajab'**
  String get hijri_rajab;

  /// No description provided for @hijri_shaban.
  ///
  /// In en, this message translates to:
  /// **'Sha\'ban'**
  String get hijri_shaban;

  /// No description provided for @hijri_ramadan.
  ///
  /// In en, this message translates to:
  /// **'Ramadan'**
  String get hijri_ramadan;

  /// No description provided for @hijri_shawwal.
  ///
  /// In en, this message translates to:
  /// **'Shawwal'**
  String get hijri_shawwal;

  /// No description provided for @hijri_dhul_qadah.
  ///
  /// In en, this message translates to:
  /// **'Dhul-Qadah'**
  String get hijri_dhul_qadah;

  /// No description provided for @hijri_dhul_hijjah.
  ///
  /// In en, this message translates to:
  /// **'Dhul-Hijjah'**
  String get hijri_dhul_hijjah;

  /// No description provided for @tasbih_title.
  ///
  /// In en, this message translates to:
  /// **'Tasbih'**
  String get tasbih_title;

  /// No description provided for @tasbih_reset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get tasbih_reset;

  /// No description provided for @tasbih_total.
  ///
  /// In en, this message translates to:
  /// **'Total: {count}'**
  String tasbih_total(Object count);

  /// No description provided for @tasbih_tap_hint.
  ///
  /// In en, this message translates to:
  /// **'Tap to count'**
  String get tasbih_tap_hint;

  /// No description provided for @qibla_title.
  ///
  /// In en, this message translates to:
  /// **'Qibla Direction'**
  String get qibla_title;

  /// No description provided for @qibla_coming_desc.
  ///
  /// In en, this message translates to:
  /// **'This feature is under development and will be available in the next version.'**
  String get qibla_coming_desc;

  /// No description provided for @coming_soon.
  ///
  /// In en, this message translates to:
  /// **'Coming Soon'**
  String get coming_soon;

  /// No description provided for @duas_title.
  ///
  /// In en, this message translates to:
  /// **'Duas'**
  String get duas_title;

  /// No description provided for @dua_category_morning.
  ///
  /// In en, this message translates to:
  /// **'Morning'**
  String get dua_category_morning;

  /// No description provided for @dua_category_night.
  ///
  /// In en, this message translates to:
  /// **'Night'**
  String get dua_category_night;

  /// No description provided for @dua_category_prayer.
  ///
  /// In en, this message translates to:
  /// **'Prayer'**
  String get dua_category_prayer;

  /// No description provided for @dua_category_istighfar.
  ///
  /// In en, this message translates to:
  /// **'Istighfar'**
  String get dua_category_istighfar;

  /// No description provided for @dua_category_family.
  ///
  /// In en, this message translates to:
  /// **'Family'**
  String get dua_category_family;

  /// No description provided for @dua_category_trust.
  ///
  /// In en, this message translates to:
  /// **'Trust'**
  String get dua_category_trust;

  /// No description provided for @dua_title_morning.
  ///
  /// In en, this message translates to:
  /// **'Morning Dua'**
  String get dua_title_morning;

  /// No description provided for @dua_title_before_sleep.
  ///
  /// In en, this message translates to:
  /// **'Before Sleep Dua'**
  String get dua_title_before_sleep;

  /// No description provided for @dua_title_after_prayer.
  ///
  /// In en, this message translates to:
  /// **'After Prayer Dua'**
  String get dua_title_after_prayer;

  /// No description provided for @dua_title_istighfar.
  ///
  /// In en, this message translates to:
  /// **'Istighfar Dua'**
  String get dua_title_istighfar;

  /// No description provided for @dua_title_parents.
  ///
  /// In en, this message translates to:
  /// **'Dua for Parents'**
  String get dua_title_parents;

  /// No description provided for @dua_title_trust.
  ///
  /// In en, this message translates to:
  /// **'Dua of Trust'**
  String get dua_title_trust;

  /// No description provided for @khatam_title.
  ///
  /// In en, this message translates to:
  /// **'Khatam Quran'**
  String get khatam_title;

  /// No description provided for @khatam_completed_percent.
  ///
  /// In en, this message translates to:
  /// **'{percent}% completed'**
  String khatam_completed_percent(Object percent);

  /// No description provided for @today_features_title.
  ///
  /// In en, this message translates to:
  /// **'Features'**
  String get today_features_title;

  /// No description provided for @today_assistant_tools.
  ///
  /// In en, this message translates to:
  /// **'Your Assistant Tools'**
  String get today_assistant_tools;

  /// No description provided for @today_monthly_deeds_title.
  ///
  /// In en, this message translates to:
  /// **'Monthly Deeds'**
  String get today_monthly_deeds_title;

  /// No description provided for @today_monthly_deeds_subtitle.
  ///
  /// In en, this message translates to:
  /// **'Virtues and deeds of this month'**
  String get today_monthly_deeds_subtitle;

  /// No description provided for @today_now.
  ///
  /// In en, this message translates to:
  /// **'Now'**
  String get today_now;

  /// No description provided for @today_next.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get today_next;

  /// No description provided for @today_in_hours_minutes.
  ///
  /// In en, this message translates to:
  /// **'In {hours}h {minutes}m'**
  String today_in_hours_minutes(Object hours, Object minutes);

  /// No description provided for @today_in_minutes_seconds.
  ///
  /// In en, this message translates to:
  /// **'In {minutes}m {seconds}s'**
  String today_in_minutes_seconds(Object minutes, Object seconds);

  /// No description provided for @settings_notifications_section.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get settings_notifications_section;

  /// No description provided for @settings_reading_section.
  ///
  /// In en, this message translates to:
  /// **'Reading'**
  String get settings_reading_section;

  /// No description provided for @settings_app_language_section.
  ///
  /// In en, this message translates to:
  /// **'App Language'**
  String get settings_app_language_section;

  /// No description provided for @settings_allow_notifications.
  ///
  /// In en, this message translates to:
  /// **'Allow Notifications'**
  String get settings_allow_notifications;

  /// No description provided for @settings_auto_scroll.
  ///
  /// In en, this message translates to:
  /// **'Auto Scroll'**
  String get settings_auto_scroll;

  /// No description provided for @settings_font_size.
  ///
  /// In en, this message translates to:
  /// **'Font Size'**
  String get settings_font_size;

  /// No description provided for @settings_language_english.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get settings_language_english;

  /// No description provided for @settings_language_dari.
  ///
  /// In en, this message translates to:
  /// **'Dari / Farsi'**
  String get settings_language_dari;

  /// No description provided for @monthly_deeds_rajab_title.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Rajab'**
  String get monthly_deeds_rajab_title;

  /// No description provided for @monthly_deeds_rajab_deed_1.
  ///
  /// In en, this message translates to:
  /// **'Fasting on recommended days'**
  String get monthly_deeds_rajab_deed_1;

  /// No description provided for @monthly_deeds_rajab_deed_2.
  ///
  /// In en, this message translates to:
  /// **'Reciting the Dua Ya Man Arjuhu'**
  String get monthly_deeds_rajab_deed_2;

  /// No description provided for @monthly_deeds_rajab_deed_3.
  ///
  /// In en, this message translates to:
  /// **'Frequent Istighfar'**
  String get monthly_deeds_rajab_deed_3;

  /// No description provided for @monthly_deeds_shaban_title.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Sha\'ban'**
  String get monthly_deeds_shaban_title;

  /// No description provided for @monthly_deeds_shaban_deed_1.
  ///
  /// In en, this message translates to:
  /// **'Salawat Sha\'baniyyah'**
  String get monthly_deeds_shaban_deed_1;

  /// No description provided for @monthly_deeds_shaban_deed_2.
  ///
  /// In en, this message translates to:
  /// **'Recommended fasting'**
  String get monthly_deeds_shaban_deed_2;

  /// No description provided for @monthly_deeds_shaban_deed_3.
  ///
  /// In en, this message translates to:
  /// **'Giving charity'**
  String get monthly_deeds_shaban_deed_3;

  /// No description provided for @monthly_deeds_ramadan_title.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Ramadan'**
  String get monthly_deeds_ramadan_title;

  /// No description provided for @monthly_deeds_ramadan_deed_1.
  ///
  /// In en, this message translates to:
  /// **'Fasting'**
  String get monthly_deeds_ramadan_deed_1;

  /// No description provided for @monthly_deeds_ramadan_deed_2.
  ///
  /// In en, this message translates to:
  /// **'Reciting the Quran'**
  String get monthly_deeds_ramadan_deed_2;

  /// No description provided for @monthly_deeds_ramadan_deed_3.
  ///
  /// In en, this message translates to:
  /// **'Dua al-Iftitah'**
  String get monthly_deeds_ramadan_deed_3;

  /// No description provided for @monthly_deeds_ramadan_deed_4.
  ///
  /// In en, this message translates to:
  /// **'Reviving the Nights of Qadr'**
  String get monthly_deeds_ramadan_deed_4;

  /// No description provided for @weekday_saturday.
  ///
  /// In en, this message translates to:
  /// **'Saturday'**
  String get weekday_saturday;

  /// No description provided for @day_name_saturday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Saturday'**
  String get day_name_saturday;

  /// No description provided for @weekday_letter_saturday.
  ///
  /// In en, this message translates to:
  /// **'S'**
  String get weekday_letter_saturday;

  /// No description provided for @weekday_sunday.
  ///
  /// In en, this message translates to:
  /// **'Sunday'**
  String get weekday_sunday;

  /// No description provided for @day_name_sunday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Sunday'**
  String get day_name_sunday;

  /// No description provided for @weekday_letter_sunday.
  ///
  /// In en, this message translates to:
  /// **'S'**
  String get weekday_letter_sunday;

  /// No description provided for @weekday_monday.
  ///
  /// In en, this message translates to:
  /// **'Monday'**
  String get weekday_monday;

  /// No description provided for @day_name_monday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Monday'**
  String get day_name_monday;

  /// No description provided for @weekday_letter_monday.
  ///
  /// In en, this message translates to:
  /// **'M'**
  String get weekday_letter_monday;

  /// No description provided for @weekday_tuesday.
  ///
  /// In en, this message translates to:
  /// **'Tuesday'**
  String get weekday_tuesday;

  /// No description provided for @day_name_tuesday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Tuesday'**
  String get day_name_tuesday;

  /// No description provided for @weekday_letter_tuesday.
  ///
  /// In en, this message translates to:
  /// **'T'**
  String get weekday_letter_tuesday;

  /// No description provided for @weekday_wednesday.
  ///
  /// In en, this message translates to:
  /// **'Wednesday'**
  String get weekday_wednesday;

  /// No description provided for @day_name_wednesday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Wednesday'**
  String get day_name_wednesday;

  /// No description provided for @weekday_letter_wednesday.
  ///
  /// In en, this message translates to:
  /// **'W'**
  String get weekday_letter_wednesday;

  /// No description provided for @weekday_thursday.
  ///
  /// In en, this message translates to:
  /// **'Thursday'**
  String get weekday_thursday;

  /// No description provided for @day_name_thursday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Thursday'**
  String get day_name_thursday;

  /// No description provided for @weekday_letter_thursday.
  ///
  /// In en, this message translates to:
  /// **'T'**
  String get weekday_letter_thursday;

  /// No description provided for @weekday_friday.
  ///
  /// In en, this message translates to:
  /// **'Friday'**
  String get weekday_friday;

  /// No description provided for @day_name_friday.
  ///
  /// In en, this message translates to:
  /// **'Deeds of Friday'**
  String get day_name_friday;

  /// No description provided for @weekday_letter_friday.
  ///
  /// In en, this message translates to:
  /// **'F'**
  String get weekday_letter_friday;

  /// No description provided for @story_sat_1_title.
  ///
  /// In en, this message translates to:
  /// **'Reciting Surah Al-Kahf'**
  String get story_sat_1_title;

  /// No description provided for @story_sat_1_translation.
  ///
  /// In en, this message translates to:
  /// **'Praise be to Allah who revealed the Book to His servant and placed no crookedness in it.'**
  String get story_sat_1_translation;

  /// No description provided for @story_sat_2_title.
  ///
  /// In en, this message translates to:
  /// **'Saturday Supplication'**
  String get story_sat_2_title;

  /// No description provided for @story_sat_2_translation.
  ///
  /// In en, this message translates to:
  /// **'Our Lord, grant us mercy from Yourself and guide us rightly in our affair.'**
  String get story_sat_2_translation;

  /// No description provided for @story_sat_3_title.
  ///
  /// In en, this message translates to:
  /// **'Establishing the Five Daily Prayers'**
  String get story_sat_3_title;

  /// No description provided for @story_sat_3_translation.
  ///
  /// In en, this message translates to:
  /// **'Establish prayer from the decline of the sun until the darkness of the night, and the Quran of dawn.'**
  String get story_sat_3_translation;

  /// No description provided for @story_sat_4_title.
  ///
  /// In en, this message translates to:
  /// **'Giving Charity on Saturday'**
  String get story_sat_4_title;

  /// No description provided for @story_sat_4_translation.
  ///
  /// In en, this message translates to:
  /// **'Establish prayer, give zakat, and bow with those who bow.'**
  String get story_sat_4_translation;

  /// No description provided for @story_sat_5_title.
  ///
  /// In en, this message translates to:
  /// **'Istighfar and Repentance'**
  String get story_sat_5_title;

  /// No description provided for @story_sat_5_translation.
  ///
  /// In en, this message translates to:
  /// **'So glorify your Lord with praise and seek His forgiveness. Indeed, He is ever accepting of repentance.'**
  String get story_sat_5_translation;

  /// No description provided for @story_sun_1_title.
  ///
  /// In en, this message translates to:
  /// **'Supplication and Whispered Prayer on Sunday'**
  String get story_sun_1_title;

  /// No description provided for @story_sun_1_translation.
  ///
  /// In en, this message translates to:
  /// **'When My servants ask you about Me, indeed I am near. I respond to the call of the supplicant.'**
  String get story_sun_1_translation;

  /// No description provided for @story_sun_2_title.
  ///
  /// In en, this message translates to:
  /// **'Dhikr and Tasbih'**
  String get story_sun_2_title;

  /// No description provided for @story_sun_2_translation.
  ///
  /// In en, this message translates to:
  /// **'Surely, in the remembrance of Allah do hearts find rest.'**
  String get story_sun_2_translation;

  /// No description provided for @story_sun_3_title.
  ///
  /// In en, this message translates to:
  /// **'Voluntary Fasting on Sunday'**
  String get story_sun_3_title;

  /// No description provided for @story_sun_3_translation.
  ///
  /// In en, this message translates to:
  /// **'O you who believe, fasting has been prescribed for you as it was prescribed for those before you.'**
  String get story_sun_3_translation;

  /// No description provided for @story_sun_4_title.
  ///
  /// In en, this message translates to:
  /// **'Recitation of the Noble Quran'**
  String get story_sun_4_title;

  /// No description provided for @story_sun_4_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, this Quran guides to that which is most upright.'**
  String get story_sun_4_translation;

  /// No description provided for @story_sun_5_title.
  ///
  /// In en, this message translates to:
  /// **'Sending Blessings upon the Prophet'**
  String get story_sun_5_title;

  /// No description provided for @story_sun_5_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, Allah and His angels send blessings upon the Prophet. O believers, send blessings and peace upon him.'**
  String get story_sun_5_translation;

  /// No description provided for @story_mon_1_title.
  ///
  /// In en, this message translates to:
  /// **'Hastening toward Good Deeds'**
  String get story_mon_1_title;

  /// No description provided for @story_mon_1_translation.
  ///
  /// In en, this message translates to:
  /// **'Race toward forgiveness from your Lord and a garden as wide as the heavens and the earth.'**
  String get story_mon_1_translation;

  /// No description provided for @story_mon_2_title.
  ///
  /// In en, this message translates to:
  /// **'Praise and Gratitude to Allah'**
  String get story_mon_2_title;

  /// No description provided for @story_mon_2_translation.
  ///
  /// In en, this message translates to:
  /// **'All praise belongs to Allah, Lord of the worlds.'**
  String get story_mon_2_translation;

  /// No description provided for @story_mon_3_title.
  ///
  /// In en, this message translates to:
  /// **'Repentance and Istighfar on Monday'**
  String get story_mon_3_title;

  /// No description provided for @story_mon_3_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, Allah loves those who repent and loves those who purify themselves.'**
  String get story_mon_3_translation;

  /// No description provided for @story_mon_4_title.
  ///
  /// In en, this message translates to:
  /// **'Truthfulness and Honesty'**
  String get story_mon_4_title;

  /// No description provided for @story_mon_4_translation.
  ///
  /// In en, this message translates to:
  /// **'O believers, fear Allah and be with the truthful.'**
  String get story_mon_4_translation;

  /// No description provided for @story_mon_5_title.
  ///
  /// In en, this message translates to:
  /// **'Spending in the Way of Allah'**
  String get story_mon_5_title;

  /// No description provided for @story_mon_5_translation.
  ///
  /// In en, this message translates to:
  /// **'And those in whose wealth there is a known right for the beggar and the deprived.'**
  String get story_mon_5_translation;

  /// No description provided for @story_tue_1_title.
  ///
  /// In en, this message translates to:
  /// **'Patience and Perseverance'**
  String get story_tue_1_title;

  /// No description provided for @story_tue_1_translation.
  ///
  /// In en, this message translates to:
  /// **'Allah does not burden a soul beyond its capacity. For it is what it has earned and against it is what it has committed.'**
  String get story_tue_1_translation;

  /// No description provided for @story_tue_2_title.
  ///
  /// In en, this message translates to:
  /// **'Reciting Surah Al-Ikhlas'**
  String get story_tue_2_title;

  /// No description provided for @story_tue_2_translation.
  ///
  /// In en, this message translates to:
  /// **'Say: He is Allah, One. Allah, the Eternal Refuge.'**
  String get story_tue_2_translation;

  /// No description provided for @story_tue_3_title.
  ///
  /// In en, this message translates to:
  /// **'Humility and Modesty'**
  String get story_tue_3_title;

  /// No description provided for @story_tue_3_translation.
  ///
  /// In en, this message translates to:
  /// **'The servants of the Most Merciful are those who walk upon the earth humbly.'**
  String get story_tue_3_translation;

  /// No description provided for @story_tue_4_title.
  ///
  /// In en, this message translates to:
  /// **'Patience and Steadfastness'**
  String get story_tue_4_title;

  /// No description provided for @story_tue_4_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, Allah is with the patient.'**
  String get story_tue_4_translation;

  /// No description provided for @story_tue_5_title.
  ///
  /// In en, this message translates to:
  /// **'Trust in Allah'**
  String get story_tue_5_title;

  /// No description provided for @story_tue_5_translation.
  ///
  /// In en, this message translates to:
  /// **'Whoever relies upon Allah, He is sufficient for him. Indeed, Allah will accomplish His purpose.'**
  String get story_tue_5_translation;

  /// No description provided for @story_wed_1_title.
  ///
  /// In en, this message translates to:
  /// **'Gratitude for Allah\'s Blessings'**
  String get story_wed_1_title;

  /// No description provided for @story_wed_1_translation.
  ///
  /// In en, this message translates to:
  /// **'So which of your Lord\'s favors will you both deny?'**
  String get story_wed_1_translation;

  /// No description provided for @story_wed_2_title.
  ///
  /// In en, this message translates to:
  /// **'Good Deeds on Wednesday'**
  String get story_wed_2_title;

  /// No description provided for @story_wed_2_translation.
  ///
  /// In en, this message translates to:
  /// **'Whoever comes with a good deed shall have ten times the like of it.'**
  String get story_wed_2_translation;

  /// No description provided for @story_wed_3_title.
  ///
  /// In en, this message translates to:
  /// **'Brotherhood and Reconciliation'**
  String get story_wed_3_title;

  /// No description provided for @story_wed_3_translation.
  ///
  /// In en, this message translates to:
  /// **'The believers are but brothers, so make peace between your brothers.'**
  String get story_wed_3_translation;

  /// No description provided for @story_wed_4_title.
  ///
  /// In en, this message translates to:
  /// **'Seeking Knowledge'**
  String get story_wed_4_title;

  /// No description provided for @story_wed_4_translation.
  ///
  /// In en, this message translates to:
  /// **'And say: My Lord, increase me in knowledge.'**
  String get story_wed_4_translation;

  /// No description provided for @story_wed_5_title.
  ///
  /// In en, this message translates to:
  /// **'Supplication and Prayer'**
  String get story_wed_5_title;

  /// No description provided for @story_wed_5_translation.
  ///
  /// In en, this message translates to:
  /// **'Your Lord said: Call upon Me; I will respond to you.'**
  String get story_wed_5_translation;

  /// No description provided for @story_thu_1_title.
  ///
  /// In en, this message translates to:
  /// **'Glorifying Allah'**
  String get story_thu_1_title;

  /// No description provided for @story_thu_1_translation.
  ///
  /// In en, this message translates to:
  /// **'So exalted is He in whose hand is the dominion of all things, and to Him you will be returned.'**
  String get story_thu_1_translation;

  /// No description provided for @story_thu_2_title.
  ///
  /// In en, this message translates to:
  /// **'Preparing for Friday Prayer'**
  String get story_thu_2_title;

  /// No description provided for @story_thu_2_translation.
  ///
  /// In en, this message translates to:
  /// **'O believers, when the call is made for prayer on Friday, hasten to the remembrance of Allah.'**
  String get story_thu_2_translation;

  /// No description provided for @story_thu_3_title.
  ///
  /// In en, this message translates to:
  /// **'Night Prayer on Thursday'**
  String get story_thu_3_title;

  /// No description provided for @story_thu_3_translation.
  ///
  /// In en, this message translates to:
  /// **'And during part of the night, pray with it as extra worship for you.'**
  String get story_thu_3_translation;

  /// No description provided for @story_thu_4_title.
  ///
  /// In en, this message translates to:
  /// **'Sincere Worship and Servitude'**
  String get story_thu_4_title;

  /// No description provided for @story_thu_4_translation.
  ///
  /// In en, this message translates to:
  /// **'I did not create jinn and mankind except that they worship Me.'**
  String get story_thu_4_translation;

  /// No description provided for @story_thu_5_title.
  ///
  /// In en, this message translates to:
  /// **'Hope in Allah\'s Mercy'**
  String get story_thu_5_title;

  /// No description provided for @story_thu_5_translation.
  ///
  /// In en, this message translates to:
  /// **'Say: O My servants who have transgressed against themselves, do not despair of Allah\'s mercy.'**
  String get story_thu_5_translation;

  /// No description provided for @story_fri_1_title.
  ///
  /// In en, this message translates to:
  /// **'Friday Prayer and Seeking Provision'**
  String get story_fri_1_title;

  /// No description provided for @story_fri_1_translation.
  ///
  /// In en, this message translates to:
  /// **'When the prayer has been concluded, disperse through the land and seek Allah\'s bounty.'**
  String get story_fri_1_translation;

  /// No description provided for @story_fri_2_title.
  ///
  /// In en, this message translates to:
  /// **'Reciting Surah Al-Kahf on Friday'**
  String get story_fri_2_title;

  /// No description provided for @story_fri_2_translation.
  ///
  /// In en, this message translates to:
  /// **'Praise be to Allah who revealed the Book to His servant and made no crookedness in it.'**
  String get story_fri_2_translation;

  /// No description provided for @story_fri_3_title.
  ///
  /// In en, this message translates to:
  /// **'Abundant Salawat on Friday'**
  String get story_fri_3_title;

  /// No description provided for @story_fri_3_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, Allah and His angels send blessings upon the Prophet.'**
  String get story_fri_3_translation;

  /// No description provided for @story_fri_4_title.
  ///
  /// In en, this message translates to:
  /// **'Friday Charity'**
  String get story_fri_4_title;

  /// No description provided for @story_fri_4_translation.
  ///
  /// In en, this message translates to:
  /// **'Take from their wealth a charity by which you purify them and cause them increase.'**
  String get story_fri_4_translation;

  /// No description provided for @story_fri_5_title.
  ///
  /// In en, this message translates to:
  /// **'Supplication and Drawing Near to Allah'**
  String get story_fri_5_title;

  /// No description provided for @story_fri_5_translation.
  ///
  /// In en, this message translates to:
  /// **'O believers, fear Allah and seek the means of nearness to Him.'**
  String get story_fri_5_translation;

  /// No description provided for @story_fri_6_title.
  ///
  /// In en, this message translates to:
  /// **'Reviving Thursday Night'**
  String get story_fri_6_title;

  /// No description provided for @story_fri_6_translation.
  ///
  /// In en, this message translates to:
  /// **'Indeed, We sent it down in a blessed night; surely We are ever warning.'**
  String get story_fri_6_translation;

  /// No description provided for @amal_adia.
  ///
  /// In en, this message translates to:
  /// **'Deeds and Supplications'**
  String get amal_adia;

  /// No description provided for @search_by_type_title.
  ///
  /// In en, this message translates to:
  /// **'Search by'**
  String get search_by_type_title;

  /// No description provided for @search_surah_short.
  ///
  /// In en, this message translates to:
  /// **'Surah'**
  String get search_surah_short;

  /// No description provided for @search_ayah_short.
  ///
  /// In en, this message translates to:
  /// **'Ayah'**
  String get search_ayah_short;

  /// No description provided for @search_ayah_example.
  ///
  /// In en, this message translates to:
  /// **'Example: 2:255 or Allah'**
  String get search_ayah_example;

  /// No description provided for @search_enter_surah_name.
  ///
  /// In en, this message translates to:
  /// **'Enter a Surah name'**
  String get search_enter_surah_name;

  /// No description provided for @search_enter_ayah_text_or_number.
  ///
  /// In en, this message translates to:
  /// **'Enter an Ayah, text, or number'**
  String get search_enter_ayah_text_or_number;

  /// No description provided for @search_go_to_ayah.
  ///
  /// In en, this message translates to:
  /// **'Go to Ayah'**
  String get search_go_to_ayah;

  /// No description provided for @search_no_result_for.
  ///
  /// In en, this message translates to:
  /// **'No result found for \"{query}\"'**
  String search_no_result_for(Object query);

  /// No description provided for @search_ayah_filter_subtitle.
  ///
  /// In en, this message translates to:
  /// **'Ayah text or number (example: 2:255)'**
  String get search_ayah_filter_subtitle;

  /// No description provided for @exit_app_message.
  ///
  /// In en, this message translates to:
  /// **'Press back again to exit the app'**
  String get exit_app_message;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'fa'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'fa':
      return AppLocalizationsFa();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
