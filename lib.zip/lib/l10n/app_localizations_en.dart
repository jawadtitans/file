// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get splash_text => 'Hedaya';

  @override
  String get header_date => 'Today\'s Date';

  @override
  String get header_location => 'Your Location';

  @override
  String get header_time => 'Time';

  @override
  String get header_fajr => 'Time remaining until Fajr';

  @override
  String get al_quran => 'Al-Quran';

  @override
  String get tab_surah => 'Surah';

  @override
  String get tab_juz => 'Juz';

  @override
  String get tab_Ayah => 'Ayah';

  @override
  String get no_surahs => 'No Surahs Found';

  @override
  String get no_ayah => 'No saved Ayah yet';

  @override
  String get no_surah => 'No saved Surah yet';

  @override
  String get no_juz => 'No saved Juz yet';

  @override
  String get bookmar_title => 'Bookmarks';

  @override
  String get today_zikr => 'Today\'s Zikr';

  @override
  String get nav_home => 'Home';

  @override
  String get nav_Quran => 'Quran';

  @override
  String get nav_prayer => 'Prayer Times';

  @override
  String get nav_islam => 'Home';

  @override
  String get nav_search => 'Search';

  @override
  String get nav_settings => 'Settings';

  @override
  String get search_hint => 'Search';

  @override
  String get no_results => 'No results found';

  @override
  String get settings_title => 'Settings';

  @override
  String get recent_downloads => 'Recent Downloads';

  @override
  String get share_apps => 'Share App';

  @override
  String get my_network => 'My Network';

  @override
  String get payments => 'Payments';

  @override
  String get support => 'Sounds';

  @override
  String get allow_notifications => 'Allow Notifications';

  @override
  String get auto_scroll => 'Auto Scroll During Recitation';

  @override
  String get preview_text => 'Preview Text';

  @override
  String get quran_font_size => 'Quran Font Size';

  @override
  String get account_admin => 'Account Admin';

  @override
  String get login => 'Login';

  @override
  String get quran_app => 'Quran Mobile App';

  @override
  String get share => 'Share App';

  @override
  String get about_app => 'About App';

  @override
  String get filter => 'Filter';

  @override
  String get search_ayah => 'Search by Ayah';

  @override
  String get search_surah => 'Search by Surah';

  @override
  String get search_surah_subtitle => 'Search for a Surah by its name';

  @override
  String get search_ayah_subtitle => 'Search for an Ayah by its text';

  @override
  String get prayer_times => 'Prayer Times';

  @override
  String get fajr => 'Fajr';

  @override
  String get sunrise => 'Sunrise';

  @override
  String get dhuhr => 'Dhuhr';

  @override
  String get asr => 'Asr';

  @override
  String get maghrib => 'Maghrib';

  @override
  String get isha => 'Isha\'a';

  @override
  String get now => 'Now';

  @override
  String get next => 'Next';

  @override
  String get upcoming => 'Upcoming';

  @override
  String get location_permission => 'Enable Location';

  @override
  String get location_required =>
      'Location is required for accurate prayer times';

  @override
  String get location_success => 'Location acquired';

  @override
  String get enable_notification => 'Enable Notifications';

  @override
  String get notification_desc =>
      'Don\'t miss prayer time with Adhan reminders';

  @override
  String get done => 'Done';

  @override
  String get skip => 'Skip';

  @override
  String get enable_location => 'Enable Location';

  @override
  String get see_prayer_times => 'See Prayer Times';

  @override
  String get events_of_day => 'Events of This Day';

  @override
  String get hijri => 'Hijri';

  @override
  String get shamsi => 'Shamsi';

  @override
  String get bookmark => 'Bookmark';

  @override
  String get reading => 'Reading';

  @override
  String get continue_reading => 'Continue Reading';

  @override
  String get surah => 'Surah';

  @override
  String get juz => 'Juz';

  @override
  String get verse => 'Verse';

  @override
  String get font_size => 'Font Size';

  @override
  String get theme => 'Theme';

  @override
  String get language => 'Language';

  @override
  String get dark_mode => 'Dark Mode';

  @override
  String get light_mode => 'Light Mode';

  @override
  String get welcome_title => 'Salaam !\nWelcome to Hedaya 🌙';

  @override
  String get welcome_goal_question => 'What is your Goal to More Focus on?';

  @override
  String get welcome_goal_pray_consistently => 'Pray consistently';

  @override
  String get welcome_goal_read_more_quran => 'Read more Quran';

  @override
  String get welcome_description =>
      'Take a minute to Personalize your app and stay on track with your prayers and Allah.';

  @override
  String get welcome_start_button => 'Bismillah, let\'s start';

  @override
  String get onboarding_close => 'Close';

  @override
  String get location_permission_denied_message =>
      'Please enable location permission and GPS';

  @override
  String get enable_notifications_and_finish =>
      'Enable Notifications and Finish';

  @override
  String get quran_read_tab => 'Read';

  @override
  String get quran_progress_tab => 'My Progress';

  @override
  String get quran_recents => 'Recents';

  @override
  String get quran_sura_list => 'Sura list';

  @override
  String get quran_juz_list => 'Juz list';

  @override
  String quran_view_label(Object type) {
    return 'View: $type';
  }

  @override
  String get quran_view_sura => 'Sura';

  @override
  String get quran_view_juz => 'Juz';

  @override
  String quran_ayah_count(Object count) {
    return '$count Ayah';
  }

  @override
  String quran_juz_header(Object number) {
    return 'Juz $number';
  }

  @override
  String quran_aya_short(Object number) {
    return 'Aya $number';
  }

  @override
  String get quran_khatam_tab => 'Khatam';

  @override
  String get quran_juz_done => 'Juz done';

  @override
  String get quran_surah_done => 'Surah done';

  @override
  String get quran_complete_surah_message => 'Complete a Surah to see it here';

  @override
  String get quran_completed => '✓ Completed';

  @override
  String get quran_last_read => 'Last read';

  @override
  String get quran_no_reading_yet => 'No reading yet';

  @override
  String get quran_minute_read => 'minute read';

  @override
  String get quran_reading_progress_title => 'Reading Progress';

  @override
  String get quran_reading_progress_subtitle =>
      'Scroll-based progress per Surah & Juz';

  @override
  String quran_surah_label(Object number) {
    return 'Surah $number';
  }

  @override
  String quran_juz_label(Object number) {
    return 'Juz $number';
  }

  @override
  String get quran_start_reading_progress => 'Start reading to track progress';

  @override
  String get prayer_times_title => 'Prayer Times';

  @override
  String get calendar_gregorian => 'Gregorian';

  @override
  String get calendar_hijri => 'Hijri';

  @override
  String get prayer_now => 'Now';

  @override
  String get prayer_next => 'Next';

  @override
  String prayer_in(Object time) {
    return 'In $time';
  }

  @override
  String get prayer_completed_count => 'Completed';

  @override
  String get prayer_now_badge => 'Now';

  @override
  String get prayer_fajr_local => 'Fajr';

  @override
  String get prayer_dhuhr_local => 'Dhuhr';

  @override
  String get prayer_asr_local => 'Asr';

  @override
  String get prayer_maghrib_local => 'Maghrib';

  @override
  String get prayer_isha_local => 'Isha';

  @override
  String time_hours_minutes(Object hours, Object minutes) {
    return '${hours}h ${minutes}m';
  }

  @override
  String time_minutes_seconds(Object minutes, Object seconds) {
    return '${minutes}m ${seconds}s';
  }

  @override
  String get month_january => 'January';

  @override
  String get month_february => 'February';

  @override
  String get month_march => 'March';

  @override
  String get month_april => 'April';

  @override
  String get month_may => 'May';

  @override
  String get month_june => 'June';

  @override
  String get month_july => 'July';

  @override
  String get month_august => 'August';

  @override
  String get month_september => 'September';

  @override
  String get month_october => 'October';

  @override
  String get month_november => 'November';

  @override
  String get month_december => 'December';

  @override
  String get weekday_short_sat => 'S';

  @override
  String get weekday_short_sun => 'S';

  @override
  String get weekday_short_mon => 'M';

  @override
  String get weekday_short_tue => 'T';

  @override
  String get weekday_short_wed => 'W';

  @override
  String get weekday_short_thu => 'T';

  @override
  String get weekday_short_fri => 'F';

  @override
  String get hijri_muharram => 'Muharram';

  @override
  String get hijri_safar => 'Safar';

  @override
  String get hijri_rabi_al_awwal => 'Rabi al-Awwal';

  @override
  String get hijri_rabi_al_thani => 'Rabi al-Thani';

  @override
  String get hijri_jumada_al_awwal => 'Jumada al-Awwal';

  @override
  String get hijri_jumada_al_thani => 'Jumada al-Thani';

  @override
  String get hijri_rajab => 'Rajab';

  @override
  String get hijri_shaban => 'Sha\'ban';

  @override
  String get hijri_ramadan => 'Ramadan';

  @override
  String get hijri_shawwal => 'Shawwal';

  @override
  String get hijri_dhul_qadah => 'Dhul-Qadah';

  @override
  String get hijri_dhul_hijjah => 'Dhul-Hijjah';

  @override
  String get tasbih_title => 'Tasbih';

  @override
  String get tasbih_reset => 'Reset';

  @override
  String tasbih_total(Object count) {
    return 'Total: $count';
  }

  @override
  String get tasbih_tap_hint => 'Tap to count';

  @override
  String get qibla_title => 'Qibla Direction';

  @override
  String get qibla_coming_desc =>
      'This feature is under development and will be available in the next version.';

  @override
  String get coming_soon => 'Coming Soon';

  @override
  String get duas_title => 'Duas';

  @override
  String get dua_category_morning => 'Morning';

  @override
  String get dua_category_night => 'Night';

  @override
  String get dua_category_prayer => 'Prayer';

  @override
  String get dua_category_istighfar => 'Istighfar';

  @override
  String get dua_category_family => 'Family';

  @override
  String get dua_category_trust => 'Trust';

  @override
  String get dua_title_morning => 'Morning Dua';

  @override
  String get dua_title_before_sleep => 'Before Sleep Dua';

  @override
  String get dua_title_after_prayer => 'After Prayer Dua';

  @override
  String get dua_title_istighfar => 'Istighfar Dua';

  @override
  String get dua_title_parents => 'Dua for Parents';

  @override
  String get dua_title_trust => 'Dua of Trust';

  @override
  String get khatam_title => 'Khatam Quran';

  @override
  String khatam_completed_percent(Object percent) {
    return '$percent% completed';
  }

  @override
  String get today_features_title => 'Features';

  @override
  String get today_assistant_tools => 'Your Assistant Tools';

  @override
  String get today_monthly_deeds_title => 'Monthly Deeds';

  @override
  String get today_monthly_deeds_subtitle => 'Virtues and deeds of this month';

  @override
  String get today_now => 'Now';

  @override
  String get today_next => 'Next';

  @override
  String today_in_hours_minutes(Object hours, Object minutes) {
    return 'In ${hours}h ${minutes}m';
  }

  @override
  String today_in_minutes_seconds(Object minutes, Object seconds) {
    return 'In ${minutes}m ${seconds}s';
  }

  @override
  String get settings_notifications_section => 'Notifications';

  @override
  String get settings_reading_section => 'Reading';

  @override
  String get settings_app_language_section => 'App Language';

  @override
  String get settings_allow_notifications => 'Allow Notifications';

  @override
  String get settings_auto_scroll => 'Auto Scroll';

  @override
  String get settings_font_size => 'Font Size';

  @override
  String get settings_language_english => 'English';

  @override
  String get settings_language_dari => 'Dari / Farsi';

  @override
  String get monthly_deeds_rajab_title => 'Deeds of Rajab';

  @override
  String get monthly_deeds_rajab_deed_1 => 'Fasting on recommended days';

  @override
  String get monthly_deeds_rajab_deed_2 => 'Reciting the Dua Ya Man Arjuhu';

  @override
  String get monthly_deeds_rajab_deed_3 => 'Frequent Istighfar';

  @override
  String get monthly_deeds_shaban_title => 'Deeds of Sha\'ban';

  @override
  String get monthly_deeds_shaban_deed_1 => 'Salawat Sha\'baniyyah';

  @override
  String get monthly_deeds_shaban_deed_2 => 'Recommended fasting';

  @override
  String get monthly_deeds_shaban_deed_3 => 'Giving charity';

  @override
  String get monthly_deeds_ramadan_title => 'Deeds of Ramadan';

  @override
  String get monthly_deeds_ramadan_deed_1 => 'Fasting';

  @override
  String get monthly_deeds_ramadan_deed_2 => 'Reciting the Quran';

  @override
  String get monthly_deeds_ramadan_deed_3 => 'Dua al-Iftitah';

  @override
  String get monthly_deeds_ramadan_deed_4 => 'Reviving the Nights of Qadr';

  @override
  String get weekday_saturday => 'Saturday';

  @override
  String get day_name_saturday => 'Deeds of Saturday';

  @override
  String get weekday_letter_saturday => 'S';

  @override
  String get weekday_sunday => 'Sunday';

  @override
  String get day_name_sunday => 'Deeds of Sunday';

  @override
  String get weekday_letter_sunday => 'S';

  @override
  String get weekday_monday => 'Monday';

  @override
  String get day_name_monday => 'Deeds of Monday';

  @override
  String get weekday_letter_monday => 'M';

  @override
  String get weekday_tuesday => 'Tuesday';

  @override
  String get day_name_tuesday => 'Deeds of Tuesday';

  @override
  String get weekday_letter_tuesday => 'T';

  @override
  String get weekday_wednesday => 'Wednesday';

  @override
  String get day_name_wednesday => 'Deeds of Wednesday';

  @override
  String get weekday_letter_wednesday => 'W';

  @override
  String get weekday_thursday => 'Thursday';

  @override
  String get day_name_thursday => 'Deeds of Thursday';

  @override
  String get weekday_letter_thursday => 'T';

  @override
  String get weekday_friday => 'Friday';

  @override
  String get day_name_friday => 'Deeds of Friday';

  @override
  String get weekday_letter_friday => 'F';

  @override
  String get story_sat_1_title => 'Reciting Surah Al-Kahf';

  @override
  String get story_sat_1_translation =>
      'Praise be to Allah who revealed the Book to His servant and placed no crookedness in it.';

  @override
  String get story_sat_2_title => 'Saturday Supplication';

  @override
  String get story_sat_2_translation =>
      'Our Lord, grant us mercy from Yourself and guide us rightly in our affair.';

  @override
  String get story_sat_3_title => 'Establishing the Five Daily Prayers';

  @override
  String get story_sat_3_translation =>
      'Establish prayer from the decline of the sun until the darkness of the night, and the Quran of dawn.';

  @override
  String get story_sat_4_title => 'Giving Charity on Saturday';

  @override
  String get story_sat_4_translation =>
      'Establish prayer, give zakat, and bow with those who bow.';

  @override
  String get story_sat_5_title => 'Istighfar and Repentance';

  @override
  String get story_sat_5_translation =>
      'So glorify your Lord with praise and seek His forgiveness. Indeed, He is ever accepting of repentance.';

  @override
  String get story_sun_1_title => 'Supplication and Whispered Prayer on Sunday';

  @override
  String get story_sun_1_translation =>
      'When My servants ask you about Me, indeed I am near. I respond to the call of the supplicant.';

  @override
  String get story_sun_2_title => 'Dhikr and Tasbih';

  @override
  String get story_sun_2_translation =>
      'Surely, in the remembrance of Allah do hearts find rest.';

  @override
  String get story_sun_3_title => 'Voluntary Fasting on Sunday';

  @override
  String get story_sun_3_translation =>
      'O you who believe, fasting has been prescribed for you as it was prescribed for those before you.';

  @override
  String get story_sun_4_title => 'Recitation of the Noble Quran';

  @override
  String get story_sun_4_translation =>
      'Indeed, this Quran guides to that which is most upright.';

  @override
  String get story_sun_5_title => 'Sending Blessings upon the Prophet';

  @override
  String get story_sun_5_translation =>
      'Indeed, Allah and His angels send blessings upon the Prophet. O believers, send blessings and peace upon him.';

  @override
  String get story_mon_1_title => 'Hastening toward Good Deeds';

  @override
  String get story_mon_1_translation =>
      'Race toward forgiveness from your Lord and a garden as wide as the heavens and the earth.';

  @override
  String get story_mon_2_title => 'Praise and Gratitude to Allah';

  @override
  String get story_mon_2_translation =>
      'All praise belongs to Allah, Lord of the worlds.';

  @override
  String get story_mon_3_title => 'Repentance and Istighfar on Monday';

  @override
  String get story_mon_3_translation =>
      'Indeed, Allah loves those who repent and loves those who purify themselves.';

  @override
  String get story_mon_4_title => 'Truthfulness and Honesty';

  @override
  String get story_mon_4_translation =>
      'O believers, fear Allah and be with the truthful.';

  @override
  String get story_mon_5_title => 'Spending in the Way of Allah';

  @override
  String get story_mon_5_translation =>
      'And those in whose wealth there is a known right for the beggar and the deprived.';

  @override
  String get story_tue_1_title => 'Patience and Perseverance';

  @override
  String get story_tue_1_translation =>
      'Allah does not burden a soul beyond its capacity. For it is what it has earned and against it is what it has committed.';

  @override
  String get story_tue_2_title => 'Reciting Surah Al-Ikhlas';

  @override
  String get story_tue_2_translation =>
      'Say: He is Allah, One. Allah, the Eternal Refuge.';

  @override
  String get story_tue_3_title => 'Humility and Modesty';

  @override
  String get story_tue_3_translation =>
      'The servants of the Most Merciful are those who walk upon the earth humbly.';

  @override
  String get story_tue_4_title => 'Patience and Steadfastness';

  @override
  String get story_tue_4_translation => 'Indeed, Allah is with the patient.';

  @override
  String get story_tue_5_title => 'Trust in Allah';

  @override
  String get story_tue_5_translation =>
      'Whoever relies upon Allah, He is sufficient for him. Indeed, Allah will accomplish His purpose.';

  @override
  String get story_wed_1_title => 'Gratitude for Allah\'s Blessings';

  @override
  String get story_wed_1_translation =>
      'So which of your Lord\'s favors will you both deny?';

  @override
  String get story_wed_2_title => 'Good Deeds on Wednesday';

  @override
  String get story_wed_2_translation =>
      'Whoever comes with a good deed shall have ten times the like of it.';

  @override
  String get story_wed_3_title => 'Brotherhood and Reconciliation';

  @override
  String get story_wed_3_translation =>
      'The believers are but brothers, so make peace between your brothers.';

  @override
  String get story_wed_4_title => 'Seeking Knowledge';

  @override
  String get story_wed_4_translation =>
      'And say: My Lord, increase me in knowledge.';

  @override
  String get story_wed_5_title => 'Supplication and Prayer';

  @override
  String get story_wed_5_translation =>
      'Your Lord said: Call upon Me; I will respond to you.';

  @override
  String get story_thu_1_title => 'Glorifying Allah';

  @override
  String get story_thu_1_translation =>
      'So exalted is He in whose hand is the dominion of all things, and to Him you will be returned.';

  @override
  String get story_thu_2_title => 'Preparing for Friday Prayer';

  @override
  String get story_thu_2_translation =>
      'O believers, when the call is made for prayer on Friday, hasten to the remembrance of Allah.';

  @override
  String get story_thu_3_title => 'Night Prayer on Thursday';

  @override
  String get story_thu_3_translation =>
      'And during part of the night, pray with it as extra worship for you.';

  @override
  String get story_thu_4_title => 'Sincere Worship and Servitude';

  @override
  String get story_thu_4_translation =>
      'I did not create jinn and mankind except that they worship Me.';

  @override
  String get story_thu_5_title => 'Hope in Allah\'s Mercy';

  @override
  String get story_thu_5_translation =>
      'Say: O My servants who have transgressed against themselves, do not despair of Allah\'s mercy.';

  @override
  String get story_fri_1_title => 'Friday Prayer and Seeking Provision';

  @override
  String get story_fri_1_translation =>
      'When the prayer has been concluded, disperse through the land and seek Allah\'s bounty.';

  @override
  String get story_fri_2_title => 'Reciting Surah Al-Kahf on Friday';

  @override
  String get story_fri_2_translation =>
      'Praise be to Allah who revealed the Book to His servant and made no crookedness in it.';

  @override
  String get story_fri_3_title => 'Abundant Salawat on Friday';

  @override
  String get story_fri_3_translation =>
      'Indeed, Allah and His angels send blessings upon the Prophet.';

  @override
  String get story_fri_4_title => 'Friday Charity';

  @override
  String get story_fri_4_translation =>
      'Take from their wealth a charity by which you purify them and cause them increase.';

  @override
  String get story_fri_5_title => 'Supplication and Drawing Near to Allah';

  @override
  String get story_fri_5_translation =>
      'O believers, fear Allah and seek the means of nearness to Him.';

  @override
  String get story_fri_6_title => 'Reviving Thursday Night';

  @override
  String get story_fri_6_translation =>
      'Indeed, We sent it down in a blessed night; surely We are ever warning.';

  @override
  String get amal_adia => 'Deeds and Supplications';

  @override
  String get search_by_type_title => 'Search by';

  @override
  String get search_surah_short => 'Surah';

  @override
  String get search_ayah_short => 'Ayah';

  @override
  String get search_ayah_example => 'Example: 2:255 or Allah';

  @override
  String get search_enter_surah_name => 'Enter a Surah name';

  @override
  String get search_enter_ayah_text_or_number =>
      'Enter an Ayah, text, or number';

  @override
  String get search_go_to_ayah => 'Go to Ayah';

  @override
  String search_no_result_for(Object query) {
    return 'No result found for \"$query\"';
  }

  @override
  String get search_ayah_filter_subtitle =>
      'Ayah text or number (example: 2:255)';

  @override
  String get exit_app_message => 'Press back again to exit the app';
}
