class Juz {
  final int id;
  final String nameEn;
  final String nameAr;
  final int number;

  Juz({
    required this.id,
    required this.nameEn,
    required this.nameAr,
    required this.number,
  });

  factory Juz.fromJson(Map<String, dynamic> json) {
    return Juz(
      id: json['id'],
      nameEn: json['name'],
      nameAr: json['name_ar'],
      number: json['number'],
    );
  }
}
