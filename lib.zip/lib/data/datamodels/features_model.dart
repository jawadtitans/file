import '../../generated/l10n.dart';

class Feature {
  final String title;
  final String emoji;

  const Feature(this.title, this.emoji);
}

List<Feature> deenFeatures(S s) => [
  Feature(s.prayer_times, "assets/webp/prayer_time.webp"),
  Feature(s.nav_Quran, "assets/webp/Dowaha.webp"),
  Feature(s.tasbih_title, "assets/webp/tazbih.webp"),
  Feature(s.qibla_title, "assets/webp/kabah.webp"),
  Feature(s.duas_title, "assets/webp/doya.webp"),
  Feature(s.quran_khatam_tab, "assets/webp/khatm.webp"),
];
