import 'dart:ui';
import '../../exportfile.dart';

class WeekDayModel {
  final String title;
  final Color color;

  WeekDayModel({required this.title, required this.color});
}

final List<WeekDayModel> weekDays = [
  WeekDayModel(title: "اعمال روز شنبه", color: Colors.orange),
  WeekDayModel(title: "اعمال روز یکشنبه", color: Colors.blue),
  WeekDayModel(title: "اعمال روز دوشنبه", color: Colors.green),
  WeekDayModel(title: "اعمال روز سه‌شنبه", color: Colors.purple),
  WeekDayModel(title: "اعمال روز چهارشنبه", color: Colors.teal),
  WeekDayModel(title: "اعمال روز پنجشنبه", color: Colors.red),
  WeekDayModel(title: "اعمال روز جمعه", color: Colors.amber),
];
