class Verse {
  final int globalId;
  final int surah;
  final int ayah;
  final String verseKey;
  final String textAr;

  Verse({
    required this.globalId,
    required this.surah,
    required this.ayah,
    required this.verseKey,
    required this.textAr,
  });

  factory Verse.fromJson(Map<String, dynamic> json) {
    return Verse(
      globalId: json['global_id'],
      surah: json['surah'],
      ayah: json['ayah'],
      verseKey: json['verse_key'],
      textAr: json['text_ar'],
    );
  }
}
