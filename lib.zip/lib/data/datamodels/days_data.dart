import 'package:flutter/material.dart';
import '../../generated/l10n.dart';

class DayStory {
  final String verseRef;
  final String arabicText;
  final String translation;
  final String amalTitle;
  final String icon;
  final List<Color> bgGradient;

  const DayStory({
    required this.verseRef,
    required this.arabicText,
    required this.translation,
    required this.amalTitle,
    required this.icon,
    required this.bgGradient,
  });
}

class DayData {
  final int id;
  final String dayLabel;
  final String dayName;
  final String letter;
  final List<Color> avatarGradient;
  final List<DayStory> stories;

  const DayData({
    required this.id,
    required this.dayLabel,
    required this.dayName,
    required this.letter,
    required this.avatarGradient,
    required this.stories,
  });
}

List<DayData> weekDays(S s) => [
  DayData(
    id: 0,
    dayLabel: s.weekday_saturday,
    dayName: s.day_name_saturday,
    letter: s.weekday_letter_saturday,
    avatarGradient: [const Color(0xFF1A6B4A), const Color(0xFF0D3D2A)],
    stories: [
      DayStory(
        verseRef: 'الکهف ۱۸:۱',
        arabicText:
            'الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ',
        translation: s.story_sat_1_translation,
        amalTitle: s.story_sat_1_title,
        icon: '📖',
        bgGradient: [
          const Color(0xFF0D2B1F),
          const Color(0xFF1A5C3A),
          const Color(0xFF0A1F14),
        ],
      ),
      DayStory(
        verseRef: 'الکهف ۱۸:۱۰',
        arabicText:
            'رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا',
        translation: s.story_sat_2_translation,
        amalTitle: s.story_sat_2_title,
        icon: '🤲',
        bgGradient: [
          const Color(0xFF1A3A5C),
          const Color(0xFF0D2B4A),
          const Color(0xFF061520),
        ],
      ),
      DayStory(
        verseRef: 'الإسراء ۱۷:۷۸',
        arabicText:
            'أَقِمِ الصَّلَاةَ لِدُلُوكِ الشَّمْسِ إِلَىٰ غَسَقِ اللَّيْلِ وَقُرْآنَ الْفَجْرِ',
        translation: s.story_sat_3_translation,
        amalTitle: s.story_sat_3_title,
        icon: '🕌',
        bgGradient: [
          const Color(0xFF1A1A0D),
          const Color(0xFF3A3A1A),
          const Color(0xFF0D0D06),
        ],
      ),
      DayStory(
        verseRef: 'البقرة ۲:۴۳',
        arabicText:
            'وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ وَارْكَعُوا مَعَ الرَّاكِعِينَ',
        translation: s.story_sat_4_translation,
        amalTitle: s.story_sat_4_title,
        icon: '💝',
        bgGradient: [
          const Color(0xFF1A4A1A),
          const Color(0xFF0D2B0D),
          const Color(0xFF061306),
        ],
      ),
      DayStory(
        verseRef: 'النصر ۱۱۰:۳',
        arabicText:
            'فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا',
        translation: s.story_sat_5_translation,
        amalTitle: s.story_sat_5_title,
        icon: '✨',
        bgGradient: [
          const Color(0xFF4A3A1A),
          const Color(0xFF2B200D),
          const Color(0xFF130F06),
        ],
      ),
    ],
  ),
  DayData(
    id: 1,
    dayLabel: s.weekday_sunday,
    dayName: s.day_name_sunday,
    letter: s.weekday_letter_sunday,
    avatarGradient: [const Color(0xFF6B1A1A), const Color(0xFF3D0D0D)],
    stories: [
      DayStory(
        verseRef: 'البقرة ۲:۱۸۶',
        arabicText:
            'وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ',
        translation: s.story_sun_1_translation,
        amalTitle: s.story_sun_1_title,
        icon: '🤲',
        bgGradient: [
          const Color(0xFF2B0D0D),
          const Color(0xFF5C1A1A),
          const Color(0xFF1F0A0A),
        ],
      ),
      DayStory(
        verseRef: 'الرعد ۱۳:۲۸',
        arabicText: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
        translation: s.story_sun_2_translation,
        amalTitle: s.story_sun_2_title,
        icon: '📿',
        bgGradient: [
          const Color(0xFF1A0D2B),
          const Color(0xFF3A1A5C),
          const Color(0xFF0D0620),
        ],
      ),
      DayStory(
        verseRef: 'البقرة ۲:۱۸۳',
        arabicText:
            'يَا أَيُّهَا الَّذِينَ آمَنُوا كُتِبَ عَلَيْكُمُ الصِّيَامُ كَمَا كُتِبَ عَلَى الَّذِينَ مِن قَبْلِكُمْ',
        translation: s.story_sun_3_translation,
        amalTitle: s.story_sun_3_title,
        icon: '🌙',
        bgGradient: [
          const Color(0xFF0D1A2B),
          const Color(0xFF1A3A5C),
          const Color(0xFF060D1F),
        ],
      ),
      DayStory(
        verseRef: 'الإسراء ۱۷:۹',
        arabicText: 'إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ',
        translation: s.story_sun_4_translation,
        amalTitle: s.story_sun_4_title,
        icon: '📖',
        bgGradient: [
          const Color(0xFF1A2B0D),
          const Color(0xFF3A5C1A),
          const Color(0xFF0D1F06),
        ],
      ),
      DayStory(
        verseRef: 'الأحزاب ۳۳:۵۶',
        arabicText: 'إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ',
        translation: s.story_sun_5_translation,
        amalTitle: s.story_sun_5_title,
        icon: '⭐',
        bgGradient: [
          const Color(0xFF2B1A0D),
          const Color(0xFF5C3A1A),
          const Color(0xFF1F130A),
        ],
      ),
    ],
  ),
  DayData(
    id: 2,
    dayLabel: s.weekday_monday,
    dayName: s.day_name_monday,
    letter: s.weekday_letter_monday,
    avatarGradient: [const Color(0xFF1A3A6B), const Color(0xFF0D1F3D)],
    stories: [
      DayStory(
        verseRef: 'آل‌عمران ۳:۱۳۳',
        arabicText:
            'وَسَارِعُوا إِلَىٰ مَغْفِرَةٍ مِّن رَّبِّكُمْ وَجَنَّةٍ عَرْضُهَا السَّمَاوَاتُ وَالْأَرْضُ',
        translation: s.story_mon_1_translation,
        amalTitle: s.story_mon_1_title,
        icon: '🏃',
        bgGradient: [
          const Color(0xFF0D1A3D),
          const Color(0xFF1A3A7A),
          const Color(0xFF060D1F),
        ],
      ),
      DayStory(
        verseRef: 'الفاتحة ۱:۲',
        arabicText: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        translation: s.story_mon_2_translation,
        amalTitle: s.story_mon_2_title,
        icon: '🙏',
        bgGradient: [
          const Color(0xFF0D2B1A),
          const Color(0xFF1A5C3A),
          const Color(0xFF060D0A),
        ],
      ),
      DayStory(
        verseRef: 'البقرة ۲:۲۲۲',
        arabicText:
            'إِنَّ اللَّهَ يُحِبُّ التَّوَّابِينَ وَيُحِبُّ الْمُتَطَهِّرِينَ',
        translation: s.story_mon_3_translation,
        amalTitle: s.story_mon_3_title,
        icon: '💧',
        bgGradient: [
          const Color(0xFF1A0D3A),
          const Color(0xFF3A1A7A),
          const Color(0xFF0D0620),
        ],
      ),
      DayStory(
        verseRef: 'التوبة ۹:۱۱۹',
        arabicText:
            'يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَكُونُوا مَعَ الصَّادِقِينَ',
        translation: s.story_mon_4_translation,
        amalTitle: s.story_mon_4_title,
        icon: '✅',
        bgGradient: [
          const Color(0xFF2B2B0D),
          const Color(0xFF5C5C1A),
          const Color(0xFF131306),
        ],
      ),
      DayStory(
        verseRef: 'المعارج ۷۰:۲۴',
        arabicText:
            'وَالَّذِينَ فِي أَمْوَالِهِمْ حَقٌّ مَّعْلُومٌ لِّلسَّائِلِ وَالْمَحْرُومِ',
        translation: s.story_mon_5_translation,
        amalTitle: s.story_mon_5_title,
        icon: '💰',
        bgGradient: [
          const Color(0xFF0D2B2B),
          const Color(0xFF1A5C5C),
          const Color(0xFF061313),
        ],
      ),
    ],
  ),
  DayData(
    id: 3,
    dayLabel: s.weekday_tuesday,
    dayName: s.day_name_tuesday,
    letter: s.weekday_letter_tuesday,
    avatarGradient: [const Color(0xFF6B4A1A), const Color(0xFF3D2A0D)],
    stories: [
      DayStory(
        verseRef: 'البقرة ۲:۲۸۶',
        arabicText:
            'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا ۚ لَهَا مَا كَسَبَتْ وَعَلَيْهَا مَا اكْتَسَبَتْ',
        translation: s.story_tue_1_translation,
        amalTitle: s.story_tue_1_title,
        icon: '🌿',
        bgGradient: [
          const Color(0xFF2B1A0D),
          const Color(0xFF5C3A1A),
          const Color(0xFF1F130A),
        ],
      ),
      DayStory(
        verseRef: 'الإخلاص ۱۱۲:۱-۲',
        arabicText: 'قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ',
        translation: s.story_tue_2_translation,
        amalTitle: s.story_tue_2_title,
        icon: '☝️',
        bgGradient: [
          const Color(0xFF1A2B0D),
          const Color(0xFF3A5C1A),
          const Color(0xFF0A1F06),
        ],
      ),
      DayStory(
        verseRef: 'الفرقان ۲۵:۶۳',
        arabicText:
            'وَعِبَادُ الرَّحْمَٰنِ الَّذِينَ يَمْشُونَ عَلَى الْأَرْضِ هَوْنًا',
        translation: s.story_tue_3_translation,
        amalTitle: s.story_tue_3_title,
        icon: '🌾',
        bgGradient: [
          const Color(0xFF1A0D2B),
          const Color(0xFF3A1A5C),
          const Color(0xFF0D0620),
        ],
      ),
      DayStory(
        verseRef: 'البقرة ۲:۱۵۳',
        arabicText: 'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ',
        translation: s.story_tue_4_translation,
        amalTitle: s.story_tue_4_title,
        icon: '⚓',
        bgGradient: [
          const Color(0xFF0D1A2B),
          const Color(0xFF1A3A5C),
          const Color(0xFF060D1F),
        ],
      ),
      DayStory(
        verseRef: 'الطلاق ۶۵:۳',
        arabicText:
            'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ ۚ إِنَّ اللَّهَ بَالِغُ أَمْرِهِ',
        translation: s.story_tue_5_translation,
        amalTitle: s.story_tue_5_title,
        icon: '🌟',
        bgGradient: [
          const Color(0xFF2B0D0D),
          const Color(0xFF5C1A1A),
          const Color(0xFF1F0A0A),
        ],
      ),
    ],
  ),
  DayData(
    id: 4,
    dayLabel: s.weekday_wednesday,
    dayName: s.day_name_wednesday,
    letter: s.weekday_letter_wednesday,
    avatarGradient: [const Color(0xFF1A6B6B), const Color(0xFF0D3D3D)],
    stories: [
      DayStory(
        verseRef: 'الرحمن ۵۵:۱۳',
        arabicText: 'فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ',
        translation: s.story_wed_1_translation,
        amalTitle: s.story_wed_1_title,
        icon: '🌺',
        bgGradient: [
          const Color(0xFF0D3A3A),
          const Color(0xFF1A7A7A),
          const Color(0xFF061F1F),
        ],
      ),
      DayStory(
        verseRef: 'الأنعام ۶:۱۶۰',
        arabicText: 'مَن جَاءَ بِالْحَسَنَةِ فَلَهُ عَشْرُ أَمْثَالِهَا',
        translation: s.story_wed_2_translation,
        amalTitle: s.story_wed_2_title,
        icon: '💚',
        bgGradient: [
          const Color(0xFF1A3A0D),
          const Color(0xFF3A7A1A),
          const Color(0xFF0D1F06),
        ],
      ),
      DayStory(
        verseRef: 'الحجرات ۴۹:۱۰',
        arabicText:
            'إِنَّمَا الْمُؤْمِنُونَ إِخْوَةٌ فَأَصْلِحُوا بَيْنَ أَخَوَيْكُمْ',
        translation: s.story_wed_3_translation,
        amalTitle: s.story_wed_3_title,
        icon: '🤝',
        bgGradient: [
          const Color(0xFF2B1A3A),
          const Color(0xFF5C3A7A),
          const Color(0xFF130D1F),
        ],
      ),
      DayStory(
        verseRef: 'طه ۲۰:۱۱۴',
        arabicText: 'وَقُل رَّبِّ زِدْنِي عِلْمًا',
        translation: s.story_wed_4_translation,
        amalTitle: s.story_wed_4_title,
        icon: '📚',
        bgGradient: [
          const Color(0xFF1A1A3A),
          const Color(0xFF3A3A7A),
          const Color(0xFF0D0D1F),
        ],
      ),
      DayStory(
        verseRef: 'غافر ۴۰:۶۰',
        arabicText: 'وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ',
        translation: s.story_wed_5_translation,
        amalTitle: s.story_wed_5_title,
        icon: '🌙',
        bgGradient: [
          const Color(0xFF0D2B1A),
          const Color(0xFF1A5C3A),
          const Color(0xFF060D0A),
        ],
      ),
    ],
  ),
  DayData(
    id: 5,
    dayLabel: s.weekday_thursday,
    dayName: s.day_name_thursday,
    letter: s.weekday_letter_thursday,
    avatarGradient: [const Color(0xFF4A1A6B), const Color(0xFF2A0D3D)],
    stories: [
      DayStory(
        verseRef: 'یس ۳۶:۸۳',
        arabicText:
            'فَسُبْحَانَ الَّذِي بِيَدِهِ مَلَكُوتُ كُلِّ شَيْءٍ وَإِلَيْهِ تُرْجَعُونَ',
        translation: s.story_thu_1_translation,
        amalTitle: s.story_thu_1_title,
        icon: '🌙',
        bgGradient: [
          const Color(0xFF1A0D3A),
          const Color(0xFF3A1A7A),
          const Color(0xFF0D0620),
        ],
      ),
      DayStory(
        verseRef: 'الجمعة ۶۲:۹',
        arabicText:
            'يَا أَيُّهَا الَّذِينَ آمَنُوا إِذَا نُودِيَ لِلصَّلَاةِ مِن يَوْمِ الْجُمُعَةِ فَاسْعَوْا إِلَىٰ ذِكْرِ اللَّهِ',
        translation: s.story_thu_2_translation,
        amalTitle: s.story_thu_2_title,
        icon: '🕌',
        bgGradient: [
          const Color(0xFF1A3A5C),
          const Color(0xFF0D2B4A),
          const Color(0xFF061520),
        ],
      ),
      DayStory(
        verseRef: 'الإسراء ۱۷:۷۹',
        arabicText: 'وَمِنَ اللَّيْلِ فَتَهَجَّدْ بِهِ نَافِلَةً لَّكَ',
        translation: s.story_thu_3_translation,
        amalTitle: s.story_thu_3_title,
        icon: '⭐',
        bgGradient: [
          const Color(0xFF0D2B1A),
          const Color(0xFF1A5C3A),
          const Color(0xFF060D0A),
        ],
      ),
      DayStory(
        verseRef: 'الذاریات ۵۱:۵۶',
        arabicText: 'وَمَا خَلَقْتُ الْجِنَّ وَالْإِنسَ إِلَّا لِيَعْبُدُونِ',
        translation: s.story_thu_4_translation,
        amalTitle: s.story_thu_4_title,
        icon: '🙏',
        bgGradient: [
          const Color(0xFF2B1A0D),
          const Color(0xFF5C3A1A),
          const Color(0xFF1F130A),
        ],
      ),
      DayStory(
        verseRef: 'الزمر ۳۹:۵۳',
        arabicText:
            'قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَىٰ أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ',
        translation: s.story_thu_5_translation,
        amalTitle: s.story_thu_5_title,
        icon: '💫',
        bgGradient: [
          const Color(0xFF0D3A3A),
          const Color(0xFF1A7A7A),
          const Color(0xFF061F1F),
        ],
      ),
    ],
  ),
  DayData(
    id: 6,
    dayLabel: s.weekday_friday,
    dayName: s.day_name_friday,
    letter: s.weekday_letter_friday,
    avatarGradient: [const Color(0xFF6B6B1A), const Color(0xFF3D3D0D)],
    stories: [
      DayStory(
        verseRef: 'الجمعة ۶۲:۱۰',
        arabicText:
            'فَإِذَا قُضِيَتِ الصَّلَاةُ فَانتَشِرُوا فِي الْأَرْضِ وَابْتَغُوا مِن فَضْلِ اللَّهِ',
        translation: s.story_fri_1_translation,
        amalTitle: s.story_fri_1_title,
        icon: '🌅',
        bgGradient: [
          const Color(0xFF2B2B0D),
          const Color(0xFF5C5C1A),
          const Color(0xFF131306),
        ],
      ),
      DayStory(
        verseRef: 'الکهف ۱۸:۱',
        arabicText:
            'الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ وَلَمْ يَجْعَل لَّهُ عِوَجًا',
        translation: s.story_fri_2_translation,
        amalTitle: s.story_fri_2_title,
        icon: '📖',
        bgGradient: [
          const Color(0xFF0D2B1A),
          const Color(0xFF1A5C3A),
          const Color(0xFF060D0A),
        ],
      ),
      DayStory(
        verseRef: 'الأحزاب ۳۳:۵۶',
        arabicText: 'إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ',
        translation: s.story_fri_3_translation,
        amalTitle: s.story_fri_3_title,
        icon: '☀️',
        bgGradient: [
          const Color(0xFF1A0D2B),
          const Color(0xFF3A1A5C),
          const Color(0xFF0D0620),
        ],
      ),
      DayStory(
        verseRef: 'التوبة ۹:۱۰۳',
        arabicText:
            'خُذْ مِنْ أَمْوَالِهِمْ صَدَقَةً تُطَهِّرُهُمْ وَتُزَكِّيهِم بِهَا',
        translation: s.story_fri_4_translation,
        amalTitle: s.story_fri_4_title,
        icon: '💝',
        bgGradient: [
          const Color(0xFF1A3A5C),
          const Color(0xFF0D2B4A),
          const Color(0xFF061520),
        ],
      ),
      DayStory(
        verseRef: 'المائدة ۵:۳۵',
        arabicText:
            'يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ وَابْتَغُوا إِلَيْهِ الْوَسِيلَةَ',
        translation: s.story_fri_5_translation,
        amalTitle: s.story_fri_5_title,
        icon: '🌟',
        bgGradient: [
          const Color(0xFF0D3A3A),
          const Color(0xFF1A7A7A),
          const Color(0xFF061F1F),
        ],
      ),
      DayStory(
        verseRef: 'الدخان ۴۴:۳',
        arabicText:
            'إِنَّا أَنزَلْنَاهُ فِي لَيْلَةٍ مُّبَارَكَةٍ ۚ إِنَّا كُنَّا مُنذِرِينَ',
        translation: s.story_fri_6_translation,
        amalTitle: s.story_fri_6_title,
        icon: '🌙',
        bgGradient: [
          const Color(0xFF1A1A3A),
          const Color(0xFF3A3A7A),
          const Color(0xFF0D0D1F),
        ],
      ),
    ],
  ),
];
