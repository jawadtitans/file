import 'package:hijri/hijri_calendar.dart';
import '../../generated/l10n.dart';

class MonthlyDeeds {
  final int month; // Hijri month number
  final String title;
  final List<String> deeds;

  const MonthlyDeeds({
    required this.month,
    required this.title,
    required this.deeds,
  });
}

List<MonthlyDeeds> monthlyDeedsList(S s) => [
  MonthlyDeeds(
    month: 7,
    title: s.monthly_deeds_rajab_title,
    deeds: [
      s.monthly_deeds_rajab_deed_1,
      s.monthly_deeds_rajab_deed_2,
      s.monthly_deeds_rajab_deed_3,
    ],
  ),
  MonthlyDeeds(
    month: 8,
    title: s.monthly_deeds_shaban_title,
    deeds: [
      s.monthly_deeds_shaban_deed_1,
      s.monthly_deeds_shaban_deed_2,
      s.monthly_deeds_shaban_deed_3,
    ],
  ),
  MonthlyDeeds(
    month: 9,
    title: s.monthly_deeds_ramadan_title,
    deeds: [
      s.monthly_deeds_ramadan_deed_1,
      s.monthly_deeds_ramadan_deed_2,
      s.monthly_deeds_ramadan_deed_3,
      s.monthly_deeds_ramadan_deed_4,
    ],
  ),
];

MonthlyDeeds? getCurrentMonthDeeds(S s) {
  final hijri = HijriCalendar.now();

  try {
    return monthlyDeedsList(
      s,
    ).firstWhere((element) => element.month == hijri.hMonth);
  } catch (_) {
    return null;
  }
}
