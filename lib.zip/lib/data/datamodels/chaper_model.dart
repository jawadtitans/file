class Chapter {
  final int surahNumber;
  final String nameEn;
  final String nameAr;
  final int versesCount;
  final int firstGlobalId;
  final int lastGlobalId;

  Chapter({
    required this.surahNumber,
    required this.nameEn,
    required this.nameAr,
    required this.versesCount,
    required this.firstGlobalId,
    required this.lastGlobalId,
  });

  factory Chapter.fromJson(Map<String, dynamic> json) {
    return Chapter(
      surahNumber: json['surah_number'],
      nameEn: json['name_en'],
      nameAr: json['name_ar'],
      versesCount: json['verses_count'],
      firstGlobalId: json['first_global_id'],
      lastGlobalId: json['last_global_id'],
    );
  }
}
