import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProgressEntry {
  final double progress;       // 0.0 – 1.0
  final DateTime lastUpdated;

  const ProgressEntry({required this.progress, required this.lastUpdated});

  bool get isComplete => progress >= 0.99;

  /// Partial progress expires after 1 day; completed entries are kept forever
  bool get isExpired {
    if (isComplete) return false;
    return DateTime.now().difference(lastUpdated).inDays >= 1;
  }

  Map<String, dynamic> toJson() => {
    'progress': progress,
    'ts': lastUpdated.millisecondsSinceEpoch,
  };

  factory ProgressEntry.fromJson(Map<String, dynamic> j) => ProgressEntry(
    progress: (j['progress'] as num).toDouble(),
    lastUpdated: DateTime.fromMillisecondsSinceEpoch(j['ts'] as int),
  );
}

class ReadingProgressNotifier extends StateNotifier<Map<String, ProgressEntry>> {
  static const _key = 'reading_progress_v2';

  ReadingProgressNotifier() : super({}) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return;
    try {
      final map = json.decode(raw) as Map<String, dynamic>;
      final entries = <String, ProgressEntry>{};
      map.forEach((k, v) {
        final entry = ProgressEntry.fromJson(v as Map<String, dynamic>);
        if (!entry.isExpired) entries[k] = entry;
      });
      state = entries;
      // persist cleaned map
      await _save();
    } catch (_) {}
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, dynamic>{};
    state.forEach((k, v) => map[k] = v.toJson());
    await prefs.setString(_key, json.encode(map));
  }

  Future<void> updateProgress(String key, double progress) async {
    final clamped = progress.clamp(0.0, 1.0);
    final current = state[key]?.progress ?? 0.0;
    // Only advance, never go back – unless completing
    if (clamped <= current && clamped < 0.99) return;
    final newMap = Map<String, ProgressEntry>.from(state);
    newMap[key] = ProgressEntry(progress: clamped, lastUpdated: DateTime.now());
    state = newMap;
    await _save();
  }

  double getProgress(String key) => state[key]?.progress ?? 0.0;

  /// Returns only non-expired entries sorted by recency
  List<MapEntry<String, ProgressEntry>> get activeEntries {
    final list = state.entries.where((e) => !e.value.isExpired).toList()
      ..sort((a, b) => b.value.lastUpdated.compareTo(a.value.lastUpdated));
    return list;
  }

  /// Returns keys of completed items (progress >= 99%)
  Set<String> get completedKeys =>
      state.entries.where((e) => e.value.isComplete).map((e) => e.key).toSet();
}

final readingProgressProvider =
    StateNotifierProvider<ReadingProgressNotifier, Map<String, ProgressEntry>>(
  (ref) => ReadingProgressNotifier(),
);
