import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';

final homeNavIndexProvider = StateProvider<int>((ref) => 0);
// this is the default Home page.
