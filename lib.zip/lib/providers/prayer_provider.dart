import 'dart:async';
import 'dart:math' as math;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/prayer_times_service.dart';

class UserLocationCoords {
  final double latitude;
  final double longitude;

  const UserLocationCoords(this.latitude, this.longitude);
}

const _defaultCoords = UserLocationCoords(34.5553, 69.2075);

final userLocationCoordsProvider =
    StateNotifierProvider<UserLocationCoordsNotifier, UserLocationCoords>(
      (ref) => UserLocationCoordsNotifier(),
    );

class UserLocationCoordsNotifier extends StateNotifier<UserLocationCoords> {
  UserLocationCoordsNotifier() : super(_defaultCoords) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final lat = prefs.getDouble('user_latitude');
    final lng = prefs.getDouble('user_longitude');
    if (lat != null && lng != null) {
      state = UserLocationCoords(lat, lng);
    }
  }

  Future<void> setCoords(double lat, double lng) async {
    state = UserLocationCoords(lat, lng);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('user_latitude', lat);
    await prefs.setDouble('user_longitude', lng);
  }

  String get nearestProvinceName {
    double minDist = double.infinity;
    AfghanProvince nearest = afghanProvinces[0];

    for (final p in afghanProvinces) {
      final d = math.sqrt(
        math.pow(p.latitude - state.latitude, 2) +
            math.pow(p.longitude - state.longitude, 2),
      );
      if (d < minDist) {
        minDist = d;
        nearest = p;
      }
    }
    return nearest.nameDari;
  }
}

final selectedMadhabProvider =
    StateNotifierProvider<MadhabNotifier, PrayerMadhab>(
      (ref) => MadhabNotifier(),
    );

class MadhabNotifier extends StateNotifier<PrayerMadhab> {
  MadhabNotifier() : super(PrayerMadhab.sunni) {
    _load();
  }

  Future<void> _load() async {
    state = await PrayerSettingsService.getMadhab();
  }

  Future<void> setMadhab(PrayerMadhab m) async {
    state = m;
    await PrayerSettingsService.saveMadhab(m);
  }
}

final prayerTimesProvider = Provider<PrayerTimes>((ref) {
  final coords = ref.watch(userLocationCoordsProvider);
  final method = ref.watch(selectedMadhabProvider) == PrayerMadhab.sunni
      ? sunniMethod
      : shiaMethod;

  return PrayerTimesCalculator.calculate(
    latitude: coords.latitude,
    longitude: coords.longitude,
    date: DateTime.now(),
    method: method,
  );
});

PrayerTimes prayerTimesForDate(
  UserLocationCoords coords,
  PrayerMadhab madhab,
  DateTime date,
) {
  final method = madhab == PrayerMadhab.sunni ? sunniMethod : shiaMethod;

  return PrayerTimesCalculator.calculate(
    latitude: coords.latitude,
    longitude: coords.longitude,
    date: date,
    method: method,
  );
}

enum PrayerCardStatus { current, next, upcoming }

class PrayerCardInfo {
  final String label;
  final String prayerName;
  final String prayerNameKey;
  final String prayerEmoji;
  final DateTime time;
  final PrayerCardStatus status;

  const PrayerCardInfo({
    required this.label,
    required this.prayerName,
    required this.prayerNameKey,
    required this.prayerEmoji,
    required this.time,
    required this.status,
  });
}

class PrayerCardsState {
  final PrayerCardInfo left;
  final PrayerCardInfo right;

  const PrayerCardsState({required this.left, required this.right});
}

final prayerCardsProvider = Provider<PrayerCardsState>((ref) {
  final times = ref.watch(prayerTimesProvider);
  final now = DateTime.now();

  final prayers = [
    ('Fajr', 'fajr', '✦', times.fajr),
    ('Dhuhr', 'dhuhr', '☀️', times.dhuhr),
    ('Asr', 'asr', '⛅', times.asr),
    ('Maghrib', 'maghrib', '🌆', times.maghrib),
    ("Isha'a", 'isha', '🌙', times.isha),
  ];

  int activeIdx = -1;

  for (int i = 0; i < prayers.length; i++) {
    final start = prayers[i].$4;
    final end = i + 1 < prayers.length
        ? prayers[i + 1].$4
        : prayers[i].$4.add(const Duration(hours: 2));

    if (now.isAfter(start) && now.isBefore(end)) {
      activeIdx = i;
      break;
    }
  }

  if (activeIdx >= 0) {
    final cur = prayers[activeIdx];
    final next = prayers[(activeIdx + 1) % prayers.length];

    return PrayerCardsState(
      left: PrayerCardInfo(
        label: 'now',
        prayerName: cur.$1,
        prayerNameKey: cur.$2,
        prayerEmoji: cur.$3,
        time: cur.$4,
        status: PrayerCardStatus.current,
      ),
      right: PrayerCardInfo(
        label: 'next',
        prayerName: next.$1,
        prayerNameKey: next.$2,
        prayerEmoji: next.$3,
        time: next.$4,
        status: PrayerCardStatus.next,
      ),
    );
  } else {
    int nextIdx = 0;

    for (int i = 0; i < prayers.length; i++) {
      if (now.isBefore(prayers[i].$4)) {
        nextIdx = i;
        break;
      }
      nextIdx = 0;
    }

    final next = prayers[nextIdx];
    final upcoming = prayers[(nextIdx + 1) % prayers.length];

    return PrayerCardsState(
      left: PrayerCardInfo(
        label: 'next',
        prayerName: next.$1,
        prayerNameKey: next.$2,
        prayerEmoji: next.$3,
        time: next.$4,
        status: PrayerCardStatus.next,
      ),
      right: PrayerCardInfo(
        label: 'upcoming',
        prayerName: upcoming.$1,
        prayerNameKey: upcoming.$2,
        prayerEmoji: upcoming.$3,
        time: upcoming.$4,
        status: PrayerCardStatus.upcoming,
      ),
    );
  }
});

// ── Prayed Prayers Today ───────────────────────────────────────────────────

class PrayedPrayersNotifier extends StateNotifier<Set<String>> {
  PrayedPrayersNotifier() : super({}) {
    _load();
  }

  static String _todayKey() {
    final d = DateTime.now();
    return 'prayed_${d.year}_${d.month}_${d.day}';
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = (prefs.getStringList(_todayKey()) ?? []).toSet();
  }

  Future<void> toggle(String prayer) async {
    final s = Set<String>.from(state);
    if (s.contains(prayer)) {
      s.remove(prayer);
    } else {
      s.add(prayer);
    }
    state = s;

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_todayKey(), s.toList());
  }

  bool isDone(String prayer) => state.contains(prayer);
  int get doneCount => state.length;
}

final prayedPrayersProvider =
    StateNotifierProvider<PrayedPrayersNotifier, Set<String>>(
      (ref) => PrayedPrayersNotifier(),
    );

// ── Adhan Sound Provider ───────────────────────────────────────────────────

final selectedAdhanSoundProvider =
    StateNotifierProvider<AdhanSoundNotifier, String>(
      (ref) => AdhanSoundNotifier(),
    );

class AdhanSoundNotifier extends StateNotifier<String> {
  AdhanSoundNotifier() : super('adhan_makkah') {
    _load();
  }

  Future<void> _load() async {
    state = await PrayerSettingsService.getAdhanSound();
  }

  Future<void> setSound(String k) async {
    state = k;
    await PrayerSettingsService.saveAdhanSound(k);
  }
}

class AdhanScheduler {
  Timer? _timer;

  void schedule({
    required PrayerTimes times,
    required void Function(String prayerName, String prayerTime) onAdhan,
  }) {
    _timer?.cancel();
    final now = DateTime.now();

    final prayers = [
      ('Fajr', times.fajr),
      ('Dhuhr', times.dhuhr),
      ('Asr', times.asr),
      ('Maghrib', times.maghrib),
      ('Isha', times.isha),
    ];

    DateTime? nextTime;
    String nextName = '';

    for (final p in prayers) {
      if (p.$2.isAfter(now)) {
        nextTime = p.$2;
        nextName = p.$1;
        break;
      }
    }

    if (nextTime == null) return;

    final diff = nextTime.difference(now);
    _timer = Timer(diff, () {
      final h = nextTime!.hour > 12
          ? nextTime.hour - 12
          : (nextTime.hour == 0 ? 12 : nextTime.hour);
      final m = nextTime.minute.toString().padLeft(2, '0');
      final period = nextTime.hour >= 12 ? 'PM' : 'AM';
      onAdhan(nextName, '$h:$m $period');
    });
  }

  void cancel() => _timer?.cancel();
}

final adhanSchedulerProvider = Provider<AdhanScheduler>((ref) {
  final scheduler = AdhanScheduler();
  ref.onDispose(scheduler.cancel);
  return scheduler;
});

final selectedProvinceProvider = StateNotifierProvider<_DummyProvince, int>(
  (ref) => _DummyProvince(),
);

class _DummyProvince extends StateNotifier<int> {
  _DummyProvince() : super(0);
}
