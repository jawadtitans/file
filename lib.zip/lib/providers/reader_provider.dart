import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';

final readerProvider = StateNotifierProvider<ReaderNotifier, ReaderState>((
  ref,
) {
  return ReaderNotifier();
});

class ReaderState {
  final List<dynamic> verses;
  final bool loading;
  final double fontSize;
  final int? highlightAyah;

  ReaderState({
    required this.verses,
    required this.loading,
    required this.fontSize,
    this.highlightAyah,
  });

  ReaderState copyWith({
    List<dynamic>? verses,
    bool? loading,
    double? fontSize,
    int? highlightAyah,
  }) {
    return ReaderState(
      verses: verses ?? this.verses,
      loading: loading ?? this.loading,
      fontSize: fontSize ?? this.fontSize,
      highlightAyah: highlightAyah ?? this.highlightAyah,
    );
  }
}

class ReaderNotifier extends StateNotifier<ReaderState> {
  ReaderNotifier()
    : super(ReaderState(verses: [], loading: true, fontSize: 30));

  static const Map<int, List<int>> _juzRanges = {
    1: [1, 148],
    2: [149, 259],
    3: [260, 385],
    4: [386, 516],
    5: [517, 640],
    6: [641, 750],
    7: [751, 899],
    8: [900, 1041],
    9: [1042, 1200],
    10: [1201, 1327],
    11: [1328, 1478],
    12: [1479, 1648],
    13: [1649, 1802],
    14: [1803, 2029],
    15: [2030, 2214],
    16: [2215, 2483],
    17: [2484, 2673],
    18: [2674, 2875],
    19: [2876, 3214],
    20: [3215, 3385],
    21: [3386, 3563],
    22: [3564, 3732],
    23: [3733, 4089],
    24: [4090, 4264],
    25: [4265, 4510],
    26: [4511, 4705],
    27: [4706, 5104],
    28: [5105, 5241],
    29: [5242, 5672],
    30: [5673, 6236],
  };

  Future<void> loadFontSize() async {
    final prefs = await SharedPreferences.getInstance();
    state = state.copyWith(fontSize: prefs.getDouble('quran_font_size') ?? 30);
  }

  Future<void> loadContent({int? surahNumber, int? juzNumber}) async {
    final response = await rootBundle.loadString('assets/json/quran.json');
    final data = json.decode(response);
    final all = data['verses'] as List<dynamic>;

    List<dynamic> filtered = [];

    if (surahNumber != null) {
      filtered = all.where((v) => v['surah'] == surahNumber).toList();
    }

    if (juzNumber != null) {
      final range = _juzRanges[juzNumber];
      if (range != null) {
        filtered = all.where((v) {
          final id = v['global_id'] as int;
          return id >= range[0] && id <= range[1];
        }).toList();
      }
    }

    state = state.copyWith(verses: filtered, loading: false);
  }

  void setHighlight(int? ayah) {
    state = state.copyWith(highlightAyah: ayah);
  }
}
