import 'package:flutter/material.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:shared_preferences/shared_preferences.dart';

//  ======= bookmark provider section for the // Bookmark Providers and Notifier
// These providers manage bookmarked Surahs and Juz using Riverpod's StateNotifier.
// Each provider creates a BookmarksNotifier with a unique key to store/retrieve data
// from SharedPreferences. The notifier handles:
//   - Loading saved bookmarks (_load)
//   - Checking if an item is bookmarked (isBookmarked)
//   - Toggling bookmarks on/off (toggle)
// The state is a Set<int> representing IDs of bookmarked items.

final bookmarkedSurahsProvider =
    StateNotifierProvider<BookmarksNotifier, Set<int>>(
      (ref) => BookmarksNotifier('bookmarked_surahs'),
    );
final bookmarkedJuzProvider =
    StateNotifierProvider<BookmarksNotifier, Set<int>>(
      (ref) => BookmarksNotifier('bookmarked_juz'),
    );

class BookmarksNotifier extends StateNotifier<Set<int>> {
  final String key;

  BookmarksNotifier(this.key) : super({}) {
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(key) ?? [];
    state = list.map(int.parse).toSet();
  }

  bool isBookmarked(int id) => state.contains(id);

  Future<void> toggle(int id) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(key) ?? [];

    if (list.contains(id.toString())) {
      list.remove(id.toString());
      state = {...state}..remove(id);
    } else {
      list.add(id.toString());
      state = {...state, id};
    }

    await prefs.setStringList(key, list);
  }
}
