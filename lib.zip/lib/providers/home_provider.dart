import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// ============================ Quran Data provider for the home page contents in here =================================

final surahProvider = FutureProvider<List<dynamic>>((ref) async {
  final data = await rootBundle.loadString('assets/json/surah.json');
  return json.decode(data);
});

final versesProvider = FutureProvider<List<dynamic>>((ref) async {
  final data = await rootBundle.loadString('assets/json/quran.json');
  return json.decode(data)['verses'];
});

final juzProvider = FutureProvider<List<dynamic>>((ref) async {
  final data = await rootBundle.loadString('assets/json/quran_juzs.json');
  return json.decode(data);
});
