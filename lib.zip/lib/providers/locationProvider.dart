import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:geolocator/geolocator.dart';

final locationProvider =
    StateNotifierProvider<LocationNotifier, AsyncValue<Position?>>(
      (ref) => LocationNotifier(),
    );

class LocationNotifier extends StateNotifier<AsyncValue<Position?>> {
  LocationNotifier() : super(const AsyncValue.data(null));

  Future<Position?> getCurrentLocation() async {
    state = const AsyncValue.loading();

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      print("SERVICE ENABLED: $serviceEnabled");

      if (!serviceEnabled) {
        state = AsyncValue.error(
          "Location service disabled",
          StackTrace.current,
        );
        return null;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      print("PERMISSION BEFORE: $permission");

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        print("PERMISSION AFTER REQUEST: $permission");
      }

      if (permission == LocationPermission.deniedForever) {
        print("PERMISSION DENIED FOREVER");
        state = AsyncValue.error(
          "Permission denied forever",
          StackTrace.current,
        );
        await Geolocator.openAppSettings();
        return null;
      }

      if (permission == LocationPermission.denied) {
        print("PERMISSION STILL DENIED");
        state = AsyncValue.error("Permission denied", StackTrace.current);
        return null;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      print("POSITION: ${position.latitude}, ${position.longitude}");

      state = AsyncValue.data(position);
      return position;
    } catch (e) {
      print("LOCATION ERROR: $e");
      state = AsyncValue.error(e, StackTrace.current);
      return null;
    }
  }
}
