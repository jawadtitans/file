import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/onboarding_local_service.dart';

final onboardingControllerProvider =
    AsyncNotifierProvider<OnboardingController, bool>(OnboardingController.new);

class OnboardingController extends AsyncNotifier<bool> {
  late final OnboardingLocalService _service;

  @override
  Future<bool> build() async {
    _service = OnboardingLocalService();
    return _service.isCompleted();
  }

  Future<void> completeOnboarding() async {
    await _service.setCompleted();
    state = const AsyncData(true);
  }
}
