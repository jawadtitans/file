import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../services/onboarding_local_service.dart';

final splashProvider = AsyncNotifierProvider<SplashController, bool>(
  SplashController.new,
);

class SplashController extends AsyncNotifier<bool> {
  late final OnboardingLocalService _service;

  @override
  Future<bool> build() async {
    _service = OnboardingLocalService();
    // Simulate splash delay (so animation finishes)
    await Future.delayed(const Duration(seconds: 3));
    final completed = await _service.isCompleted();
    return completed;
  }
}
