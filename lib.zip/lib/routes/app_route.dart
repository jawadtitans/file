import 'package:flutter/cupertino.dart';
import 'package:quran_app/data/datamodels/days_data.dart';
import 'package:quran_app/feature/views/features/feature_pages.dart';
import 'package:quran_app/feature/views/Quran/Quran_view.dart';
import '../data/datamodels/weeks_events_model.dart';
import '../exportfile.dart';
import '../feature/views/homes/story_view.dart';
import '../feature/views/onboarding/first_onboarding.dart';
import '../feature/views/onboarding/setup_page_onboarding.dart';

class AppRoutes {
  static const String splash = '/';
  static const String welcome = '/welcome';
  static const String onboarding = '/onboarding';
  static const String home = '/home';
  static const String story_view = '/story-view';
  static const String prayerTimePage = '/prayer-time';
  static const String quranPage = '/quran';
  static const String tasbihPage = '/tasbih';
  static const String qiblaPage = '/qibla';
  static const String duasPage = '/duas';
  static const String khatamPage = '/khatam';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return CupertinoPageRoute(builder: (_) => const SplashScreen());
      case welcome:
        return CupertinoPageRoute(builder: (_) => const WelcomePage());
      case story_view:
        final dayData = settings.arguments as DayData;
        return CupertinoPageRoute(
          builder: (_) => StoryViewScreen(dayData: dayData),
        );
      case onboarding:
        return CupertinoPageRoute(builder: (_) => const OnboardingPage());
      case home:
        return CupertinoPageRoute(
          builder: (_) => const HomePage(initialSelectedIndex: 2),
        );
      case quranPage:
        return CupertinoPageRoute(builder: (_) => const QuranView());
      case prayerTimePage:
        return CupertinoPageRoute(builder: (_) => const PrayerTime());
      case tasbihPage:
        return CupertinoPageRoute(builder: (_) => const TasbihPage());
      case qiblaPage:
        return CupertinoPageRoute(builder: (_) => const QiblaPage());
      case duasPage:
        return CupertinoPageRoute(builder: (_) => const DuasPage());
      case khatamPage:
        return CupertinoPageRoute(builder: (_) => const KhatamPage());
      default:
        return CupertinoPageRoute(builder: (_) => const SplashScreen());
    }
  }
}
