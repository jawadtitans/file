import 'package:flutter/material.dart';

class QuranColors {
  QuranColors._();
  // App Basic Color
  static const Color creamColor = Color(0xFFF5F5DC);
  static const Color deepGreenColor = Color(0xFF003232);
  static const Color goldAccentColor = Color(0xFFFFD700);
  static const Color greenPrimary = Color(0xFF00D082);
  static const Color cardColors = Color(0xFF1a4848);
  static const Color prayer_cardColor = Color(0xFF0A2826);
  // Background Color

  // Text Color

  // Button Color

  //Container Border

  //Container Shadow Color

  //Text Field Fill Color

  //Rating Color

  // Icon Color

  // Gradient color
}
