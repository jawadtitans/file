import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:shamsi_date/shamsi_date.dart';
import 'package:intl/intl.dart';

class DateHelper {
  DateHelper._();
  static String hijriMonth(BuildContext context, DateTime now) {
    final hijri = HijriCalendar.fromDate(now);

    final Map<int, String> hijriMonthsFa = {
      1: 'محرم',
      2: 'صفر',
      3: 'ربیع‌الاول',
      4: 'ربیع‌الثانی',
      5: 'جمادی‌الاول',
      6: 'جمادی‌الثانی',
      7: 'رجب',
      8: 'شعبان',
      9: 'رمضان',
      10: 'شوال',
      11: 'ذی‌القعده',
      12: 'ذی‌الحجه',
    };

    final locale = Localizations.localeOf(context).languageCode;

    if (locale == 'fa') {
      return hijriMonthsFa[hijri.hMonth] ?? '';
    }

    return hijri.longMonthName;
  }

  static String hijriDate(BuildContext context, DateTime now) {
    final hijri = HijriCalendar.fromDate(
      now,
    ); // convert by the method of the HijriCalendar.fromDate ok using the method of the fromDate ok......
    final Map<int, String> hijriMonthsFa = {
      1: 'محرم',
      2: 'صفر',
      3: 'ربیع‌الاول',
      4: 'ربیع‌الثانی',
      5: 'جمادی‌الاول',
      6: 'جمادی‌الثانی',
      7: 'رجب',
      8: 'شعبان',
      9: 'رمضان',
      10: 'شوال',
      11: 'ذی‌القعده',
      12: 'ذی‌الحجه',
    };

    final locale = Localizations.localeOf(context).languageCode;

    if (locale == 'fa') {
      final month = hijriMonthsFa[hijri.hMonth] ?? '';
      return '${hijri.hDay} $month ${hijri.hYear}';
    }

    return '${hijri.hDay} ${hijri.longMonthName} ${hijri.hYear}';
  }

  static String shamsiDate(BuildContext context, DateTime now) {
    final jalali = Jalali.fromDateTime(now);

    final locale = Localizations.localeOf(context).languageCode;

    // Persian month names
    final monthsFa = [
      'حمل',
      'ثور',
      'جوزا',
      'سرطان',
      'اسد',
      'سنبله',
      'میزان',
      'عقرب',
      'قوس',
      'جدی',
      'دلو',
      'حوت',
    ];

    // English month names (Jalali)
    final monthsEn = [
      'Hamal',
      'Saur',
      'Jawza',
      'Saratan',
      'Asad',
      'Sunbula',
      'Mizan',
      'Aqrab',
      'Qaws',
      'Jadi',
      'Dalwa',
      'Hut',
    ];

    if (locale == 'fa') {
      return '${jalali.day} ${monthsFa[jalali.month - 1]} ${jalali.year}';
    }

    return '${jalali.day} ${monthsEn[jalali.month - 1]} ${jalali.year}';
  }

  static String time12h(DateTime now) {
    return DateFormat('hh:mm:ss a').format(now);
  }
}
