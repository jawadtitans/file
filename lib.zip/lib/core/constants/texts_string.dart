import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:hugeicons/hugeicons.dart';
import '../../exportfile.dart';
import '../../generated/l10n.dart';
import '../commons/ui_components/home/bottom_nav_section.dart';

class const_texts {
  static const String fontname = "Arabic";

  static final List<Map<String, dynamic>> features = [
    {'label': 'Quran', 'icon': Iconsax.menu},
    {'label': 'Adzan', 'icon': Iconsax.volume_up_copy},
    {'label': 'Qibla', 'icon': Iconsax.export_2_copy},
    {'label': 'Donation', 'icon': Iconsax.favorite_chart},
    {'label': 'All', 'icon': Iconsax.grid_1_copy},
  ];
  static List<BottomNavItem> getBottomNavItems(BuildContext context) {
    return [
      BottomNavItem(
        icon: "assets/webp/islam.png",
        label: S.of(context)!.nav_islam,
      ),
      BottomNavItem(
        icon: "assets/webp/prayer.png",
        label: S.of(context)!.nav_prayer,
      ),
      BottomNavItem(
        icon: "assets/webp/quran.png",
        label: S.of(context)!.nav_Quran,
      ),
      BottomNavItem(
        icon: "assets/webp/bookmark.png",
        label: S.of(context)!.bookmar_title,
      ),
      BottomNavItem(
        icon: "assets/webp/setting.png",
        label: S.of(context)!.nav_settings,
      ),
    ];
  }
}
