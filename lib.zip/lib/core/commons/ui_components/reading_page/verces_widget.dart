import 'package:flutter/material.dart';

class VerseWidget extends StatelessWidget {
  final String text;
  final int ayah;
  final bool highlight;

  const VerseWidget({
    super.key,
    required this.text,
    required this.ayah,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: "$text ",
            style: TextStyle(backgroundColor: Colors.black),
          ),
          TextSpan(
            text: "﴿$ayah﴾ ",
            style: TextStyle(
              fontSize: 22,
              color: Colors.black54,
              backgroundColor: Colors.black,
            ),
          ),
        ],
        style: TextStyle(
          fontFamily: "Quran",
          fontSize: 30,
          height: 1.8,
          color: Colors.black,
        ),
      ),
    );
  }
}
