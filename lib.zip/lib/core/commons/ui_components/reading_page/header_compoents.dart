import 'package:flutter/material.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:quran_app/core/constants/colors.dart';

class ReaderHeader extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback onToggleMode;
  final VoidCallback onAutoScroll;
  final VoidCallback onSpeed;

  final bool isAutoScroll;
  final bool isPageMode;

  const ReaderHeader({
    super.key,
    required this.title,
    required this.onToggleMode,
    required this.onAutoScroll,
    required this.onSpeed,
    required this.isAutoScroll,
    required this.isPageMode,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: QuranColors.creamColor,
      leading: IconButton(
        icon: const Icon(Iconsax.arrow_right_3_copy, color: Colors.black),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(title, style: Theme.of(context).textTheme.labelSmall),
      actions: [
        IconButton(
          icon: Icon(
            isAutoScroll ? Icons.pause : Icons.play_arrow,
            color: Colors.black,
          ),
          onPressed: onAutoScroll,
        ),
        IconButton(
          icon: const Icon(Icons.speed, color: Colors.black),
          onPressed: onSpeed,
        ),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(50);
}
