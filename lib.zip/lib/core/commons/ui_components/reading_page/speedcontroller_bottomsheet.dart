import 'package:flutter/material.dart';

class SpeedControlBottomSheet extends StatefulWidget {
  final double speed;
  final ValueChanged<double> onChanged;

  const SpeedControlBottomSheet({
    super.key,
    required this.speed,
    required this.onChanged,
  });

  @override
  State<SpeedControlBottomSheet> createState() =>
      _SpeedControlBottomSheetState();
}

class _SpeedControlBottomSheetState extends State<SpeedControlBottomSheet> {
  late double _currentSpeed;

  @override
  void initState() {
    super.initState();
    _currentSpeed = widget.speed.clamp(10.0, 200.0);
  }

  String _label(double v) {
    if (v <= 40) return 'Slow';
    if (v <= 90) return 'Normal';
    if (v <= 140) return 'Fast';
    return 'Very Fast';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Drag handle
          Center(
            child: Container(
              width: 40,
              height: 5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.grey.shade400,
              ),
            ),
          ),

          const SizedBox(height: 20),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Scroll Speed',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A3A30),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  _label(_currentSpeed),
                  style: const TextStyle(
                    color: Color(0xFF22C55E),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Speed markers
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: ['Slow', 'Normal', 'Fast', 'Very Fast'].map((l) {
              return Text(
                l,
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.grey.shade500,
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 4),

          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFF22C55E),
              inactiveTrackColor: const Color(0xFFD1D5DB),
              thumbColor: const Color(0xFF22C55E),
              overlayColor: const Color(0xFF22C55E).withOpacity(0.15),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 12),
              trackHeight: 6,
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 22),
            ),
            child: Slider(
              min: 10,
              max: 200,
              divisions: 19,
              value: _currentSpeed,
              onChanged: (v) {
                setState(() => _currentSpeed = v);
                widget.onChanged(v);
              },
            ),
          ),

          const SizedBox(height: 4),

          Center(
            child: Text(
              '${_currentSpeed.round()} px / sec',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
