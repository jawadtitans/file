import 'package:flutter/material.dart';

/// Draws small stars/crosses in the header background
class HeaderStarsPainter extends CustomPainter {
  final double opacity;
  final Color color;

  HeaderStarsPainter({this.opacity = 0.3, this.color = Colors.white});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    // Predefined star positions as fractions of width/height
    const stars = [
      [0.08, 0.10],
      [0.90, 0.08],
      [0.25, 0.18],
      [0.70, 0.22],
      [0.45, 0.06],
      [0.15, 0.55],
      [0.82, 0.48],
      [0.60, 0.35],
      [0.35, 0.68],
      [0.92, 0.72],
      [0.05, 0.82],
    ];

    for (final s in stars) {
      final cx = s[0] * size.width;
      final cy = s[1] * size.height;
      const half = 5.0;

      // Draw small cross
      canvas.drawLine(Offset(cx - half, cy), Offset(cx + half, cy), paint);
      canvas.drawLine(Offset(cx, cy - half), Offset(cx, cy + half), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
