import 'package:flutter/material.dart';

import '../../../../data/datamodels/months_model.dart';
import '../../../../generated/l10n.dart';
import '../../../constants/colors.dart';

class MonthlyDeedsCard extends StatelessWidget {
  const MonthlyDeedsCard({super.key});

  @override
  Widget build(BuildContext context) {
    final deedsData = getCurrentMonthDeeds(S.of(context)!);

    if (deedsData == null) {
      return const SizedBox();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: QuranColors.cardColors, // fallback color
          borderRadius: BorderRadius.circular(18),
          image: const DecorationImage(
            image: AssetImage(
              'assets/webp/o.webp',
            ), // replace with your image URL
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              textAlign: TextAlign.center,
              deedsData.title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ...deedsData.deeds.map(
              (deed) => Padding(
                padding: const EdgeInsets.only(bottom: 6, left: 18, right: 18),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18.0),
                  child: Row(
                    children: [
                      const Text(
                        textAlign: TextAlign.center,
                        "• ",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          deed,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
