import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../../generated/l10n.dart';
import '../../../constants/colors.dart';
import '../../../constants/date_convertion.dart';

class custom_appbar extends StatelessWidget implements PreferredSizeWidget {
  const custom_appbar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 1,
      automaticallyImplyLeading: false,
      title: Center(
        child: Row(
          children: [
            const Icon(Iconsax.calendar, size: 20, color: Colors.white),
            const SizedBox(width: 6),

            AnimatedTextKit(
              repeatForever: true,
              animatedTexts: [
                RotateAnimatedText(
                  duration: Duration(seconds: 30),
                  DateHelper.hijriDate(context, DateTime.now()),
                  textStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                RotateAnimatedText(
                  duration: Duration(seconds: 30),
                  DateHelper.shamsiDate(context, DateTime.now()),
                  textStyle: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: QuranColors.cardColors,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 7),
                child: Text(
                  S.of(context)!.today_zikr,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: QuranColors.creamColor,
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: Image.asset(
                  "assets/webp/icon_appbar.webp",
                  fit: BoxFit.cover,
                  width: 35,
                  height: 35,
                ),
              ),
            ],
          ),
        ),

        Container(
          margin: const EdgeInsets.symmetric(horizontal: 15),
          padding: const EdgeInsets.all(9),
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: QuranColors.cardColors,
          ),
          child: const Icon(Iconsax.notification),
        ),
      ],
    );
  }

  // **Required for PreferredSizeWidget**
  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
