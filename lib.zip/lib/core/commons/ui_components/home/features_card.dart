import 'package:flutter/material.dart';

import '../../../constants/colors.dart';

class FeatureCard extends StatefulWidget {
  final String title;
  final String emoji;
  final VoidCallback onTap;

  const FeatureCard({
    required this.title,
    required this.emoji,
    required this.onTap,
  });

  @override
  State<FeatureCard> createState() => _FeatureCardState();
}

class _FeatureCardState extends State<FeatureCard> {
  double scale = 1.0;

  void _onTapDown(TapDownDetails details) {
    setState(() {
      scale = 0.95; // shrink
    });
  }

  void _onTapUp(TapUpDetails details) {
    setState(() {
      scale = 1.0;
    });
    widget.onTap();
  }

  void _onTapCancel() {
    setState(() {
      scale = 1.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: _onTapDown,
      onTapUp: _onTapUp,
      onTapCancel: _onTapCancel,
      child: AnimatedScale(
        scale: scale,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: QuranColors.cardColors,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                widget.emoji,
                scale: 13,
                fit: BoxFit.cover,
                width: 45,
                height: 45,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 33.0),
                child: Text(
                  overflow: TextOverflow.ellipsis,
                  widget.title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//  this is the best consultatn in here where i were able to find out the main context in the side of dvelopment in here so, what i want to build right niw in erhere is very specific in here ok so, let's build one the bset apliation for the friends in here....
