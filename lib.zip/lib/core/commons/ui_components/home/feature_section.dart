import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../feature/views/reader/reader.dart';
import '../../../../generated/l10n.dart';
import '../../../../providers/bookmark_provider.dart';
import '../../../../providers/home_provider.dart';
import '../../../constants/colors.dart';
import 'listitems.dart';

class QuranContentSection extends ConsumerWidget {
  const QuranContentSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final surahsAsync = ref.watch(surahProvider);
    final juzAsync = ref.watch(juzProvider);
    final locale = Localizations.localeOf(context).languageCode;
    final isPersian = locale == 'fa';
    return DefaultTabController(
      length: 2,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  S.of(context)!.al_quran,
                  style: const TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  height: 38,
                  width: 200,
                  decoration: BoxDecoration(
                    color: QuranColors.cardColors,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: TabBar(
                    indicatorSize: TabBarIndicatorSize.tab,
                    dividerColor: Colors.transparent,
                    labelColor: QuranColors.creamColor,
                    unselectedLabelColor: QuranColors.creamColor,
                    indicator: BoxDecoration(
                      color: QuranColors.greenPrimary,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    tabs: [
                      Tab(text: S.of(context)!.tab_surah),
                      Tab(text: S.of(context)!.tab_juz),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TabBarView(
              children: [
                surahsAsync.when(
                  data: (surahs) => _buildSurahList(ref, surahs, isPersian),
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (e, _) => Center(child: Text(e.toString())),
                ),
                juzAsync.when(
                  data: (juz) => _buildJuzList(ref, juz, isPersian),
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (e, _) => Center(child: Text(e.toString())),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSurahList(WidgetRef ref, List<dynamic> surahs, bool isPersian) {
    final bookmarks = ref.watch(bookmarkedSurahsProvider);

    return ListView.builder(
      itemCount: surahs.length,
      itemBuilder: (context, index) {
        final surah = surahs[index];
        final String name = isPersian ? surah['nameAr'] : surah['nameEn'];
        final int surahNumber = int.parse(surah['number'].toString());

        return BuildQuranItem(
          is_juz: false,
          isBookmarked: bookmarks.contains(surahNumber),
          number: surahNumber.toString(),
          nameEn: name,
          nameAr: surah['nameAr'],
          ayahs: "${surah['ayahs']} ${S.of(context)!.tab_Ayah}",
          revelationType: surah['type'],
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ReaderPage(surahNumber: surahNumber, surahName: name),
              ),
            );
          },
          onBookmark: () {
            ref.read(bookmarkedSurahsProvider.notifier).toggle(surahNumber);
          },
        );
      },
    );
  }

  Widget _buildJuzList(WidgetRef ref, List<dynamic> juzList, bool isPersian) {
    final bookmarks = ref.watch(bookmarkedJuzProvider);

    return ListView.builder(
      itemCount: juzList.length,
      itemBuilder: (context, index) {
        final juz = juzList[index] as Map<String, dynamic>;

        final String name = isPersian ? juz['name_ar'] : juz['name'];
        final int number = juz['number'];

        return BuildQuranItem(
          is_juz: true,
          isBookmarked: bookmarks.contains(number),
          number: number.toString(),
          nameEn: name,
          nameAr: "",
          ayahs: "",
          revelationType: "",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ReaderPage(juzNumber: number)),
            );
          },
          onBookmark: () {
            ref.read(bookmarkedJuzProvider.notifier).toggle(number);
          },
        );
      },
    );
  }
}
