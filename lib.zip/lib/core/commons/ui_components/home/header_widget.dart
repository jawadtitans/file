import 'package:flutter/material.dart';

import '../../../constants/colors.dart';
import '../../../constants/date_convertion.dart';

class header extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool is_month_header;
  const header({
    super.key,
    required this.title,
    required this.subtitle,
    this.is_month_header = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Row(
            children: [
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (is_month_header)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3.0),
                  child: Text(
                    DateHelper.hijriMonth(context, DateTime.now()),
                    style: TextStyle(
                      color: QuranColors.greenPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }
}
