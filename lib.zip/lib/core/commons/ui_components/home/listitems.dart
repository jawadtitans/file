import 'package:flutter/material.dart';
import '../../../constants/colors.dart';

class BuildQuranItem extends StatelessWidget {
  final bool is_juz;
  final bool isBookmarked; // 👈 NEW
  final String number;
  final String nameEn;
  final String nameAr;
  final String ayahs;
  final String revelationType;
  final VoidCallback onTap;
  final VoidCallback? onBookmark;
  final bool? is_visible_icon;
  final Widget? trailing;

  const BuildQuranItem({
    super.key,
    required this.is_juz,
    required this.isBookmarked, // 👈 NEW
    required this.number,
    required this.nameEn,
    required this.nameAr,
    required this.ayahs,
    required this.revelationType,
    required this.onTap,
    this.onBookmark,
    this.trailing,
    this.is_visible_icon = true,
  });

  @override
  Widget build(BuildContext context) {
    final bool isMeccan =
        revelationType.toLowerCase() == 'meccan' ||
        revelationType.toLowerCase() == 'makkah';

    final String cityImage = isMeccan
        ? 'assets/webp/mecca.png'
        : 'assets/webp/madian.png';
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        border: Border.all(
          width: 0.5,
          color: QuranColors.creamColor.withOpacity(0.1),
        ),
        color: QuranColors.cardColors,
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        splashColor: QuranColors.deepGreenColor.withOpacity(0.3),
        highlightColor: QuranColors.deepGreenColor.withOpacity(0.1),
        child: Row(
          children: [
            // Number badge
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: QuranColors.deepGreenColor,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: Text(
                number,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: QuranColors.creamColor,
                ),
              ),
            ),
            const SizedBox(width: 12),

            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    nameEn,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: QuranColors.creamColor,
                    ),
                  ),

                  if (!is_juz) ...[
                    const SizedBox(height: 3),
                    Text(
                      ayahs,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            if (!is_juz && is_visible_icon!) ...[
              const SizedBox(width: 10),
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage(cityImage),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ],

            const SizedBox(width: 10),

            // Bookmark icon (filled or border)
            if (onBookmark != null)
              IconButton(
                icon: Icon(
                  isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                  color: isBookmarked
                      ? QuranColors.greenPrimary
                      : QuranColors.creamColor,
                ),
                onPressed: onBookmark,
              ),

            if (trailing != null) trailing!,
          ],
        ),
      ),
    );
  }
}
