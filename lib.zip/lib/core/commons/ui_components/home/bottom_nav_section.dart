import 'package:flutter/material.dart';
import '../../../constants/colors.dart';

class BottomNav extends StatelessWidget {
  final List<BottomNavItem> items;
  final int selectedIndex;
  final ValueChanged<int> onTap;

  const BottomNav({
    super.key,
    required this.items,
    required this.selectedIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    if (items.length < 5) {
      return const SizedBox.shrink();
    }

    return BottomAppBar(
      height: 65,
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,

      color: QuranColors.deepGreenColor,
      elevation: 0,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 70,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildItem(items[0], 0),
              _buildItem(items[1], 1),
              const SizedBox(width: 80),
              _buildItem(items[3], 3),
              _buildItem(items[4], 4),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildItem(BottomNavItem item, int index) {
    final isSelected = index == selectedIndex;

    return InkWell(
      highlightColor: Colors.transparent,
      splashFactory: InkRipple.splashFactory,
      splashColor: Colors.transparent,
      onTap: () => onTap(index),
      borderRadius: BorderRadius.circular(45),
      child: SizedBox(
        width: 63,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              item.icon,
              scale: 25,
              color: isSelected ? QuranColors.creamColor : Colors.grey.shade500,
            ),
            const SizedBox(height: 3),
            Text(
              item.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                //  this
                fontSize: 12,
                color: isSelected
                    ? QuranColors.creamColor
                    : Colors.grey.shade500,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BottomNavItem {
  final String icon;
  final String label;

  const BottomNavItem({required this.icon, required this.label});
}
