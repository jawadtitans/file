import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:quran_app/core/constants/colors.dart';

class GoalButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  final bool selected;

  const GoalButton({
    super.key,
    required this.title,
    required this.icon,
    required this.onTap,
    required this.selected,
  });

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(50);

    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: radius,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeInOut,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: radius,

                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: selected
                      ? [
                          Colors.white.withOpacity(0.28),
                          QuranColors.greenPrimary.withOpacity(0.18),
                          Colors.white.withOpacity(0.08),
                        ]
                      : [
                          Colors.white.withOpacity(0.14),
                          Colors.white.withOpacity(0.06),
                        ],
                ),

                // ✨ Glass border
                border: Border.all(
                  color: selected
                      ? Colors.white.withOpacity(0.6)
                      : Colors.white.withOpacity(0.25),
                  width: 1.2,
                ),
              ),

              child: Stack(
                children: [
                  Row(
                    children: [
                      // Icon bubble
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.15),
                        ),
                        child: Icon(icon, color: Colors.white, size: 20),
                      ),

                      const SizedBox(width: 12),

                      Expanded(
                        child: Text(
                          title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),

                      // ✔ Selected indicator
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: selected
                              ? Colors.white
                              : Colors.white.withOpacity(0.08),
                          border: Border.all(
                            color: Colors.white.withOpacity(
                              selected ? 0.7 : 0.25,
                            ),
                          ),
                        ),
                        child: selected
                            ? const Icon(
                                Icons.check,
                                size: 14,
                                color: Colors.black,
                              )
                            : null,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
