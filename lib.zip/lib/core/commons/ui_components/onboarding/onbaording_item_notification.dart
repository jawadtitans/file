import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:quran_app/core/constants/colors.dart';

class NotificationAdhan extends StatelessWidget {
  const NotificationAdhan({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,

      children: [
        Center(
          child: Image.network(
            'https://cdn3d.iconscout.com/3d/premium/thumb/voice-message-10276034-8306582.png',
            width: 170,
            height: 170,
            fit: BoxFit.cover,
            // loading while fetching image
            loadingBuilder: (context, child, loadingProgress) {
              if (loadingProgress == null) return child;
              return CupertinoActivityIndicator(color: QuranColors.creamColor);
            },
            // offline or error state
            errorBuilder: (context, error, stackTrace) {
              return CupertinoActivityIndicator(color: QuranColors.creamColor);
            },
          ),
        ),
      ],
    );
  }
}
