import 'package:flutter/material.dart';
import 'package:animate_do/animate_do.dart';
import 'package:quran_app/core/constants/colors.dart';

class OnboardingPageItem extends StatelessWidget {
  final String title;
  final Widget child;

  const OnboardingPageItem({
    super.key,
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 23, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 10),

          /// 🔥 Title FadeInUp
          FadeInUp(
            duration: const Duration(milliseconds: 800),
            child: Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: QuranColors.creamColor,
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(height: 20),

          /// 🔥 Content FadeInUp
          Expanded(
            child: FadeInUp(
              duration: const Duration(milliseconds: 800),
              delay: const Duration(milliseconds: 200),
              child: child,
            ),
          ),
        ],
      ),
    );
  }
}
