import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:quran_app/core/constants/colors.dart';

import '../../../../feature/views/reader/reader.dart';
import '../../../../generated/l10n.dart';
import '../../../../providers/bookmark_provider.dart';
import '../home/listitems.dart';

class JuzTab extends ConsumerWidget {
  final List<dynamic> juz;
  final Set<int> bookmarked;

  const JuzTab({required this.juz, required this.bookmarked});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (bookmarked.isEmpty) {
      return Center(
        child: Text(
          S.of(context)!.no_juz,
          style: TextStyle(color: QuranColors.creamColor),
        ),
      );
    }

    return ListView(
      children: bookmarked.map((number) {
        final item = juz.firstWhere(
          (j) => j['number'] == number,
          orElse: () => {'nameEn': 'Juz $number', 'nameAr': ''},
        );

        final locale = Localizations.localeOf(context).languageCode;
        final name = locale == 'fa'
            ? (item['name_ar'] ?? '')
            : (item['nameEn'] ?? '');

        return BuildQuranItem(
          is_juz: true,
          isBookmarked: true,
          number: number.toString(),
          nameEn: name,
          nameAr: '',
          ayahs: '',
          revelationType: '',
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ReaderPage(juzNumber: number)),
          ),
          onBookmark: () =>
              ref.read(bookmarkedJuzProvider.notifier).toggle(number),
        );
      }).toList(),
    );
  }
}

class SurahTab extends ConsumerWidget {
  final List<dynamic> surahs;
  final Set<int> bookmarked;

  const SurahTab({required this.surahs, required this.bookmarked});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (bookmarked.isEmpty) {
      return Center(
        child: Text(
          S.of(context)!.no_surahs,
          style: TextStyle(color: QuranColors.creamColor),
        ),
      );
    }

    return ListView(
      children: bookmarked.map((number) {
        final surah = surahs.firstWhere(
          (s) => int.parse(s['number'].toString()) == number,
          orElse: () => null,
        );

        if (surah == null) return const SizedBox();

        final locale = Localizations.localeOf(context).languageCode;
        final name = locale == 'fa' ? surah['nameAr'] : surah['nameEn'];
        final ayahLabel = locale == 'fa' ? "آیه" : "Ayah";

        return BuildQuranItem(
          is_juz: false,
          isBookmarked: true,
          number: number.toString(),
          nameEn: name,
          nameAr: surah['nameAr'],
          ayahs: "${surah['ayahs']} $ayahLabel",
          revelationType: surah['type'],
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ReaderPage(surahNumber: number, surahName: name),
            ),
          ),
          onBookmark: () =>
              ref.read(bookmarkedSurahsProvider.notifier).toggle(number),
        );
      }).toList(),
    );
  }
}
