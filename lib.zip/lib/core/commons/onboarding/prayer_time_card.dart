import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:quran_app/core/constants/colors.dart';
import 'package:quran_app/providers/prayer_provider.dart';
import 'package:quran_app/services/prayer_times_service.dart';

class PrayerTimesOnboardingWidget extends ConsumerWidget {
  const PrayerTimesOnboardingWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: const [_LivePrayerCard(), SizedBox(height: 14)],
      ),
    );
  }
}

class _LivePrayerCard extends ConsumerWidget {
  const _LivePrayerCard();

  String _fmt(DateTime dt) {
    final h = dt.hour > 12 ? dt.hour - 12 : (dt.hour == 0 ? 12 : dt.hour);
    final m = dt.minute.toString().padLeft(2, '0');
    final period = dt.hour >= 12 ? 'PM' : 'AM';
    return '$h:$m $period';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final times = ref.watch(prayerTimesProvider);
    final coords = ref.watch(userLocationCoordsProvider);
    final now = DateTime.now();
    final dateStr =
        '${now.day.toString().padLeft(2, '0')} / ${now.month.toString().padLeft(2, '0')} / ${now.year}';
    return Container(
      decoration: BoxDecoration(
        color: QuranColors.prayer_cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.13)),
      ),
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                dateStr,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _PrayerItem(
                icon: '✦',
                isFajr: true,
                time: _fmt(times.fajr),
                name: 'Fajr',
              ),
              _PrayerItem(icon: '☀️', time: _fmt(times.dhuhr), name: 'Dhuhr'),
              _PrayerItem(icon: '⛅', time: _fmt(times.asr), name: 'Asr'),
              _PrayerItem(
                icon: '🌅',
                time: _fmt(times.maghrib),
                name: 'Maghrib',
              ),
              _PrayerItem(icon: '🌙', time: _fmt(times.isha), name: "Isha'a"),
            ],
          ),
          const SizedBox(height: 14),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              'Sunrise: ${_fmt(times.sunrise)}',
              style: TextStyle(
                color: Colors.white.withOpacity(0.45),
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PrayerItem extends StatelessWidget {
  final String icon;
  final String time;
  final String name;
  final bool isFajr;

  const _PrayerItem({
    required this.icon,
    required this.time,
    required this.name,
    this.isFajr = false,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: 36,
            child: Center(
              child: isFajr
                  ? const Text(
                      '✦ ✦',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w300,
                        letterSpacing: -1,
                      ),
                    )
                  : Text(icon, style: const TextStyle(fontSize: 24)),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            time,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            name,
            style: TextStyle(
              color: Colors.white.withOpacity(0.75),
              fontSize: 11,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
