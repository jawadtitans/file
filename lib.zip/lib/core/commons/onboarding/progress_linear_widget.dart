import 'package:flutter/material.dart';
import '../../constants/colors.dart';

class AnimatedShimmerProgress extends StatelessWidget {
  final double value;

  const AnimatedShimmerProgress({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: value, end: value),
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOut,
      builder: (context, animatedValue, child) {
        return Padding(
          padding: EdgeInsetsGeometry.only(right: 14),
          child: LinearProgressIndicator(
            minHeight: 10,
            value: animatedValue.clamp(0.0, 1.0),
            backgroundColor: QuranColors.cardColors.withOpacity(1),
            color: QuranColors.greenPrimary,
            borderRadius: BorderRadius.circular(30),
          ),
        );
      },
    );
  }
}
