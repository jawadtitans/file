import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class WelcomeLottie extends StatelessWidget {
  const WelcomeLottie({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: Lottie.asset(
        "assets/animations/salam.lottie",
        fit: BoxFit.contain,
        repeat: true,
      ),
    );
  }
}

///TODO: json format of the lottie file in here:

class WelcomeLottieJson extends StatelessWidget {
  final String assetPath;
  final double height;
  final bool repeat;

  const WelcomeLottieJson({
    super.key,
    required this.assetPath,
    this.height = 50,
    this.repeat = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Lottie.asset(assetPath, fit: BoxFit.contain, repeat: repeat),
    );
  }
}
