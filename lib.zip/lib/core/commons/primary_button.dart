import 'package:flutter/material.dart';

class PrimaryButton extends StatefulWidget {
  final String text;
  final VoidCallback onPressed;
  final double? width;
  final double height;
  final Color? color;
  final TextStyle? textStyle;
  final BorderRadiusGeometry borderRadius;

  const PrimaryButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.width = double.infinity,
    this.height = 50,
    this.color,
    this.textStyle,
    this.borderRadius = const BorderRadius.all(Radius.circular(12)),
  });

  @override
  State<PrimaryButton> createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> {
  bool _pressed = false;

  void _onTapDown(_) => setState(() => _pressed = true);

  void _onTapUp(_) {
    setState(() => _pressed = false);
    widget.onPressed();
  }

  void _onTapCancel() => setState(() => _pressed = false);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      child: GestureDetector(
        onTapDown: _onTapDown,
        onTapUp: _onTapUp,
        onTapCancel: _onTapCancel,
        child: AnimatedScale(
          scale: _pressed ? 0.96 : 1.0, // smaller scale for button
          duration: const Duration(milliseconds: 120),
          child: SizedBox(
            width: widget.width,
            height: widget.height,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: widget.color ?? Theme.of(context).primaryColor,
                shape: RoundedRectangleBorder(
                  borderRadius: widget.borderRadius,
                ),
              ),
              onPressed: widget.onPressed,
              child: Text(
                widget.text,
                style:
                    widget.textStyle ??
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
