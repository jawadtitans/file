// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a fa locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fa';

  static String m0(percent) => "${percent}% کامل شده";

  static String m1(time) => "در ${time}";

  static String m2(number) => "آیه ${number}";

  static String m3(count) => "${count} آیه";

  static String m4(number) => "جزء ${number}";

  static String m5(number) => "جزء ${number}";

  static String m6(number) => "سوره ${number}";

  static String m7(type) => "نمایش: ${type}";

  static String m8(query) => "نتیجه‌ای برای \"${query}\" نیافتیم";

  static String m9(count) => "مجموع: ${count}";

  static String m10(hours, minutes) => "${hours}س ${minutes}د";

  static String m11(minutes, seconds) => "${minutes}د ${seconds}ث";

  static String m12(hours, minutes) => "در ${hours}س ${minutes}د";

  static String m13(minutes, seconds) => "در ${minutes}د ${seconds}ث";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "about_app": MessageLookupByLibrary.simpleMessage("درباره برنامه"),
    "account_admin": MessageLookupByLibrary.simpleMessage("مدیریت حساب"),
    "al_quran": MessageLookupByLibrary.simpleMessage("القرآن"),
    "allow_notifications": MessageLookupByLibrary.simpleMessage(
      "اجازه اعلان‌ها",
    ),
    "amal_adia": MessageLookupByLibrary.simpleMessage("ادعیه و اعمال"),
    "asr": MessageLookupByLibrary.simpleMessage("عصر"),
    "auto_scroll": MessageLookupByLibrary.simpleMessage(
      "اسکرول خودکار هنگام قرائت",
    ),
    "bookmar_title": MessageLookupByLibrary.simpleMessage("ذخیره‌شده‌ها"),
    "bookmark": MessageLookupByLibrary.simpleMessage("ذخیره"),
    "calendar_gregorian": MessageLookupByLibrary.simpleMessage("میلادی"),
    "calendar_hijri": MessageLookupByLibrary.simpleMessage("هجری"),
    "coming_soon": MessageLookupByLibrary.simpleMessage("به زودی"),
    "continue_reading": MessageLookupByLibrary.simpleMessage("ادامه قرائت"),
    "dark_mode": MessageLookupByLibrary.simpleMessage("حالت تاریک"),
    "day_name_friday": MessageLookupByLibrary.simpleMessage("اعمال روز جمعه"),
    "day_name_monday": MessageLookupByLibrary.simpleMessage("اعمال روز دوشنبه"),
    "day_name_saturday": MessageLookupByLibrary.simpleMessage("اعمال روز شنبه"),
    "day_name_sunday": MessageLookupByLibrary.simpleMessage("اعمال روز یکشنبه"),
    "day_name_thursday": MessageLookupByLibrary.simpleMessage(
      "اعمال روز پنج‌شنبه",
    ),
    "day_name_tuesday": MessageLookupByLibrary.simpleMessage(
      "اعمال روز سه‌شنبه",
    ),
    "day_name_wednesday": MessageLookupByLibrary.simpleMessage(
      "اعمال روز چهارشنبه",
    ),
    "dhuhr": MessageLookupByLibrary.simpleMessage("ظهر"),
    "done": MessageLookupByLibrary.simpleMessage("اتمام"),
    "dua_category_family": MessageLookupByLibrary.simpleMessage("خانواده"),
    "dua_category_istighfar": MessageLookupByLibrary.simpleMessage("استغفار"),
    "dua_category_morning": MessageLookupByLibrary.simpleMessage("صبح"),
    "dua_category_night": MessageLookupByLibrary.simpleMessage("شب"),
    "dua_category_prayer": MessageLookupByLibrary.simpleMessage("نماز"),
    "dua_category_trust": MessageLookupByLibrary.simpleMessage("توکل"),
    "dua_title_after_prayer": MessageLookupByLibrary.simpleMessage(
      "دعای بعد از نماز",
    ),
    "dua_title_before_sleep": MessageLookupByLibrary.simpleMessage(
      "دعای قبل از خواب",
    ),
    "dua_title_istighfar": MessageLookupByLibrary.simpleMessage("دعای استغفار"),
    "dua_title_morning": MessageLookupByLibrary.simpleMessage("دعای صباح"),
    "dua_title_parents": MessageLookupByLibrary.simpleMessage(
      "دعای برای والدین",
    ),
    "dua_title_trust": MessageLookupByLibrary.simpleMessage("دعای توکل"),
    "duas_title": MessageLookupByLibrary.simpleMessage("دعاها"),
    "enable_location": MessageLookupByLibrary.simpleMessage("اجازه موقعیت"),
    "enable_notification": MessageLookupByLibrary.simpleMessage(
      "فعال‌سازی اعلان‌ها",
    ),
    "enable_notifications_and_finish": MessageLookupByLibrary.simpleMessage(
      "فعال‌سازی اعلان‌ها و اتمام",
    ),
    "events_of_day": MessageLookupByLibrary.simpleMessage("مناسبت‌های این روز"),
    "exit_app_message": MessageLookupByLibrary.simpleMessage(
      "برای خروج، دوباره دکمه برگشت را فشار دهید",
    ),
    "fajr": MessageLookupByLibrary.simpleMessage("صبح"),
    "filter": MessageLookupByLibrary.simpleMessage("فیلتر"),
    "font_size": MessageLookupByLibrary.simpleMessage("اندازه قلم"),
    "header_date": MessageLookupByLibrary.simpleMessage("تاریخ امروز"),
    "header_fajr": MessageLookupByLibrary.simpleMessage(
      "زمان باقی‌مانده تا فجر",
    ),
    "header_location": MessageLookupByLibrary.simpleMessage("موقعیت شما"),
    "header_time": MessageLookupByLibrary.simpleMessage("ساعت"),
    "hijri": MessageLookupByLibrary.simpleMessage("هجری"),
    "hijri_dhul_hijjah": MessageLookupByLibrary.simpleMessage("ذالحجه"),
    "hijri_dhul_qadah": MessageLookupByLibrary.simpleMessage("ذالقعده"),
    "hijri_jumada_al_awwal": MessageLookupByLibrary.simpleMessage(
      "جمادی الاول",
    ),
    "hijri_jumada_al_thani": MessageLookupByLibrary.simpleMessage(
      "جمادی الثانی",
    ),
    "hijri_muharram": MessageLookupByLibrary.simpleMessage("محرم"),
    "hijri_rabi_al_awwal": MessageLookupByLibrary.simpleMessage("ربیع الاول"),
    "hijri_rabi_al_thani": MessageLookupByLibrary.simpleMessage("ربیع الثانی"),
    "hijri_rajab": MessageLookupByLibrary.simpleMessage("رجب"),
    "hijri_ramadan": MessageLookupByLibrary.simpleMessage("رمضان"),
    "hijri_safar": MessageLookupByLibrary.simpleMessage("صفر"),
    "hijri_shaban": MessageLookupByLibrary.simpleMessage("شعبان"),
    "hijri_shawwal": MessageLookupByLibrary.simpleMessage("شوال"),
    "isha": MessageLookupByLibrary.simpleMessage("عشاء"),
    "juz": MessageLookupByLibrary.simpleMessage("جزء"),
    "khatam_completed_percent": m0,
    "khatam_title": MessageLookupByLibrary.simpleMessage("ختم قرآن"),
    "language": MessageLookupByLibrary.simpleMessage("زبان"),
    "light_mode": MessageLookupByLibrary.simpleMessage("حالت روشن"),
    "location_permission": MessageLookupByLibrary.simpleMessage(
      "فعال‌سازی موقعیت",
    ),
    "location_permission_denied_message": MessageLookupByLibrary.simpleMessage(
      "لطفاً مجوز موقعیت و GPS را فعال کنید",
    ),
    "location_required": MessageLookupByLibrary.simpleMessage(
      "برای دریافت اوقات نماز دقیق، موقعیت را فعال کنید",
    ),
    "location_success": MessageLookupByLibrary.simpleMessage(
      "موقعیت شما دریافت شد",
    ),
    "login": MessageLookupByLibrary.simpleMessage("ورود"),
    "maghrib": MessageLookupByLibrary.simpleMessage("مغرب"),
    "month_april": MessageLookupByLibrary.simpleMessage("اپریل"),
    "month_august": MessageLookupByLibrary.simpleMessage("آگست"),
    "month_december": MessageLookupByLibrary.simpleMessage("دسامبر"),
    "month_february": MessageLookupByLibrary.simpleMessage("فبروری"),
    "month_january": MessageLookupByLibrary.simpleMessage("جنوری"),
    "month_july": MessageLookupByLibrary.simpleMessage("جولای"),
    "month_june": MessageLookupByLibrary.simpleMessage("جون"),
    "month_march": MessageLookupByLibrary.simpleMessage("مارچ"),
    "month_may": MessageLookupByLibrary.simpleMessage("می"),
    "month_november": MessageLookupByLibrary.simpleMessage("نوامبر"),
    "month_october": MessageLookupByLibrary.simpleMessage("اکتبر"),
    "month_september": MessageLookupByLibrary.simpleMessage("سپتامبر"),
    "monthly_deeds_rajab_deed_1": MessageLookupByLibrary.simpleMessage(
      "روزه گرفتن در روزهای مستحب",
    ),
    "monthly_deeds_rajab_deed_2": MessageLookupByLibrary.simpleMessage(
      "خواندن دعای یا من ارجوه",
    ),
    "monthly_deeds_rajab_deed_3": MessageLookupByLibrary.simpleMessage(
      "استغفار زیاد",
    ),
    "monthly_deeds_rajab_title": MessageLookupByLibrary.simpleMessage(
      "اعمال ماه رجب",
    ),
    "monthly_deeds_ramadan_deed_1": MessageLookupByLibrary.simpleMessage(
      "روزه گرفتن",
    ),
    "monthly_deeds_ramadan_deed_2": MessageLookupByLibrary.simpleMessage(
      "تلاوت قرآن",
    ),
    "monthly_deeds_ramadan_deed_3": MessageLookupByLibrary.simpleMessage(
      "دعای افتتاح",
    ),
    "monthly_deeds_ramadan_deed_4": MessageLookupByLibrary.simpleMessage(
      "احیای شب‌های قدر",
    ),
    "monthly_deeds_ramadan_title": MessageLookupByLibrary.simpleMessage(
      "اعمال ماه رمضان",
    ),
    "monthly_deeds_shaban_deed_1": MessageLookupByLibrary.simpleMessage(
      "صلوات شعبانیه",
    ),
    "monthly_deeds_shaban_deed_2": MessageLookupByLibrary.simpleMessage(
      "روزه مستحب",
    ),
    "monthly_deeds_shaban_deed_3": MessageLookupByLibrary.simpleMessage(
      "صدقه دادن",
    ),
    "monthly_deeds_shaban_title": MessageLookupByLibrary.simpleMessage(
      "اعمال ماه شعبان",
    ),
    "my_network": MessageLookupByLibrary.simpleMessage("شبکه من"),
    "nav_Quran": MessageLookupByLibrary.simpleMessage("قرآن"),
    "nav_home": MessageLookupByLibrary.simpleMessage("خانه"),
    "nav_islam": MessageLookupByLibrary.simpleMessage("خانه"),
    "nav_prayer": MessageLookupByLibrary.simpleMessage("اوقات نماز"),
    "nav_search": MessageLookupByLibrary.simpleMessage("جستجو"),
    "nav_settings": MessageLookupByLibrary.simpleMessage("تنظیمات"),
    "next": MessageLookupByLibrary.simpleMessage("بعدی"),
    "no_ayah": MessageLookupByLibrary.simpleMessage("هیچ آیه‌ای ذخیره نشده"),
    "no_juz": MessageLookupByLibrary.simpleMessage("هیچ جزئی ذخیره نشده"),
    "no_results": MessageLookupByLibrary.simpleMessage("نتیجه‌ای یافت نشد"),
    "no_surah": MessageLookupByLibrary.simpleMessage("هیچ سوره‌ای ذخیره نشده"),
    "no_surahs": MessageLookupByLibrary.simpleMessage("هیچ سوره‌ای یافت نشد"),
    "notification_desc": MessageLookupByLibrary.simpleMessage(
      "با یادآوری اذان وقت نماز را از دست ندهید",
    ),
    "now": MessageLookupByLibrary.simpleMessage("الان"),
    "onboarding_close": MessageLookupByLibrary.simpleMessage("بستن"),
    "payments": MessageLookupByLibrary.simpleMessage("پرداخت‌ها"),
    "prayer_asr_local": MessageLookupByLibrary.simpleMessage("عصر"),
    "prayer_completed_count": MessageLookupByLibrary.simpleMessage("خوانده شد"),
    "prayer_dhuhr_local": MessageLookupByLibrary.simpleMessage("ظهر"),
    "prayer_fajr_local": MessageLookupByLibrary.simpleMessage("صبح"),
    "prayer_in": m1,
    "prayer_isha_local": MessageLookupByLibrary.simpleMessage("عشاء"),
    "prayer_maghrib_local": MessageLookupByLibrary.simpleMessage("مغرب"),
    "prayer_next": MessageLookupByLibrary.simpleMessage("بعدی"),
    "prayer_now": MessageLookupByLibrary.simpleMessage("حالا"),
    "prayer_now_badge": MessageLookupByLibrary.simpleMessage("حالا"),
    "prayer_times": MessageLookupByLibrary.simpleMessage("اوقات نماز"),
    "prayer_times_title": MessageLookupByLibrary.simpleMessage("اوقات نماز"),
    "preview_text": MessageLookupByLibrary.simpleMessage("پیش‌نمایش متن"),
    "qibla_coming_desc": MessageLookupByLibrary.simpleMessage(
      "این بخش در حال توسعه است و در نسخه بعدی برنامه در دسترس قرار خواهد گرفت.",
    ),
    "qibla_title": MessageLookupByLibrary.simpleMessage("قبله‌نما"),
    "quran_app": MessageLookupByLibrary.simpleMessage("اپلیکیشن قرآن کریم"),
    "quran_aya_short": m2,
    "quran_ayah_count": m3,
    "quran_complete_surah_message": MessageLookupByLibrary.simpleMessage(
      "برای نمایش این بخش، یک سوره را کامل کنید",
    ),
    "quran_completed": MessageLookupByLibrary.simpleMessage("✓ تکمیل شد"),
    "quran_font_size": MessageLookupByLibrary.simpleMessage("اندازه قلم قرآن"),
    "quran_juz_done": MessageLookupByLibrary.simpleMessage("جزء تکمیل‌شده"),
    "quran_juz_header": m4,
    "quran_juz_label": m5,
    "quran_juz_list": MessageLookupByLibrary.simpleMessage("فهرست جزءها"),
    "quran_khatam_tab": MessageLookupByLibrary.simpleMessage("ختم"),
    "quran_last_read": MessageLookupByLibrary.simpleMessage("آخرین مطالعه"),
    "quran_minute_read": MessageLookupByLibrary.simpleMessage("دقیقه مطالعه"),
    "quran_no_reading_yet": MessageLookupByLibrary.simpleMessage(
      "هنوز چیزی نخوانده‌اید",
    ),
    "quran_progress_tab": MessageLookupByLibrary.simpleMessage("پیشرفت من"),
    "quran_read_tab": MessageLookupByLibrary.simpleMessage("مطالعه"),
    "quran_reading_progress_subtitle": MessageLookupByLibrary.simpleMessage(
      "پیشرفت بر اساس اسکرول برای سوره و جزء",
    ),
    "quran_reading_progress_title": MessageLookupByLibrary.simpleMessage(
      "پیشرفت مطالعه",
    ),
    "quran_recents": MessageLookupByLibrary.simpleMessage("اخیر"),
    "quran_start_reading_progress": MessageLookupByLibrary.simpleMessage(
      "برای ثبت پیشرفت، مطالعه را شروع کنید",
    ),
    "quran_sura_list": MessageLookupByLibrary.simpleMessage("فهرست سوره‌ها"),
    "quran_surah_done": MessageLookupByLibrary.simpleMessage("سوره تکمیل‌شده"),
    "quran_surah_label": m6,
    "quran_view_juz": MessageLookupByLibrary.simpleMessage("جزء"),
    "quran_view_label": m7,
    "quran_view_sura": MessageLookupByLibrary.simpleMessage("سوره"),
    "reading": MessageLookupByLibrary.simpleMessage("قرائت"),
    "recent_downloads": MessageLookupByLibrary.simpleMessage("دانلودهای اخیر"),
    "search_ayah": MessageLookupByLibrary.simpleMessage("جستجوی آیه"),
    "search_ayah_example": MessageLookupByLibrary.simpleMessage(
      "مثال: ۲:۲۵۵ یا الله",
    ),
    "search_ayah_filter_subtitle": MessageLookupByLibrary.simpleMessage(
      "متن آیه یا شماره (مثال: ۲:۲۵۵)",
    ),
    "search_ayah_short": MessageLookupByLibrary.simpleMessage("آیه"),
    "search_ayah_subtitle": MessageLookupByLibrary.simpleMessage(
      "می‌توانید آیه‌ها را با متن جستجو کنید",
    ),
    "search_by_type_title": MessageLookupByLibrary.simpleMessage(
      "جستجو بر اساس",
    ),
    "search_enter_ayah_text_or_number": MessageLookupByLibrary.simpleMessage(
      "آیه، متن یا شماره را وارد کنید",
    ),
    "search_enter_surah_name": MessageLookupByLibrary.simpleMessage(
      "نام سوره را وارد کنید",
    ),
    "search_go_to_ayah": MessageLookupByLibrary.simpleMessage("برو به آیه"),
    "search_hint": MessageLookupByLibrary.simpleMessage("جستجو"),
    "search_no_result_for": m8,
    "search_surah": MessageLookupByLibrary.simpleMessage("جستجوی سوره"),
    "search_surah_short": MessageLookupByLibrary.simpleMessage("سوره"),
    "search_surah_subtitle": MessageLookupByLibrary.simpleMessage(
      "می‌توانید سوره‌ها را با نام جستجو کنید",
    ),
    "see_prayer_times": MessageLookupByLibrary.simpleMessage("دیدم تشکر"),
    "settings_allow_notifications": MessageLookupByLibrary.simpleMessage(
      "اجازه اعلان‌ها",
    ),
    "settings_app_language_section": MessageLookupByLibrary.simpleMessage(
      "زبان برنامه",
    ),
    "settings_auto_scroll": MessageLookupByLibrary.simpleMessage(
      "پیمایش خودکار",
    ),
    "settings_font_size": MessageLookupByLibrary.simpleMessage("اندازه فونت"),
    "settings_language_dari": MessageLookupByLibrary.simpleMessage(
      "دری / فارسی",
    ),
    "settings_language_english": MessageLookupByLibrary.simpleMessage(
      "English",
    ),
    "settings_notifications_section": MessageLookupByLibrary.simpleMessage(
      "اعلان‌ها",
    ),
    "settings_reading_section": MessageLookupByLibrary.simpleMessage("قرائت"),
    "settings_title": MessageLookupByLibrary.simpleMessage("تنظیمات"),
    "shamsi": MessageLookupByLibrary.simpleMessage("شمسی"),
    "share": MessageLookupByLibrary.simpleMessage("اشتراک‌گذاری"),
    "share_apps": MessageLookupByLibrary.simpleMessage("اشتراک‌گذاری برنامه"),
    "skip": MessageLookupByLibrary.simpleMessage("رد کردن"),
    "splash_text": MessageLookupByLibrary.simpleMessage("هدایه"),
    "story_fri_1_title": MessageLookupByLibrary.simpleMessage(
      "نماز جمعه و طلب رزق",
    ),
    "story_fri_1_translation": MessageLookupByLibrary.simpleMessage(
      "پس چون نماز گزارده شد در زمین پراکنده شوید و فضل خداوند را بجویید.",
    ),
    "story_fri_2_title": MessageLookupByLibrary.simpleMessage(
      "خواندن سوره کهف در جمعه",
    ),
    "story_fri_2_translation": MessageLookupByLibrary.simpleMessage(
      "ستایش خداوندی را که این کتاب را بر بنده‌اش نازل کرد و هیچ کجی در آن قرار نداد.",
    ),
    "story_fri_3_title": MessageLookupByLibrary.simpleMessage(
      "کثرت صلوات در جمعه",
    ),
    "story_fri_3_translation": MessageLookupByLibrary.simpleMessage(
      "خداوند و فرشتگانش بر پیامبر درود می‌فرستند. ای مؤمنان شما نیز بر او درود بفرستید.",
    ),
    "story_fri_4_title": MessageLookupByLibrary.simpleMessage("صدقه جمعه"),
    "story_fri_4_translation": MessageLookupByLibrary.simpleMessage(
      "از اموالشان صدقه بگیر تا آنان را پاک سازی و رشد دهی.",
    ),
    "story_fri_5_title": MessageLookupByLibrary.simpleMessage(
      "دعا و تقرب به خداوند",
    ),
    "story_fri_5_translation": MessageLookupByLibrary.simpleMessage(
      "ای مؤمنان تقوای الهی پیشه کنید و وسیله‌ای برای تقرب به او بجویید.",
    ),
    "story_fri_6_title": MessageLookupByLibrary.simpleMessage("احیاء شب جمعه"),
    "story_fri_6_translation": MessageLookupByLibrary.simpleMessage(
      "ما آن را در شبی مبارک نازل کردیم و ما هشداردهنده بودیم.",
    ),
    "story_mon_1_title": MessageLookupByLibrary.simpleMessage(
      "شتاب در اعمال خیر",
    ),
    "story_mon_1_translation": MessageLookupByLibrary.simpleMessage(
      "و بشتابید به سوی مغفرت پروردگارتان و بهشتی که پهنایش آسمان‌ها و زمین است.",
    ),
    "story_mon_2_title": MessageLookupByLibrary.simpleMessage(
      "حمد و شکر خداوند",
    ),
    "story_mon_2_translation": MessageLookupByLibrary.simpleMessage(
      "ستایش مخصوص خداوند پروردگار جهانیان است.",
    ),
    "story_mon_3_title": MessageLookupByLibrary.simpleMessage(
      "توبه و استغفار دوشنبه",
    ),
    "story_mon_3_translation": MessageLookupByLibrary.simpleMessage(
      "همانا خداوند توبه‌کاران و پاکیزگان را دوست دارد.",
    ),
    "story_mon_4_title": MessageLookupByLibrary.simpleMessage("صداقت و راستی"),
    "story_mon_4_translation": MessageLookupByLibrary.simpleMessage(
      "ای مؤمنان، تقوای خدا پیشه کنید و با راستگویان باشید.",
    ),
    "story_mon_5_title": MessageLookupByLibrary.simpleMessage(
      "انفاق در راه خدا",
    ),
    "story_mon_5_translation": MessageLookupByLibrary.simpleMessage(
      "و کسانی که در اموالشان حق معلومی برای سائل و محروم است.",
    ),
    "story_sat_1_title": MessageLookupByLibrary.simpleMessage(
      "خواندن سوره کهف",
    ),
    "story_sat_1_translation": MessageLookupByLibrary.simpleMessage(
      "ستایش خداوندی را که این کتاب را بر بنده‌اش نازل کرد و هیچ کجی در آن قرار نداد.",
    ),
    "story_sat_2_title": MessageLookupByLibrary.simpleMessage("دعای روز شنبه"),
    "story_sat_2_translation": MessageLookupByLibrary.simpleMessage(
      "پروردگارا، از نزد خود به ما رحمت عطا کن و کار ما را به راه راست هدایت فرما.",
    ),
    "story_sat_3_title": MessageLookupByLibrary.simpleMessage(
      "اقامه نمازهای پنج‌گانه",
    ),
    "story_sat_3_translation": MessageLookupByLibrary.simpleMessage(
      "نماز را از زوال آفتاب تا تاریکی شب و نماز صبح به پا دار.",
    ),
    "story_sat_4_title": MessageLookupByLibrary.simpleMessage(
      "صدقه دادن در روز شنبه",
    ),
    "story_sat_4_translation": MessageLookupByLibrary.simpleMessage(
      "نماز به پا دارید و زکات بدهید و با رکوع‌کنندگان رکوع کنید.",
    ),
    "story_sat_5_title": MessageLookupByLibrary.simpleMessage("استغفار و توبه"),
    "story_sat_5_translation": MessageLookupByLibrary.simpleMessage(
      "پس پروردگارت را تسبیح و حمد گو و از او آمرزش بخواه که او همواره توبه‌پذیر است.",
    ),
    "story_sun_1_title": MessageLookupByLibrary.simpleMessage(
      "دعا و مناجات در یکشنبه",
    ),
    "story_sun_1_translation": MessageLookupByLibrary.simpleMessage(
      "و چون بندگانم از تو درباره من بپرسند، بگو من نزدیکم. دعای دعاکننده را اجابت می‌کنم.",
    ),
    "story_sun_2_title": MessageLookupByLibrary.simpleMessage("ذکر و تسبیح"),
    "story_sun_2_translation": MessageLookupByLibrary.simpleMessage(
      "آگاه باشید که تنها با یاد خدا دل‌ها آرامش می‌یابد.",
    ),
    "story_sun_3_title": MessageLookupByLibrary.simpleMessage(
      "روزه مستحبی یکشنبه",
    ),
    "story_sun_3_translation": MessageLookupByLibrary.simpleMessage(
      "ای کسانی که ایمان آورده‌اید، روزه بر شما واجب شده است همان‌گونه که بر پیشینیان واجب شده بود.",
    ),
    "story_sun_4_title": MessageLookupByLibrary.simpleMessage(
      "تلاوت قرآن کریم",
    ),
    "story_sun_4_translation": MessageLookupByLibrary.simpleMessage(
      "این قرآن به راهی که استوارترین راه‌هاست هدایت می‌کند.",
    ),
    "story_sun_5_title": MessageLookupByLibrary.simpleMessage(
      "صلوات بر پیامبر",
    ),
    "story_sun_5_translation": MessageLookupByLibrary.simpleMessage(
      "خداوند و فرشتگانش بر پیامبر درود می‌فرستند. ای مؤمنان شما نیز بر او درود و سلام بفرستید.",
    ),
    "story_thu_1_title": MessageLookupByLibrary.simpleMessage("تسبیح خداوند"),
    "story_thu_1_translation": MessageLookupByLibrary.simpleMessage(
      "پس منزه است آنکه فرمانروایی همه چیز در دست اوست و به سوی او بازمی‌گردید.",
    ),
    "story_thu_2_title": MessageLookupByLibrary.simpleMessage(
      "آمادگی برای نماز جمعه",
    ),
    "story_thu_2_translation": MessageLookupByLibrary.simpleMessage(
      "ای مؤمنان، هنگامی که روز جمعه برای نماز ندا داده شد به ذکر خدا بشتابید.",
    ),
    "story_thu_3_title": MessageLookupByLibrary.simpleMessage(
      "نماز شب پنج‌شنبه",
    ),
    "story_thu_3_translation": MessageLookupByLibrary.simpleMessage(
      "و پاسی از شب را بیدار باش و نماز شب بگزار که این برای تو فریضه‌ای اضافه است.",
    ),
    "story_thu_4_title": MessageLookupByLibrary.simpleMessage(
      "عبادت و بندگی خالص",
    ),
    "story_thu_4_translation": MessageLookupByLibrary.simpleMessage(
      "جن و انس را نیافریدم مگر برای اینکه مرا عبادت کنند.",
    ),
    "story_thu_5_title": MessageLookupByLibrary.simpleMessage(
      "امید به رحمت الهی",
    ),
    "story_thu_5_translation": MessageLookupByLibrary.simpleMessage(
      "بگو ای بندگان من که بر خود اسراف کرده‌اید از رحمت خداوند ناامید نشوید.",
    ),
    "story_tue_1_title": MessageLookupByLibrary.simpleMessage("صبر و شکیبایی"),
    "story_tue_1_translation": MessageLookupByLibrary.simpleMessage(
      "خداوند هیچ کس را جز به اندازه توانش تکلیف نمی‌کند. آنچه کسب کرده به سودش و آنچه مرتکب شده به زیانش است.",
    ),
    "story_tue_2_title": MessageLookupByLibrary.simpleMessage(
      "قرائت سوره اخلاص",
    ),
    "story_tue_2_translation": MessageLookupByLibrary.simpleMessage(
      "بگو خداوند یکتاست، خداوند بی‌نیاز است.",
    ),
    "story_tue_3_title": MessageLookupByLibrary.simpleMessage("تواضع و فروتنی"),
    "story_tue_3_translation": MessageLookupByLibrary.simpleMessage(
      "بندگان خداوند رحمان کسانی‌اند که با فروتنی بر زمین راه می‌روند.",
    ),
    "story_tue_4_title": MessageLookupByLibrary.simpleMessage("صبر و استقامت"),
    "story_tue_4_translation": MessageLookupByLibrary.simpleMessage(
      "همانا خداوند با صابران است.",
    ),
    "story_tue_5_title": MessageLookupByLibrary.simpleMessage("توکل به خداوند"),
    "story_tue_5_translation": MessageLookupByLibrary.simpleMessage(
      "و هر که بر خدا توکل کند خدا او را کافی است. همانا خداوند به فرمانش دست می‌یابد.",
    ),
    "story_wed_1_title": MessageLookupByLibrary.simpleMessage(
      "شکرگزاری از نعمت‌های الهی",
    ),
    "story_wed_1_translation": MessageLookupByLibrary.simpleMessage(
      "پس کدامین نعمت‌های پروردگارتان را انکار می‌کنید؟",
    ),
    "story_wed_2_title": MessageLookupByLibrary.simpleMessage(
      "عمل نیک در چهارشنبه",
    ),
    "story_wed_2_translation": MessageLookupByLibrary.simpleMessage(
      "هر که کار نیکی انجام دهد ده برابر پاداش خواهد داشت.",
    ),
    "story_wed_3_title": MessageLookupByLibrary.simpleMessage(
      "برادری و اصلاح ذات البین",
    ),
    "story_wed_3_translation": MessageLookupByLibrary.simpleMessage(
      "مؤمنان برادر یکدیگرند، پس میان برادرانتان صلح برقرار کنید.",
    ),
    "story_wed_4_title": MessageLookupByLibrary.simpleMessage("طلب علم و دانش"),
    "story_wed_4_translation": MessageLookupByLibrary.simpleMessage(
      "و بگو پروردگارا بر علمم بیفزا.",
    ),
    "story_wed_5_title": MessageLookupByLibrary.simpleMessage("دعا و نیایش"),
    "story_wed_5_translation": MessageLookupByLibrary.simpleMessage(
      "و پروردگارتان فرمود مرا بخوانید تا اجابت کنم.",
    ),
    "sunrise": MessageLookupByLibrary.simpleMessage("طلوع"),
    "support": MessageLookupByLibrary.simpleMessage("صداها"),
    "surah": MessageLookupByLibrary.simpleMessage("سوره"),
    "tab_Ayah": MessageLookupByLibrary.simpleMessage("آیه"),
    "tab_juz": MessageLookupByLibrary.simpleMessage("جزء"),
    "tab_surah": MessageLookupByLibrary.simpleMessage("سوره"),
    "tasbih_reset": MessageLookupByLibrary.simpleMessage("بازنشانی"),
    "tasbih_tap_hint": MessageLookupByLibrary.simpleMessage(
      "برای شمارش ضربه بزنید",
    ),
    "tasbih_title": MessageLookupByLibrary.simpleMessage("تسبیح"),
    "tasbih_total": m9,
    "theme": MessageLookupByLibrary.simpleMessage("پوسته"),
    "time_hours_minutes": m10,
    "time_minutes_seconds": m11,
    "today_assistant_tools": MessageLookupByLibrary.simpleMessage(
      "ابزارهای کمکی شما",
    ),
    "today_features_title": MessageLookupByLibrary.simpleMessage("ویژگی‌ها"),
    "today_in_hours_minutes": m12,
    "today_in_minutes_seconds": m13,
    "today_monthly_deeds_subtitle": MessageLookupByLibrary.simpleMessage(
      "فضایل و اعمال این ماه",
    ),
    "today_monthly_deeds_title": MessageLookupByLibrary.simpleMessage(
      "اعمال ماه",
    ),
    "today_next": MessageLookupByLibrary.simpleMessage("بعدی"),
    "today_now": MessageLookupByLibrary.simpleMessage("حالا"),
    "today_zikr": MessageLookupByLibrary.simpleMessage("ذکر امروز"),
    "upcoming": MessageLookupByLibrary.simpleMessage("آینده"),
    "verse": MessageLookupByLibrary.simpleMessage("آیه"),
    "weekday_friday": MessageLookupByLibrary.simpleMessage("جمعه"),
    "weekday_letter_friday": MessageLookupByLibrary.simpleMessage("ج"),
    "weekday_letter_monday": MessageLookupByLibrary.simpleMessage("د"),
    "weekday_letter_saturday": MessageLookupByLibrary.simpleMessage("ش"),
    "weekday_letter_sunday": MessageLookupByLibrary.simpleMessage("ی"),
    "weekday_letter_thursday": MessageLookupByLibrary.simpleMessage("پ"),
    "weekday_letter_tuesday": MessageLookupByLibrary.simpleMessage("س"),
    "weekday_letter_wednesday": MessageLookupByLibrary.simpleMessage("چ"),
    "weekday_monday": MessageLookupByLibrary.simpleMessage("دوشنبه"),
    "weekday_saturday": MessageLookupByLibrary.simpleMessage("شنبه"),
    "weekday_short_fri": MessageLookupByLibrary.simpleMessage("ج"),
    "weekday_short_mon": MessageLookupByLibrary.simpleMessage("د"),
    "weekday_short_sat": MessageLookupByLibrary.simpleMessage("ش"),
    "weekday_short_sun": MessageLookupByLibrary.simpleMessage("ی"),
    "weekday_short_thu": MessageLookupByLibrary.simpleMessage("پ"),
    "weekday_short_tue": MessageLookupByLibrary.simpleMessage("س"),
    "weekday_short_wed": MessageLookupByLibrary.simpleMessage("چ"),
    "weekday_sunday": MessageLookupByLibrary.simpleMessage("یکشنبه"),
    "weekday_thursday": MessageLookupByLibrary.simpleMessage("پنج‌شنبه"),
    "weekday_tuesday": MessageLookupByLibrary.simpleMessage("سه‌شنبه"),
    "weekday_wednesday": MessageLookupByLibrary.simpleMessage("چهارشنبه"),
    "welcome_description": MessageLookupByLibrary.simpleMessage(
      "یک دقیقه وقت بگذارید تا برنامه را تنظیم کنید و در نمازهایتان منظم بمانید.",
    ),
    "welcome_goal_pray_consistently": MessageLookupByLibrary.simpleMessage(
      "نماز را پیوسته بخوانم",
    ),
    "welcome_goal_question": MessageLookupByLibrary.simpleMessage(
      "بیشتر می‌خواهید روی کدام هدف تمرکز کنید؟",
    ),
    "welcome_goal_read_more_quran": MessageLookupByLibrary.simpleMessage(
      "بیشتر قرآن بخوانم",
    ),
    "welcome_start_button": MessageLookupByLibrary.simpleMessage(
      "بسم الله، شروع کنیم",
    ),
    "welcome_title": MessageLookupByLibrary.simpleMessage(
      "سلام!\nبه هدایه خوش آمدید 🌙",
    ),
  };
}
