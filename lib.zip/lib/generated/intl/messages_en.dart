// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static String m0(percent) => "${percent}% completed";

  static String m1(time) => "In ${time}";

  static String m2(number) => "Aya ${number}";

  static String m3(count) => "${count} Ayah";

  static String m4(number) => "Juz ${number}";

  static String m5(number) => "Juz ${number}";

  static String m6(number) => "Surah ${number}";

  static String m7(type) => "View: ${type}";

  static String m8(query) => "No result found for \"${query}\"";

  static String m9(count) => "Total: ${count}";

  static String m10(hours, minutes) => "${hours}h ${minutes}m";

  static String m11(minutes, seconds) => "${minutes}m ${seconds}s";

  static String m12(hours, minutes) => "In ${hours}h ${minutes}m";

  static String m13(minutes, seconds) => "In ${minutes}m ${seconds}s";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "about_app": MessageLookupByLibrary.simpleMessage("About App"),
    "account_admin": MessageLookupByLibrary.simpleMessage("Account Admin"),
    "al_quran": MessageLookupByLibrary.simpleMessage("Al-Quran"),
    "allow_notifications": MessageLookupByLibrary.simpleMessage(
      "Allow Notifications",
    ),
    "amal_adia": MessageLookupByLibrary.simpleMessage(
      "Deeds and Supplications",
    ),
    "asr": MessageLookupByLibrary.simpleMessage("Asr"),
    "auto_scroll": MessageLookupByLibrary.simpleMessage(
      "Auto Scroll During Recitation",
    ),
    "bookmar_title": MessageLookupByLibrary.simpleMessage("Bookmarks"),
    "bookmark": MessageLookupByLibrary.simpleMessage("Bookmark"),
    "calendar_gregorian": MessageLookupByLibrary.simpleMessage("Gregorian"),
    "calendar_hijri": MessageLookupByLibrary.simpleMessage("Hijri"),
    "coming_soon": MessageLookupByLibrary.simpleMessage("Coming Soon"),
    "continue_reading": MessageLookupByLibrary.simpleMessage(
      "Continue Reading",
    ),
    "dark_mode": MessageLookupByLibrary.simpleMessage("Dark Mode"),
    "day_name_friday": MessageLookupByLibrary.simpleMessage("Deeds of Friday"),
    "day_name_monday": MessageLookupByLibrary.simpleMessage("Deeds of Monday"),
    "day_name_saturday": MessageLookupByLibrary.simpleMessage(
      "Deeds of Saturday",
    ),
    "day_name_sunday": MessageLookupByLibrary.simpleMessage("Deeds of Sunday"),
    "day_name_thursday": MessageLookupByLibrary.simpleMessage(
      "Deeds of Thursday",
    ),
    "day_name_tuesday": MessageLookupByLibrary.simpleMessage(
      "Deeds of Tuesday",
    ),
    "day_name_wednesday": MessageLookupByLibrary.simpleMessage(
      "Deeds of Wednesday",
    ),
    "dhuhr": MessageLookupByLibrary.simpleMessage("Dhuhr"),
    "done": MessageLookupByLibrary.simpleMessage("Done"),
    "dua_category_family": MessageLookupByLibrary.simpleMessage("Family"),
    "dua_category_istighfar": MessageLookupByLibrary.simpleMessage("Istighfar"),
    "dua_category_morning": MessageLookupByLibrary.simpleMessage("Morning"),
    "dua_category_night": MessageLookupByLibrary.simpleMessage("Night"),
    "dua_category_prayer": MessageLookupByLibrary.simpleMessage("Prayer"),
    "dua_category_trust": MessageLookupByLibrary.simpleMessage("Trust"),
    "dua_title_after_prayer": MessageLookupByLibrary.simpleMessage(
      "After Prayer Dua",
    ),
    "dua_title_before_sleep": MessageLookupByLibrary.simpleMessage(
      "Before Sleep Dua",
    ),
    "dua_title_istighfar": MessageLookupByLibrary.simpleMessage(
      "Istighfar Dua",
    ),
    "dua_title_morning": MessageLookupByLibrary.simpleMessage("Morning Dua"),
    "dua_title_parents": MessageLookupByLibrary.simpleMessage(
      "Dua for Parents",
    ),
    "dua_title_trust": MessageLookupByLibrary.simpleMessage("Dua of Trust"),
    "duas_title": MessageLookupByLibrary.simpleMessage("Duas"),
    "enable_location": MessageLookupByLibrary.simpleMessage("Enable Location"),
    "enable_notification": MessageLookupByLibrary.simpleMessage(
      "Enable Notifications",
    ),
    "enable_notifications_and_finish": MessageLookupByLibrary.simpleMessage(
      "Enable Notifications and Finish",
    ),
    "events_of_day": MessageLookupByLibrary.simpleMessage("Events of This Day"),
    "exit_app_message": MessageLookupByLibrary.simpleMessage(
      "Press back again to exit the app",
    ),
    "fajr": MessageLookupByLibrary.simpleMessage("Fajr"),
    "filter": MessageLookupByLibrary.simpleMessage("Filter"),
    "font_size": MessageLookupByLibrary.simpleMessage("Font Size"),
    "header_date": MessageLookupByLibrary.simpleMessage("Today\'s Date"),
    "header_fajr": MessageLookupByLibrary.simpleMessage(
      "Time remaining until Fajr",
    ),
    "header_location": MessageLookupByLibrary.simpleMessage("Your Location"),
    "header_time": MessageLookupByLibrary.simpleMessage("Time"),
    "hijri": MessageLookupByLibrary.simpleMessage("Hijri"),
    "hijri_dhul_hijjah": MessageLookupByLibrary.simpleMessage("Dhul-Hijjah"),
    "hijri_dhul_qadah": MessageLookupByLibrary.simpleMessage("Dhul-Qadah"),
    "hijri_jumada_al_awwal": MessageLookupByLibrary.simpleMessage(
      "Jumada al-Awwal",
    ),
    "hijri_jumada_al_thani": MessageLookupByLibrary.simpleMessage(
      "Jumada al-Thani",
    ),
    "hijri_muharram": MessageLookupByLibrary.simpleMessage("Muharram"),
    "hijri_rabi_al_awwal": MessageLookupByLibrary.simpleMessage(
      "Rabi al-Awwal",
    ),
    "hijri_rabi_al_thani": MessageLookupByLibrary.simpleMessage(
      "Rabi al-Thani",
    ),
    "hijri_rajab": MessageLookupByLibrary.simpleMessage("Rajab"),
    "hijri_ramadan": MessageLookupByLibrary.simpleMessage("Ramadan"),
    "hijri_safar": MessageLookupByLibrary.simpleMessage("Safar"),
    "hijri_shaban": MessageLookupByLibrary.simpleMessage("Sha\'ban"),
    "hijri_shawwal": MessageLookupByLibrary.simpleMessage("Shawwal"),
    "isha": MessageLookupByLibrary.simpleMessage("Isha\'a"),
    "juz": MessageLookupByLibrary.simpleMessage("Juz"),
    "khatam_completed_percent": m0,
    "khatam_title": MessageLookupByLibrary.simpleMessage("Khatam Quran"),
    "language": MessageLookupByLibrary.simpleMessage("Language"),
    "light_mode": MessageLookupByLibrary.simpleMessage("Light Mode"),
    "location_permission": MessageLookupByLibrary.simpleMessage(
      "Enable Location",
    ),
    "location_permission_denied_message": MessageLookupByLibrary.simpleMessage(
      "Please enable location permission and GPS",
    ),
    "location_required": MessageLookupByLibrary.simpleMessage(
      "Location is required for accurate prayer times",
    ),
    "location_success": MessageLookupByLibrary.simpleMessage(
      "Location acquired",
    ),
    "login": MessageLookupByLibrary.simpleMessage("Login"),
    "maghrib": MessageLookupByLibrary.simpleMessage("Maghrib"),
    "month_april": MessageLookupByLibrary.simpleMessage("April"),
    "month_august": MessageLookupByLibrary.simpleMessage("August"),
    "month_december": MessageLookupByLibrary.simpleMessage("December"),
    "month_february": MessageLookupByLibrary.simpleMessage("February"),
    "month_january": MessageLookupByLibrary.simpleMessage("January"),
    "month_july": MessageLookupByLibrary.simpleMessage("July"),
    "month_june": MessageLookupByLibrary.simpleMessage("June"),
    "month_march": MessageLookupByLibrary.simpleMessage("March"),
    "month_may": MessageLookupByLibrary.simpleMessage("May"),
    "month_november": MessageLookupByLibrary.simpleMessage("November"),
    "month_october": MessageLookupByLibrary.simpleMessage("October"),
    "month_september": MessageLookupByLibrary.simpleMessage("September"),
    "monthly_deeds_rajab_deed_1": MessageLookupByLibrary.simpleMessage(
      "Fasting on recommended days",
    ),
    "monthly_deeds_rajab_deed_2": MessageLookupByLibrary.simpleMessage(
      "Reciting the Dua Ya Man Arjuhu",
    ),
    "monthly_deeds_rajab_deed_3": MessageLookupByLibrary.simpleMessage(
      "Frequent Istighfar",
    ),
    "monthly_deeds_rajab_title": MessageLookupByLibrary.simpleMessage(
      "Deeds of Rajab",
    ),
    "monthly_deeds_ramadan_deed_1": MessageLookupByLibrary.simpleMessage(
      "Fasting",
    ),
    "monthly_deeds_ramadan_deed_2": MessageLookupByLibrary.simpleMessage(
      "Reciting the Quran",
    ),
    "monthly_deeds_ramadan_deed_3": MessageLookupByLibrary.simpleMessage(
      "Dua al-Iftitah",
    ),
    "monthly_deeds_ramadan_deed_4": MessageLookupByLibrary.simpleMessage(
      "Reviving the Nights of Qadr",
    ),
    "monthly_deeds_ramadan_title": MessageLookupByLibrary.simpleMessage(
      "Deeds of Ramadan",
    ),
    "monthly_deeds_shaban_deed_1": MessageLookupByLibrary.simpleMessage(
      "Salawat Sha\'baniyyah",
    ),
    "monthly_deeds_shaban_deed_2": MessageLookupByLibrary.simpleMessage(
      "Recommended fasting",
    ),
    "monthly_deeds_shaban_deed_3": MessageLookupByLibrary.simpleMessage(
      "Giving charity",
    ),
    "monthly_deeds_shaban_title": MessageLookupByLibrary.simpleMessage(
      "Deeds of Sha\'ban",
    ),
    "my_network": MessageLookupByLibrary.simpleMessage("My Network"),
    "nav_Quran": MessageLookupByLibrary.simpleMessage("Quran"),
    "nav_home": MessageLookupByLibrary.simpleMessage("Home"),
    "nav_islam": MessageLookupByLibrary.simpleMessage("Home"),
    "nav_prayer": MessageLookupByLibrary.simpleMessage("Prayer Times"),
    "nav_search": MessageLookupByLibrary.simpleMessage("Search"),
    "nav_settings": MessageLookupByLibrary.simpleMessage("Settings"),
    "next": MessageLookupByLibrary.simpleMessage("Next"),
    "no_ayah": MessageLookupByLibrary.simpleMessage("No saved Ayah yet"),
    "no_juz": MessageLookupByLibrary.simpleMessage("No saved Juz yet"),
    "no_results": MessageLookupByLibrary.simpleMessage("No results found"),
    "no_surah": MessageLookupByLibrary.simpleMessage("No saved Surah yet"),
    "no_surahs": MessageLookupByLibrary.simpleMessage("No Surahs Found"),
    "notification_desc": MessageLookupByLibrary.simpleMessage(
      "Don\'t miss prayer time with Adhan reminders",
    ),
    "now": MessageLookupByLibrary.simpleMessage("Now"),
    "onboarding_close": MessageLookupByLibrary.simpleMessage("Close"),
    "payments": MessageLookupByLibrary.simpleMessage("Payments"),
    "prayer_asr_local": MessageLookupByLibrary.simpleMessage("Asr"),
    "prayer_completed_count": MessageLookupByLibrary.simpleMessage("Completed"),
    "prayer_dhuhr_local": MessageLookupByLibrary.simpleMessage("Dhuhr"),
    "prayer_fajr_local": MessageLookupByLibrary.simpleMessage("Fajr"),
    "prayer_in": m1,
    "prayer_isha_local": MessageLookupByLibrary.simpleMessage("Isha"),
    "prayer_maghrib_local": MessageLookupByLibrary.simpleMessage("Maghrib"),
    "prayer_next": MessageLookupByLibrary.simpleMessage("Next"),
    "prayer_now": MessageLookupByLibrary.simpleMessage("Now"),
    "prayer_now_badge": MessageLookupByLibrary.simpleMessage("Now"),
    "prayer_times": MessageLookupByLibrary.simpleMessage("Prayer Times"),
    "prayer_times_title": MessageLookupByLibrary.simpleMessage("Prayer Times"),
    "preview_text": MessageLookupByLibrary.simpleMessage("Preview Text"),
    "qibla_coming_desc": MessageLookupByLibrary.simpleMessage(
      "This feature is under development and will be available in the next version.",
    ),
    "qibla_title": MessageLookupByLibrary.simpleMessage("Qibla Direction"),
    "quran_app": MessageLookupByLibrary.simpleMessage("Quran Mobile App"),
    "quran_aya_short": m2,
    "quran_ayah_count": m3,
    "quran_complete_surah_message": MessageLookupByLibrary.simpleMessage(
      "Complete a Surah to see it here",
    ),
    "quran_completed": MessageLookupByLibrary.simpleMessage("✓ Completed"),
    "quran_font_size": MessageLookupByLibrary.simpleMessage("Quran Font Size"),
    "quran_juz_done": MessageLookupByLibrary.simpleMessage("Juz done"),
    "quran_juz_header": m4,
    "quran_juz_label": m5,
    "quran_juz_list": MessageLookupByLibrary.simpleMessage("Juz list"),
    "quran_khatam_tab": MessageLookupByLibrary.simpleMessage("Khatam"),
    "quran_last_read": MessageLookupByLibrary.simpleMessage("Last read"),
    "quran_minute_read": MessageLookupByLibrary.simpleMessage("minute read"),
    "quran_no_reading_yet": MessageLookupByLibrary.simpleMessage(
      "No reading yet",
    ),
    "quran_progress_tab": MessageLookupByLibrary.simpleMessage("My Progress"),
    "quran_read_tab": MessageLookupByLibrary.simpleMessage("Read"),
    "quran_reading_progress_subtitle": MessageLookupByLibrary.simpleMessage(
      "Scroll-based progress per Surah & Juz",
    ),
    "quran_reading_progress_title": MessageLookupByLibrary.simpleMessage(
      "Reading Progress",
    ),
    "quran_recents": MessageLookupByLibrary.simpleMessage("Recents"),
    "quran_start_reading_progress": MessageLookupByLibrary.simpleMessage(
      "Start reading to track progress",
    ),
    "quran_sura_list": MessageLookupByLibrary.simpleMessage("Sura list"),
    "quran_surah_done": MessageLookupByLibrary.simpleMessage("Surah done"),
    "quran_surah_label": m6,
    "quran_view_juz": MessageLookupByLibrary.simpleMessage("Juz"),
    "quran_view_label": m7,
    "quran_view_sura": MessageLookupByLibrary.simpleMessage("Sura"),
    "reading": MessageLookupByLibrary.simpleMessage("Reading"),
    "recent_downloads": MessageLookupByLibrary.simpleMessage(
      "Recent Downloads",
    ),
    "search_ayah": MessageLookupByLibrary.simpleMessage("Search by Ayah"),
    "search_ayah_example": MessageLookupByLibrary.simpleMessage(
      "Example: 2:255 or Allah",
    ),
    "search_ayah_filter_subtitle": MessageLookupByLibrary.simpleMessage(
      "Ayah text or number (example: 2:255)",
    ),
    "search_ayah_short": MessageLookupByLibrary.simpleMessage("Ayah"),
    "search_ayah_subtitle": MessageLookupByLibrary.simpleMessage(
      "Search for an Ayah by its text",
    ),
    "search_by_type_title": MessageLookupByLibrary.simpleMessage("Search by"),
    "search_enter_ayah_text_or_number": MessageLookupByLibrary.simpleMessage(
      "Enter an Ayah, text, or number",
    ),
    "search_enter_surah_name": MessageLookupByLibrary.simpleMessage(
      "Enter a Surah name",
    ),
    "search_go_to_ayah": MessageLookupByLibrary.simpleMessage("Go to Ayah"),
    "search_hint": MessageLookupByLibrary.simpleMessage("Search"),
    "search_no_result_for": m8,
    "search_surah": MessageLookupByLibrary.simpleMessage("Search by Surah"),
    "search_surah_short": MessageLookupByLibrary.simpleMessage("Surah"),
    "search_surah_subtitle": MessageLookupByLibrary.simpleMessage(
      "Search for a Surah by its name",
    ),
    "see_prayer_times": MessageLookupByLibrary.simpleMessage(
      "See Prayer Times",
    ),
    "settings_allow_notifications": MessageLookupByLibrary.simpleMessage(
      "Allow Notifications",
    ),
    "settings_app_language_section": MessageLookupByLibrary.simpleMessage(
      "App Language",
    ),
    "settings_auto_scroll": MessageLookupByLibrary.simpleMessage("Auto Scroll"),
    "settings_font_size": MessageLookupByLibrary.simpleMessage("Font Size"),
    "settings_language_dari": MessageLookupByLibrary.simpleMessage(
      "Dari / Farsi",
    ),
    "settings_language_english": MessageLookupByLibrary.simpleMessage(
      "English",
    ),
    "settings_notifications_section": MessageLookupByLibrary.simpleMessage(
      "Notifications",
    ),
    "settings_reading_section": MessageLookupByLibrary.simpleMessage("Reading"),
    "settings_title": MessageLookupByLibrary.simpleMessage("Settings"),
    "shamsi": MessageLookupByLibrary.simpleMessage("Shamsi"),
    "share": MessageLookupByLibrary.simpleMessage("Share App"),
    "share_apps": MessageLookupByLibrary.simpleMessage("Share App"),
    "skip": MessageLookupByLibrary.simpleMessage("Skip"),
    "splash_text": MessageLookupByLibrary.simpleMessage("Hedaya"),
    "story_fri_1_title": MessageLookupByLibrary.simpleMessage(
      "Friday Prayer and Seeking Provision",
    ),
    "story_fri_1_translation": MessageLookupByLibrary.simpleMessage(
      "When the prayer has been concluded, disperse through the land and seek Allah\'s bounty.",
    ),
    "story_fri_2_title": MessageLookupByLibrary.simpleMessage(
      "Reciting Surah Al-Kahf on Friday",
    ),
    "story_fri_2_translation": MessageLookupByLibrary.simpleMessage(
      "Praise be to Allah who revealed the Book to His servant and made no crookedness in it.",
    ),
    "story_fri_3_title": MessageLookupByLibrary.simpleMessage(
      "Abundant Salawat on Friday",
    ),
    "story_fri_3_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, Allah and His angels send blessings upon the Prophet.",
    ),
    "story_fri_4_title": MessageLookupByLibrary.simpleMessage("Friday Charity"),
    "story_fri_4_translation": MessageLookupByLibrary.simpleMessage(
      "Take from their wealth a charity by which you purify them and cause them increase.",
    ),
    "story_fri_5_title": MessageLookupByLibrary.simpleMessage(
      "Supplication and Drawing Near to Allah",
    ),
    "story_fri_5_translation": MessageLookupByLibrary.simpleMessage(
      "O believers, fear Allah and seek the means of nearness to Him.",
    ),
    "story_fri_6_title": MessageLookupByLibrary.simpleMessage(
      "Reviving Thursday Night",
    ),
    "story_fri_6_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, We sent it down in a blessed night; surely We are ever warning.",
    ),
    "story_mon_1_title": MessageLookupByLibrary.simpleMessage(
      "Hastening toward Good Deeds",
    ),
    "story_mon_1_translation": MessageLookupByLibrary.simpleMessage(
      "Race toward forgiveness from your Lord and a garden as wide as the heavens and the earth.",
    ),
    "story_mon_2_title": MessageLookupByLibrary.simpleMessage(
      "Praise and Gratitude to Allah",
    ),
    "story_mon_2_translation": MessageLookupByLibrary.simpleMessage(
      "All praise belongs to Allah, Lord of the worlds.",
    ),
    "story_mon_3_title": MessageLookupByLibrary.simpleMessage(
      "Repentance and Istighfar on Monday",
    ),
    "story_mon_3_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, Allah loves those who repent and loves those who purify themselves.",
    ),
    "story_mon_4_title": MessageLookupByLibrary.simpleMessage(
      "Truthfulness and Honesty",
    ),
    "story_mon_4_translation": MessageLookupByLibrary.simpleMessage(
      "O believers, fear Allah and be with the truthful.",
    ),
    "story_mon_5_title": MessageLookupByLibrary.simpleMessage(
      "Spending in the Way of Allah",
    ),
    "story_mon_5_translation": MessageLookupByLibrary.simpleMessage(
      "And those in whose wealth there is a known right for the beggar and the deprived.",
    ),
    "story_sat_1_title": MessageLookupByLibrary.simpleMessage(
      "Reciting Surah Al-Kahf",
    ),
    "story_sat_1_translation": MessageLookupByLibrary.simpleMessage(
      "Praise be to Allah who revealed the Book to His servant and placed no crookedness in it.",
    ),
    "story_sat_2_title": MessageLookupByLibrary.simpleMessage(
      "Saturday Supplication",
    ),
    "story_sat_2_translation": MessageLookupByLibrary.simpleMessage(
      "Our Lord, grant us mercy from Yourself and guide us rightly in our affair.",
    ),
    "story_sat_3_title": MessageLookupByLibrary.simpleMessage(
      "Establishing the Five Daily Prayers",
    ),
    "story_sat_3_translation": MessageLookupByLibrary.simpleMessage(
      "Establish prayer from the decline of the sun until the darkness of the night, and the Quran of dawn.",
    ),
    "story_sat_4_title": MessageLookupByLibrary.simpleMessage(
      "Giving Charity on Saturday",
    ),
    "story_sat_4_translation": MessageLookupByLibrary.simpleMessage(
      "Establish prayer, give zakat, and bow with those who bow.",
    ),
    "story_sat_5_title": MessageLookupByLibrary.simpleMessage(
      "Istighfar and Repentance",
    ),
    "story_sat_5_translation": MessageLookupByLibrary.simpleMessage(
      "So glorify your Lord with praise and seek His forgiveness. Indeed, He is ever accepting of repentance.",
    ),
    "story_sun_1_title": MessageLookupByLibrary.simpleMessage(
      "Supplication and Whispered Prayer on Sunday",
    ),
    "story_sun_1_translation": MessageLookupByLibrary.simpleMessage(
      "When My servants ask you about Me, indeed I am near. I respond to the call of the supplicant.",
    ),
    "story_sun_2_title": MessageLookupByLibrary.simpleMessage(
      "Dhikr and Tasbih",
    ),
    "story_sun_2_translation": MessageLookupByLibrary.simpleMessage(
      "Surely, in the remembrance of Allah do hearts find rest.",
    ),
    "story_sun_3_title": MessageLookupByLibrary.simpleMessage(
      "Voluntary Fasting on Sunday",
    ),
    "story_sun_3_translation": MessageLookupByLibrary.simpleMessage(
      "O you who believe, fasting has been prescribed for you as it was prescribed for those before you.",
    ),
    "story_sun_4_title": MessageLookupByLibrary.simpleMessage(
      "Recitation of the Noble Quran",
    ),
    "story_sun_4_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, this Quran guides to that which is most upright.",
    ),
    "story_sun_5_title": MessageLookupByLibrary.simpleMessage(
      "Sending Blessings upon the Prophet",
    ),
    "story_sun_5_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, Allah and His angels send blessings upon the Prophet. O believers, send blessings and peace upon him.",
    ),
    "story_thu_1_title": MessageLookupByLibrary.simpleMessage(
      "Glorifying Allah",
    ),
    "story_thu_1_translation": MessageLookupByLibrary.simpleMessage(
      "So exalted is He in whose hand is the dominion of all things, and to Him you will be returned.",
    ),
    "story_thu_2_title": MessageLookupByLibrary.simpleMessage(
      "Preparing for Friday Prayer",
    ),
    "story_thu_2_translation": MessageLookupByLibrary.simpleMessage(
      "O believers, when the call is made for prayer on Friday, hasten to the remembrance of Allah.",
    ),
    "story_thu_3_title": MessageLookupByLibrary.simpleMessage(
      "Night Prayer on Thursday",
    ),
    "story_thu_3_translation": MessageLookupByLibrary.simpleMessage(
      "And during part of the night, pray with it as extra worship for you.",
    ),
    "story_thu_4_title": MessageLookupByLibrary.simpleMessage(
      "Sincere Worship and Servitude",
    ),
    "story_thu_4_translation": MessageLookupByLibrary.simpleMessage(
      "I did not create jinn and mankind except that they worship Me.",
    ),
    "story_thu_5_title": MessageLookupByLibrary.simpleMessage(
      "Hope in Allah\'s Mercy",
    ),
    "story_thu_5_translation": MessageLookupByLibrary.simpleMessage(
      "Say: O My servants who have transgressed against themselves, do not despair of Allah\'s mercy.",
    ),
    "story_tue_1_title": MessageLookupByLibrary.simpleMessage(
      "Patience and Perseverance",
    ),
    "story_tue_1_translation": MessageLookupByLibrary.simpleMessage(
      "Allah does not burden a soul beyond its capacity. For it is what it has earned and against it is what it has committed.",
    ),
    "story_tue_2_title": MessageLookupByLibrary.simpleMessage(
      "Reciting Surah Al-Ikhlas",
    ),
    "story_tue_2_translation": MessageLookupByLibrary.simpleMessage(
      "Say: He is Allah, One. Allah, the Eternal Refuge.",
    ),
    "story_tue_3_title": MessageLookupByLibrary.simpleMessage(
      "Humility and Modesty",
    ),
    "story_tue_3_translation": MessageLookupByLibrary.simpleMessage(
      "The servants of the Most Merciful are those who walk upon the earth humbly.",
    ),
    "story_tue_4_title": MessageLookupByLibrary.simpleMessage(
      "Patience and Steadfastness",
    ),
    "story_tue_4_translation": MessageLookupByLibrary.simpleMessage(
      "Indeed, Allah is with the patient.",
    ),
    "story_tue_5_title": MessageLookupByLibrary.simpleMessage("Trust in Allah"),
    "story_tue_5_translation": MessageLookupByLibrary.simpleMessage(
      "Whoever relies upon Allah, He is sufficient for him. Indeed, Allah will accomplish His purpose.",
    ),
    "story_wed_1_title": MessageLookupByLibrary.simpleMessage(
      "Gratitude for Allah\'s Blessings",
    ),
    "story_wed_1_translation": MessageLookupByLibrary.simpleMessage(
      "So which of your Lord\'s favors will you both deny?",
    ),
    "story_wed_2_title": MessageLookupByLibrary.simpleMessage(
      "Good Deeds on Wednesday",
    ),
    "story_wed_2_translation": MessageLookupByLibrary.simpleMessage(
      "Whoever comes with a good deed shall have ten times the like of it.",
    ),
    "story_wed_3_title": MessageLookupByLibrary.simpleMessage(
      "Brotherhood and Reconciliation",
    ),
    "story_wed_3_translation": MessageLookupByLibrary.simpleMessage(
      "The believers are but brothers, so make peace between your brothers.",
    ),
    "story_wed_4_title": MessageLookupByLibrary.simpleMessage(
      "Seeking Knowledge",
    ),
    "story_wed_4_translation": MessageLookupByLibrary.simpleMessage(
      "And say: My Lord, increase me in knowledge.",
    ),
    "story_wed_5_title": MessageLookupByLibrary.simpleMessage(
      "Supplication and Prayer",
    ),
    "story_wed_5_translation": MessageLookupByLibrary.simpleMessage(
      "Your Lord said: Call upon Me; I will respond to you.",
    ),
    "sunrise": MessageLookupByLibrary.simpleMessage("Sunrise"),
    "support": MessageLookupByLibrary.simpleMessage("Sounds"),
    "surah": MessageLookupByLibrary.simpleMessage("Surah"),
    "tab_Ayah": MessageLookupByLibrary.simpleMessage("Ayah"),
    "tab_juz": MessageLookupByLibrary.simpleMessage("Juz"),
    "tab_surah": MessageLookupByLibrary.simpleMessage("Surah"),
    "tasbih_reset": MessageLookupByLibrary.simpleMessage("Reset"),
    "tasbih_tap_hint": MessageLookupByLibrary.simpleMessage("Tap to count"),
    "tasbih_title": MessageLookupByLibrary.simpleMessage("Tasbih"),
    "tasbih_total": m9,
    "theme": MessageLookupByLibrary.simpleMessage("Theme"),
    "time_hours_minutes": m10,
    "time_minutes_seconds": m11,
    "today_assistant_tools": MessageLookupByLibrary.simpleMessage(
      "Your Assistant Tools",
    ),
    "today_features_title": MessageLookupByLibrary.simpleMessage("Features"),
    "today_in_hours_minutes": m12,
    "today_in_minutes_seconds": m13,
    "today_monthly_deeds_subtitle": MessageLookupByLibrary.simpleMessage(
      "Virtues and deeds of this month",
    ),
    "today_monthly_deeds_title": MessageLookupByLibrary.simpleMessage(
      "Monthly Deeds",
    ),
    "today_next": MessageLookupByLibrary.simpleMessage("Next"),
    "today_now": MessageLookupByLibrary.simpleMessage("Now"),
    "today_zikr": MessageLookupByLibrary.simpleMessage("Today\'s Zikr"),
    "upcoming": MessageLookupByLibrary.simpleMessage("Upcoming"),
    "verse": MessageLookupByLibrary.simpleMessage("Verse"),
    "weekday_friday": MessageLookupByLibrary.simpleMessage("Friday"),
    "weekday_letter_friday": MessageLookupByLibrary.simpleMessage("F"),
    "weekday_letter_monday": MessageLookupByLibrary.simpleMessage("M"),
    "weekday_letter_saturday": MessageLookupByLibrary.simpleMessage("S"),
    "weekday_letter_sunday": MessageLookupByLibrary.simpleMessage("S"),
    "weekday_letter_thursday": MessageLookupByLibrary.simpleMessage("T"),
    "weekday_letter_tuesday": MessageLookupByLibrary.simpleMessage("T"),
    "weekday_letter_wednesday": MessageLookupByLibrary.simpleMessage("W"),
    "weekday_monday": MessageLookupByLibrary.simpleMessage("Monday"),
    "weekday_saturday": MessageLookupByLibrary.simpleMessage("Saturday"),
    "weekday_short_fri": MessageLookupByLibrary.simpleMessage("F"),
    "weekday_short_mon": MessageLookupByLibrary.simpleMessage("M"),
    "weekday_short_sat": MessageLookupByLibrary.simpleMessage("S"),
    "weekday_short_sun": MessageLookupByLibrary.simpleMessage("S"),
    "weekday_short_thu": MessageLookupByLibrary.simpleMessage("T"),
    "weekday_short_tue": MessageLookupByLibrary.simpleMessage("T"),
    "weekday_short_wed": MessageLookupByLibrary.simpleMessage("W"),
    "weekday_sunday": MessageLookupByLibrary.simpleMessage("Sunday"),
    "weekday_thursday": MessageLookupByLibrary.simpleMessage("Thursday"),
    "weekday_tuesday": MessageLookupByLibrary.simpleMessage("Tuesday"),
    "weekday_wednesday": MessageLookupByLibrary.simpleMessage("Wednesday"),
    "welcome_description": MessageLookupByLibrary.simpleMessage(
      "Take a minute to Personalize your app and stay on track with your prayers and Allah.",
    ),
    "welcome_goal_pray_consistently": MessageLookupByLibrary.simpleMessage(
      "Pray consistently",
    ),
    "welcome_goal_question": MessageLookupByLibrary.simpleMessage(
      "What is your Goal to More Focus on?",
    ),
    "welcome_goal_read_more_quran": MessageLookupByLibrary.simpleMessage(
      "Read more Quran",
    ),
    "welcome_start_button": MessageLookupByLibrary.simpleMessage(
      "Bismillah, let\'s start",
    ),
    "welcome_title": MessageLookupByLibrary.simpleMessage(
      "Salaam !\nWelcome to Hedaya 🌙",
    ),
  };
}
