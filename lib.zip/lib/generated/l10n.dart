// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(
      _current != null,
      'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(
      instance != null,
      'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Hedaya`
  String get splash_text {
    return Intl.message('Hedaya', name: 'splash_text', desc: '', args: []);
  }

  /// `Today's Date`
  String get header_date {
    return Intl.message(
      'Today\'s Date',
      name: 'header_date',
      desc: '',
      args: [],
    );
  }

  /// `Your Location`
  String get header_location {
    return Intl.message(
      'Your Location',
      name: 'header_location',
      desc: '',
      args: [],
    );
  }

  /// `Time`
  String get header_time {
    return Intl.message('Time', name: 'header_time', desc: '', args: []);
  }

  /// `Time remaining until Fajr`
  String get header_fajr {
    return Intl.message(
      'Time remaining until Fajr',
      name: 'header_fajr',
      desc: '',
      args: [],
    );
  }

  /// `Al-Quran`
  String get al_quran {
    return Intl.message('Al-Quran', name: 'al_quran', desc: '', args: []);
  }

  /// `Surah`
  String get tab_surah {
    return Intl.message('Surah', name: 'tab_surah', desc: '', args: []);
  }

  /// `Juz`
  String get tab_juz {
    return Intl.message('Juz', name: 'tab_juz', desc: '', args: []);
  }

  /// `Ayah`
  String get tab_Ayah {
    return Intl.message('Ayah', name: 'tab_Ayah', desc: '', args: []);
  }

  /// `No Surahs Found`
  String get no_surahs {
    return Intl.message(
      'No Surahs Found',
      name: 'no_surahs',
      desc: '',
      args: [],
    );
  }

  /// `No saved Ayah yet`
  String get no_ayah {
    return Intl.message(
      'No saved Ayah yet',
      name: 'no_ayah',
      desc: '',
      args: [],
    );
  }

  /// `No saved Surah yet`
  String get no_surah {
    return Intl.message(
      'No saved Surah yet',
      name: 'no_surah',
      desc: '',
      args: [],
    );
  }

  /// `No saved Juz yet`
  String get no_juz {
    return Intl.message('No saved Juz yet', name: 'no_juz', desc: '', args: []);
  }

  /// `Bookmarks`
  String get bookmar_title {
    return Intl.message('Bookmarks', name: 'bookmar_title', desc: '', args: []);
  }

  /// `Today's Zikr`
  String get today_zikr {
    return Intl.message(
      'Today\'s Zikr',
      name: 'today_zikr',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get nav_home {
    return Intl.message('Home', name: 'nav_home', desc: '', args: []);
  }

  /// `Quran`
  String get nav_Quran {
    return Intl.message('Quran', name: 'nav_Quran', desc: '', args: []);
  }

  /// `Prayer Times`
  String get nav_prayer {
    return Intl.message('Prayer Times', name: 'nav_prayer', desc: '', args: []);
  }

  /// `Home`
  String get nav_islam {
    return Intl.message('Home', name: 'nav_islam', desc: '', args: []);
  }

  /// `Search`
  String get nav_search {
    return Intl.message('Search', name: 'nav_search', desc: '', args: []);
  }

  /// `Settings`
  String get nav_settings {
    return Intl.message('Settings', name: 'nav_settings', desc: '', args: []);
  }

  /// `Search`
  String get search_hint {
    return Intl.message('Search', name: 'search_hint', desc: '', args: []);
  }

  /// `No results found`
  String get no_results {
    return Intl.message(
      'No results found',
      name: 'no_results',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings_title {
    return Intl.message('Settings', name: 'settings_title', desc: '', args: []);
  }

  /// `Recent Downloads`
  String get recent_downloads {
    return Intl.message(
      'Recent Downloads',
      name: 'recent_downloads',
      desc: '',
      args: [],
    );
  }

  /// `Share App`
  String get share_apps {
    return Intl.message('Share App', name: 'share_apps', desc: '', args: []);
  }

  /// `My Network`
  String get my_network {
    return Intl.message('My Network', name: 'my_network', desc: '', args: []);
  }

  /// `Payments`
  String get payments {
    return Intl.message('Payments', name: 'payments', desc: '', args: []);
  }

  /// `Sounds`
  String get support {
    return Intl.message('Sounds', name: 'support', desc: '', args: []);
  }

  /// `Allow Notifications`
  String get allow_notifications {
    return Intl.message(
      'Allow Notifications',
      name: 'allow_notifications',
      desc: '',
      args: [],
    );
  }

  /// `Auto Scroll During Recitation`
  String get auto_scroll {
    return Intl.message(
      'Auto Scroll During Recitation',
      name: 'auto_scroll',
      desc: '',
      args: [],
    );
  }

  /// `Preview Text`
  String get preview_text {
    return Intl.message(
      'Preview Text',
      name: 'preview_text',
      desc: '',
      args: [],
    );
  }

  /// `Quran Font Size`
  String get quran_font_size {
    return Intl.message(
      'Quran Font Size',
      name: 'quran_font_size',
      desc: '',
      args: [],
    );
  }

  /// `Account Admin`
  String get account_admin {
    return Intl.message(
      'Account Admin',
      name: 'account_admin',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message('Login', name: 'login', desc: '', args: []);
  }

  /// `Quran Mobile App`
  String get quran_app {
    return Intl.message(
      'Quran Mobile App',
      name: 'quran_app',
      desc: '',
      args: [],
    );
  }

  /// `Share App`
  String get share {
    return Intl.message('Share App', name: 'share', desc: '', args: []);
  }

  /// `About App`
  String get about_app {
    return Intl.message('About App', name: 'about_app', desc: '', args: []);
  }

  /// `Filter`
  String get filter {
    return Intl.message('Filter', name: 'filter', desc: '', args: []);
  }

  /// `Search by Ayah`
  String get search_ayah {
    return Intl.message(
      'Search by Ayah',
      name: 'search_ayah',
      desc: '',
      args: [],
    );
  }

  /// `Search by Surah`
  String get search_surah {
    return Intl.message(
      'Search by Surah',
      name: 'search_surah',
      desc: '',
      args: [],
    );
  }

  /// `Search for a Surah by its name`
  String get search_surah_subtitle {
    return Intl.message(
      'Search for a Surah by its name',
      name: 'search_surah_subtitle',
      desc: '',
      args: [],
    );
  }

  /// `Search for an Ayah by its text`
  String get search_ayah_subtitle {
    return Intl.message(
      'Search for an Ayah by its text',
      name: 'search_ayah_subtitle',
      desc: '',
      args: [],
    );
  }

  /// `Prayer Times`
  String get prayer_times {
    return Intl.message(
      'Prayer Times',
      name: 'prayer_times',
      desc: '',
      args: [],
    );
  }

  /// `Fajr`
  String get fajr {
    return Intl.message('Fajr', name: 'fajr', desc: '', args: []);
  }

  /// `Sunrise`
  String get sunrise {
    return Intl.message('Sunrise', name: 'sunrise', desc: '', args: []);
  }

  /// `Dhuhr`
  String get dhuhr {
    return Intl.message('Dhuhr', name: 'dhuhr', desc: '', args: []);
  }

  /// `Asr`
  String get asr {
    return Intl.message('Asr', name: 'asr', desc: '', args: []);
  }

  /// `Maghrib`
  String get maghrib {
    return Intl.message('Maghrib', name: 'maghrib', desc: '', args: []);
  }

  /// `Isha'a`
  String get isha {
    return Intl.message('Isha\'a', name: 'isha', desc: '', args: []);
  }

  /// `Now`
  String get now {
    return Intl.message('Now', name: 'now', desc: '', args: []);
  }

  /// `Next`
  String get next {
    return Intl.message('Next', name: 'next', desc: '', args: []);
  }

  /// `Upcoming`
  String get upcoming {
    return Intl.message('Upcoming', name: 'upcoming', desc: '', args: []);
  }

  /// `Enable Location`
  String get location_permission {
    return Intl.message(
      'Enable Location',
      name: 'location_permission',
      desc: '',
      args: [],
    );
  }

  /// `Location is required for accurate prayer times`
  String get location_required {
    return Intl.message(
      'Location is required for accurate prayer times',
      name: 'location_required',
      desc: '',
      args: [],
    );
  }

  /// `Location acquired`
  String get location_success {
    return Intl.message(
      'Location acquired',
      name: 'location_success',
      desc: '',
      args: [],
    );
  }

  /// `Enable Notifications`
  String get enable_notification {
    return Intl.message(
      'Enable Notifications',
      name: 'enable_notification',
      desc: '',
      args: [],
    );
  }

  /// `Don't miss prayer time with Adhan reminders`
  String get notification_desc {
    return Intl.message(
      'Don\'t miss prayer time with Adhan reminders',
      name: 'notification_desc',
      desc: '',
      args: [],
    );
  }

  /// `Done`
  String get done {
    return Intl.message('Done', name: 'done', desc: '', args: []);
  }

  /// `Skip`
  String get skip {
    return Intl.message('Skip', name: 'skip', desc: '', args: []);
  }

  /// `Enable Location`
  String get enable_location {
    return Intl.message(
      'Enable Location',
      name: 'enable_location',
      desc: '',
      args: [],
    );
  }

  /// `See Prayer Times`
  String get see_prayer_times {
    return Intl.message(
      'See Prayer Times',
      name: 'see_prayer_times',
      desc: '',
      args: [],
    );
  }

  /// `Events of This Day`
  String get events_of_day {
    return Intl.message(
      'Events of This Day',
      name: 'events_of_day',
      desc: '',
      args: [],
    );
  }

  /// `Hijri`
  String get hijri {
    return Intl.message('Hijri', name: 'hijri', desc: '', args: []);
  }

  /// `Shamsi`
  String get shamsi {
    return Intl.message('Shamsi', name: 'shamsi', desc: '', args: []);
  }

  /// `Bookmark`
  String get bookmark {
    return Intl.message('Bookmark', name: 'bookmark', desc: '', args: []);
  }

  /// `Reading`
  String get reading {
    return Intl.message('Reading', name: 'reading', desc: '', args: []);
  }

  /// `Continue Reading`
  String get continue_reading {
    return Intl.message(
      'Continue Reading',
      name: 'continue_reading',
      desc: '',
      args: [],
    );
  }

  /// `Surah`
  String get surah {
    return Intl.message('Surah', name: 'surah', desc: '', args: []);
  }

  /// `Juz`
  String get juz {
    return Intl.message('Juz', name: 'juz', desc: '', args: []);
  }

  /// `Verse`
  String get verse {
    return Intl.message('Verse', name: 'verse', desc: '', args: []);
  }

  /// `Font Size`
  String get font_size {
    return Intl.message('Font Size', name: 'font_size', desc: '', args: []);
  }

  /// `Theme`
  String get theme {
    return Intl.message('Theme', name: 'theme', desc: '', args: []);
  }

  /// `Language`
  String get language {
    return Intl.message('Language', name: 'language', desc: '', args: []);
  }

  /// `Dark Mode`
  String get dark_mode {
    return Intl.message('Dark Mode', name: 'dark_mode', desc: '', args: []);
  }

  /// `Light Mode`
  String get light_mode {
    return Intl.message('Light Mode', name: 'light_mode', desc: '', args: []);
  }

  /// `Salaam !\nWelcome to Hedaya 🌙`
  String get welcome_title {
    return Intl.message(
      'Salaam !\nWelcome to Hedaya 🌙',
      name: 'welcome_title',
      desc: '',
      args: [],
    );
  }

  /// `What is your Goal to More Focus on?`
  String get welcome_goal_question {
    return Intl.message(
      'What is your Goal to More Focus on?',
      name: 'welcome_goal_question',
      desc: '',
      args: [],
    );
  }

  /// `Pray consistently`
  String get welcome_goal_pray_consistently {
    return Intl.message(
      'Pray consistently',
      name: 'welcome_goal_pray_consistently',
      desc: '',
      args: [],
    );
  }

  /// `Read more Quran`
  String get welcome_goal_read_more_quran {
    return Intl.message(
      'Read more Quran',
      name: 'welcome_goal_read_more_quran',
      desc: '',
      args: [],
    );
  }

  /// `Take a minute to Personalize your app and stay on track with your prayers and Allah.`
  String get welcome_description {
    return Intl.message(
      'Take a minute to Personalize your app and stay on track with your prayers and Allah.',
      name: 'welcome_description',
      desc: '',
      args: [],
    );
  }

  /// `Bismillah, let's start`
  String get welcome_start_button {
    return Intl.message(
      'Bismillah, let\'s start',
      name: 'welcome_start_button',
      desc: '',
      args: [],
    );
  }

  /// `Close`
  String get onboarding_close {
    return Intl.message('Close', name: 'onboarding_close', desc: '', args: []);
  }

  /// `Please enable location permission and GPS`
  String get location_permission_denied_message {
    return Intl.message(
      'Please enable location permission and GPS',
      name: 'location_permission_denied_message',
      desc: '',
      args: [],
    );
  }

  /// `Enable Notifications and Finish`
  String get enable_notifications_and_finish {
    return Intl.message(
      'Enable Notifications and Finish',
      name: 'enable_notifications_and_finish',
      desc: '',
      args: [],
    );
  }

  /// `Read`
  String get quran_read_tab {
    return Intl.message('Read', name: 'quran_read_tab', desc: '', args: []);
  }

  /// `My Progress`
  String get quran_progress_tab {
    return Intl.message(
      'My Progress',
      name: 'quran_progress_tab',
      desc: '',
      args: [],
    );
  }

  /// `Recents`
  String get quran_recents {
    return Intl.message('Recents', name: 'quran_recents', desc: '', args: []);
  }

  /// `Sura list`
  String get quran_sura_list {
    return Intl.message(
      'Sura list',
      name: 'quran_sura_list',
      desc: '',
      args: [],
    );
  }

  /// `Juz list`
  String get quran_juz_list {
    return Intl.message('Juz list', name: 'quran_juz_list', desc: '', args: []);
  }

  /// `View: {type}`
  String quran_view_label(Object type) {
    return Intl.message(
      'View: $type',
      name: 'quran_view_label',
      desc: '',
      args: [type],
    );
  }

  /// `Sura`
  String get quran_view_sura {
    return Intl.message('Sura', name: 'quran_view_sura', desc: '', args: []);
  }

  /// `Juz`
  String get quran_view_juz {
    return Intl.message('Juz', name: 'quran_view_juz', desc: '', args: []);
  }

  /// `{count} Ayah`
  String quran_ayah_count(Object count) {
    return Intl.message(
      '$count Ayah',
      name: 'quran_ayah_count',
      desc: '',
      args: [count],
    );
  }

  /// `Juz {number}`
  String quran_juz_header(Object number) {
    return Intl.message(
      'Juz $number',
      name: 'quran_juz_header',
      desc: '',
      args: [number],
    );
  }

  /// `Aya {number}`
  String quran_aya_short(Object number) {
    return Intl.message(
      'Aya $number',
      name: 'quran_aya_short',
      desc: '',
      args: [number],
    );
  }

  /// `Khatam`
  String get quran_khatam_tab {
    return Intl.message('Khatam', name: 'quran_khatam_tab', desc: '', args: []);
  }

  /// `Juz done`
  String get quran_juz_done {
    return Intl.message('Juz done', name: 'quran_juz_done', desc: '', args: []);
  }

  /// `Surah done`
  String get quran_surah_done {
    return Intl.message(
      'Surah done',
      name: 'quran_surah_done',
      desc: '',
      args: [],
    );
  }

  /// `Complete a Surah to see it here`
  String get quran_complete_surah_message {
    return Intl.message(
      'Complete a Surah to see it here',
      name: 'quran_complete_surah_message',
      desc: '',
      args: [],
    );
  }

  /// `✓ Completed`
  String get quran_completed {
    return Intl.message(
      '✓ Completed',
      name: 'quran_completed',
      desc: '',
      args: [],
    );
  }

  /// `Last read`
  String get quran_last_read {
    return Intl.message(
      'Last read',
      name: 'quran_last_read',
      desc: '',
      args: [],
    );
  }

  /// `No reading yet`
  String get quran_no_reading_yet {
    return Intl.message(
      'No reading yet',
      name: 'quran_no_reading_yet',
      desc: '',
      args: [],
    );
  }

  /// `minute read`
  String get quran_minute_read {
    return Intl.message(
      'minute read',
      name: 'quran_minute_read',
      desc: '',
      args: [],
    );
  }

  /// `Reading Progress`
  String get quran_reading_progress_title {
    return Intl.message(
      'Reading Progress',
      name: 'quran_reading_progress_title',
      desc: '',
      args: [],
    );
  }

  /// `Scroll-based progress per Surah & Juz`
  String get quran_reading_progress_subtitle {
    return Intl.message(
      'Scroll-based progress per Surah & Juz',
      name: 'quran_reading_progress_subtitle',
      desc: '',
      args: [],
    );
  }

  /// `Surah {number}`
  String quran_surah_label(Object number) {
    return Intl.message(
      'Surah $number',
      name: 'quran_surah_label',
      desc: '',
      args: [number],
    );
  }

  /// `Juz {number}`
  String quran_juz_label(Object number) {
    return Intl.message(
      'Juz $number',
      name: 'quran_juz_label',
      desc: '',
      args: [number],
    );
  }

  /// `Start reading to track progress`
  String get quran_start_reading_progress {
    return Intl.message(
      'Start reading to track progress',
      name: 'quran_start_reading_progress',
      desc: '',
      args: [],
    );
  }

  /// `Prayer Times`
  String get prayer_times_title {
    return Intl.message(
      'Prayer Times',
      name: 'prayer_times_title',
      desc: '',
      args: [],
    );
  }

  /// `Gregorian`
  String get calendar_gregorian {
    return Intl.message(
      'Gregorian',
      name: 'calendar_gregorian',
      desc: '',
      args: [],
    );
  }

  /// `Hijri`
  String get calendar_hijri {
    return Intl.message('Hijri', name: 'calendar_hijri', desc: '', args: []);
  }

  /// `Now`
  String get prayer_now {
    return Intl.message('Now', name: 'prayer_now', desc: '', args: []);
  }

  /// `Next`
  String get prayer_next {
    return Intl.message('Next', name: 'prayer_next', desc: '', args: []);
  }

  /// `In {time}`
  String prayer_in(Object time) {
    return Intl.message('In $time', name: 'prayer_in', desc: '', args: [time]);
  }

  /// `Completed`
  String get prayer_completed_count {
    return Intl.message(
      'Completed',
      name: 'prayer_completed_count',
      desc: '',
      args: [],
    );
  }

  /// `Now`
  String get prayer_now_badge {
    return Intl.message('Now', name: 'prayer_now_badge', desc: '', args: []);
  }

  /// `Fajr`
  String get prayer_fajr_local {
    return Intl.message('Fajr', name: 'prayer_fajr_local', desc: '', args: []);
  }

  /// `Dhuhr`
  String get prayer_dhuhr_local {
    return Intl.message(
      'Dhuhr',
      name: 'prayer_dhuhr_local',
      desc: '',
      args: [],
    );
  }

  /// `Asr`
  String get prayer_asr_local {
    return Intl.message('Asr', name: 'prayer_asr_local', desc: '', args: []);
  }

  /// `Maghrib`
  String get prayer_maghrib_local {
    return Intl.message(
      'Maghrib',
      name: 'prayer_maghrib_local',
      desc: '',
      args: [],
    );
  }

  /// `Isha`
  String get prayer_isha_local {
    return Intl.message('Isha', name: 'prayer_isha_local', desc: '', args: []);
  }

  /// `{hours}h {minutes}m`
  String time_hours_minutes(Object hours, Object minutes) {
    return Intl.message(
      '${hours}h ${minutes}m',
      name: 'time_hours_minutes',
      desc: '',
      args: [hours, minutes],
    );
  }

  /// `{minutes}m {seconds}s`
  String time_minutes_seconds(Object minutes, Object seconds) {
    return Intl.message(
      '${minutes}m ${seconds}s',
      name: 'time_minutes_seconds',
      desc: '',
      args: [minutes, seconds],
    );
  }

  /// `January`
  String get month_january {
    return Intl.message('January', name: 'month_january', desc: '', args: []);
  }

  /// `February`
  String get month_february {
    return Intl.message('February', name: 'month_february', desc: '', args: []);
  }

  /// `March`
  String get month_march {
    return Intl.message('March', name: 'month_march', desc: '', args: []);
  }

  /// `April`
  String get month_april {
    return Intl.message('April', name: 'month_april', desc: '', args: []);
  }

  /// `May`
  String get month_may {
    return Intl.message('May', name: 'month_may', desc: '', args: []);
  }

  /// `June`
  String get month_june {
    return Intl.message('June', name: 'month_june', desc: '', args: []);
  }

  /// `July`
  String get month_july {
    return Intl.message('July', name: 'month_july', desc: '', args: []);
  }

  /// `August`
  String get month_august {
    return Intl.message('August', name: 'month_august', desc: '', args: []);
  }

  /// `September`
  String get month_september {
    return Intl.message(
      'September',
      name: 'month_september',
      desc: '',
      args: [],
    );
  }

  /// `October`
  String get month_october {
    return Intl.message('October', name: 'month_october', desc: '', args: []);
  }

  /// `November`
  String get month_november {
    return Intl.message('November', name: 'month_november', desc: '', args: []);
  }

  /// `December`
  String get month_december {
    return Intl.message('December', name: 'month_december', desc: '', args: []);
  }

  /// `S`
  String get weekday_short_sat {
    return Intl.message('S', name: 'weekday_short_sat', desc: '', args: []);
  }

  /// `S`
  String get weekday_short_sun {
    return Intl.message('S', name: 'weekday_short_sun', desc: '', args: []);
  }

  /// `M`
  String get weekday_short_mon {
    return Intl.message('M', name: 'weekday_short_mon', desc: '', args: []);
  }

  /// `T`
  String get weekday_short_tue {
    return Intl.message('T', name: 'weekday_short_tue', desc: '', args: []);
  }

  /// `W`
  String get weekday_short_wed {
    return Intl.message('W', name: 'weekday_short_wed', desc: '', args: []);
  }

  /// `T`
  String get weekday_short_thu {
    return Intl.message('T', name: 'weekday_short_thu', desc: '', args: []);
  }

  /// `F`
  String get weekday_short_fri {
    return Intl.message('F', name: 'weekday_short_fri', desc: '', args: []);
  }

  /// `Muharram`
  String get hijri_muharram {
    return Intl.message('Muharram', name: 'hijri_muharram', desc: '', args: []);
  }

  /// `Safar`
  String get hijri_safar {
    return Intl.message('Safar', name: 'hijri_safar', desc: '', args: []);
  }

  /// `Rabi al-Awwal`
  String get hijri_rabi_al_awwal {
    return Intl.message(
      'Rabi al-Awwal',
      name: 'hijri_rabi_al_awwal',
      desc: '',
      args: [],
    );
  }

  /// `Rabi al-Thani`
  String get hijri_rabi_al_thani {
    return Intl.message(
      'Rabi al-Thani',
      name: 'hijri_rabi_al_thani',
      desc: '',
      args: [],
    );
  }

  /// `Jumada al-Awwal`
  String get hijri_jumada_al_awwal {
    return Intl.message(
      'Jumada al-Awwal',
      name: 'hijri_jumada_al_awwal',
      desc: '',
      args: [],
    );
  }

  /// `Jumada al-Thani`
  String get hijri_jumada_al_thani {
    return Intl.message(
      'Jumada al-Thani',
      name: 'hijri_jumada_al_thani',
      desc: '',
      args: [],
    );
  }

  /// `Rajab`
  String get hijri_rajab {
    return Intl.message('Rajab', name: 'hijri_rajab', desc: '', args: []);
  }

  /// `Sha'ban`
  String get hijri_shaban {
    return Intl.message('Sha\'ban', name: 'hijri_shaban', desc: '', args: []);
  }

  /// `Ramadan`
  String get hijri_ramadan {
    return Intl.message('Ramadan', name: 'hijri_ramadan', desc: '', args: []);
  }

  /// `Shawwal`
  String get hijri_shawwal {
    return Intl.message('Shawwal', name: 'hijri_shawwal', desc: '', args: []);
  }

  /// `Dhul-Qadah`
  String get hijri_dhul_qadah {
    return Intl.message(
      'Dhul-Qadah',
      name: 'hijri_dhul_qadah',
      desc: '',
      args: [],
    );
  }

  /// `Dhul-Hijjah`
  String get hijri_dhul_hijjah {
    return Intl.message(
      'Dhul-Hijjah',
      name: 'hijri_dhul_hijjah',
      desc: '',
      args: [],
    );
  }

  /// `Tasbih`
  String get tasbih_title {
    return Intl.message('Tasbih', name: 'tasbih_title', desc: '', args: []);
  }

  /// `Reset`
  String get tasbih_reset {
    return Intl.message('Reset', name: 'tasbih_reset', desc: '', args: []);
  }

  /// `Total: {count}`
  String tasbih_total(Object count) {
    return Intl.message(
      'Total: $count',
      name: 'tasbih_total',
      desc: '',
      args: [count],
    );
  }

  /// `Tap to count`
  String get tasbih_tap_hint {
    return Intl.message(
      'Tap to count',
      name: 'tasbih_tap_hint',
      desc: '',
      args: [],
    );
  }

  /// `Qibla Direction`
  String get qibla_title {
    return Intl.message(
      'Qibla Direction',
      name: 'qibla_title',
      desc: '',
      args: [],
    );
  }

  /// `This feature is under development and will be available in the next version.`
  String get qibla_coming_desc {
    return Intl.message(
      'This feature is under development and will be available in the next version.',
      name: 'qibla_coming_desc',
      desc: '',
      args: [],
    );
  }

  /// `Coming Soon`
  String get coming_soon {
    return Intl.message('Coming Soon', name: 'coming_soon', desc: '', args: []);
  }

  /// `Duas`
  String get duas_title {
    return Intl.message('Duas', name: 'duas_title', desc: '', args: []);
  }

  /// `Morning`
  String get dua_category_morning {
    return Intl.message(
      'Morning',
      name: 'dua_category_morning',
      desc: '',
      args: [],
    );
  }

  /// `Night`
  String get dua_category_night {
    return Intl.message(
      'Night',
      name: 'dua_category_night',
      desc: '',
      args: [],
    );
  }

  /// `Prayer`
  String get dua_category_prayer {
    return Intl.message(
      'Prayer',
      name: 'dua_category_prayer',
      desc: '',
      args: [],
    );
  }

  /// `Istighfar`
  String get dua_category_istighfar {
    return Intl.message(
      'Istighfar',
      name: 'dua_category_istighfar',
      desc: '',
      args: [],
    );
  }

  /// `Family`
  String get dua_category_family {
    return Intl.message(
      'Family',
      name: 'dua_category_family',
      desc: '',
      args: [],
    );
  }

  /// `Trust`
  String get dua_category_trust {
    return Intl.message(
      'Trust',
      name: 'dua_category_trust',
      desc: '',
      args: [],
    );
  }

  /// `Morning Dua`
  String get dua_title_morning {
    return Intl.message(
      'Morning Dua',
      name: 'dua_title_morning',
      desc: '',
      args: [],
    );
  }

  /// `Before Sleep Dua`
  String get dua_title_before_sleep {
    return Intl.message(
      'Before Sleep Dua',
      name: 'dua_title_before_sleep',
      desc: '',
      args: [],
    );
  }

  /// `After Prayer Dua`
  String get dua_title_after_prayer {
    return Intl.message(
      'After Prayer Dua',
      name: 'dua_title_after_prayer',
      desc: '',
      args: [],
    );
  }

  /// `Istighfar Dua`
  String get dua_title_istighfar {
    return Intl.message(
      'Istighfar Dua',
      name: 'dua_title_istighfar',
      desc: '',
      args: [],
    );
  }

  /// `Dua for Parents`
  String get dua_title_parents {
    return Intl.message(
      'Dua for Parents',
      name: 'dua_title_parents',
      desc: '',
      args: [],
    );
  }

  /// `Dua of Trust`
  String get dua_title_trust {
    return Intl.message(
      'Dua of Trust',
      name: 'dua_title_trust',
      desc: '',
      args: [],
    );
  }

  /// `Khatam Quran`
  String get khatam_title {
    return Intl.message(
      'Khatam Quran',
      name: 'khatam_title',
      desc: '',
      args: [],
    );
  }

  /// `{percent}% completed`
  String khatam_completed_percent(Object percent) {
    return Intl.message(
      '$percent% completed',
      name: 'khatam_completed_percent',
      desc: '',
      args: [percent],
    );
  }

  /// `Features`
  String get today_features_title {
    return Intl.message(
      'Features',
      name: 'today_features_title',
      desc: '',
      args: [],
    );
  }

  /// `Your Assistant Tools`
  String get today_assistant_tools {
    return Intl.message(
      'Your Assistant Tools',
      name: 'today_assistant_tools',
      desc: '',
      args: [],
    );
  }

  /// `Monthly Deeds`
  String get today_monthly_deeds_title {
    return Intl.message(
      'Monthly Deeds',
      name: 'today_monthly_deeds_title',
      desc: '',
      args: [],
    );
  }

  /// `Virtues and deeds of this month`
  String get today_monthly_deeds_subtitle {
    return Intl.message(
      'Virtues and deeds of this month',
      name: 'today_monthly_deeds_subtitle',
      desc: '',
      args: [],
    );
  }

  /// `Now`
  String get today_now {
    return Intl.message('Now', name: 'today_now', desc: '', args: []);
  }

  /// `Next`
  String get today_next {
    return Intl.message('Next', name: 'today_next', desc: '', args: []);
  }

  /// `In {hours}h {minutes}m`
  String today_in_hours_minutes(Object hours, Object minutes) {
    return Intl.message(
      'In ${hours}h ${minutes}m',
      name: 'today_in_hours_minutes',
      desc: '',
      args: [hours, minutes],
    );
  }

  /// `In {minutes}m {seconds}s`
  String today_in_minutes_seconds(Object minutes, Object seconds) {
    return Intl.message(
      'In ${minutes}m ${seconds}s',
      name: 'today_in_minutes_seconds',
      desc: '',
      args: [minutes, seconds],
    );
  }

  /// `Notifications`
  String get settings_notifications_section {
    return Intl.message(
      'Notifications',
      name: 'settings_notifications_section',
      desc: '',
      args: [],
    );
  }

  /// `Reading`
  String get settings_reading_section {
    return Intl.message(
      'Reading',
      name: 'settings_reading_section',
      desc: '',
      args: [],
    );
  }

  /// `App Language`
  String get settings_app_language_section {
    return Intl.message(
      'App Language',
      name: 'settings_app_language_section',
      desc: '',
      args: [],
    );
  }

  /// `Allow Notifications`
  String get settings_allow_notifications {
    return Intl.message(
      'Allow Notifications',
      name: 'settings_allow_notifications',
      desc: '',
      args: [],
    );
  }

  /// `Auto Scroll`
  String get settings_auto_scroll {
    return Intl.message(
      'Auto Scroll',
      name: 'settings_auto_scroll',
      desc: '',
      args: [],
    );
  }

  /// `Font Size`
  String get settings_font_size {
    return Intl.message(
      'Font Size',
      name: 'settings_font_size',
      desc: '',
      args: [],
    );
  }

  /// `English`
  String get settings_language_english {
    return Intl.message(
      'English',
      name: 'settings_language_english',
      desc: '',
      args: [],
    );
  }

  /// `Dari / Farsi`
  String get settings_language_dari {
    return Intl.message(
      'Dari / Farsi',
      name: 'settings_language_dari',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Rajab`
  String get monthly_deeds_rajab_title {
    return Intl.message(
      'Deeds of Rajab',
      name: 'monthly_deeds_rajab_title',
      desc: '',
      args: [],
    );
  }

  /// `Fasting on recommended days`
  String get monthly_deeds_rajab_deed_1 {
    return Intl.message(
      'Fasting on recommended days',
      name: 'monthly_deeds_rajab_deed_1',
      desc: '',
      args: [],
    );
  }

  /// `Reciting the Dua Ya Man Arjuhu`
  String get monthly_deeds_rajab_deed_2 {
    return Intl.message(
      'Reciting the Dua Ya Man Arjuhu',
      name: 'monthly_deeds_rajab_deed_2',
      desc: '',
      args: [],
    );
  }

  /// `Frequent Istighfar`
  String get monthly_deeds_rajab_deed_3 {
    return Intl.message(
      'Frequent Istighfar',
      name: 'monthly_deeds_rajab_deed_3',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Sha'ban`
  String get monthly_deeds_shaban_title {
    return Intl.message(
      'Deeds of Sha\'ban',
      name: 'monthly_deeds_shaban_title',
      desc: '',
      args: [],
    );
  }

  /// `Salawat Sha'baniyyah`
  String get monthly_deeds_shaban_deed_1 {
    return Intl.message(
      'Salawat Sha\'baniyyah',
      name: 'monthly_deeds_shaban_deed_1',
      desc: '',
      args: [],
    );
  }

  /// `Recommended fasting`
  String get monthly_deeds_shaban_deed_2 {
    return Intl.message(
      'Recommended fasting',
      name: 'monthly_deeds_shaban_deed_2',
      desc: '',
      args: [],
    );
  }

  /// `Giving charity`
  String get monthly_deeds_shaban_deed_3 {
    return Intl.message(
      'Giving charity',
      name: 'monthly_deeds_shaban_deed_3',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Ramadan`
  String get monthly_deeds_ramadan_title {
    return Intl.message(
      'Deeds of Ramadan',
      name: 'monthly_deeds_ramadan_title',
      desc: '',
      args: [],
    );
  }

  /// `Fasting`
  String get monthly_deeds_ramadan_deed_1 {
    return Intl.message(
      'Fasting',
      name: 'monthly_deeds_ramadan_deed_1',
      desc: '',
      args: [],
    );
  }

  /// `Reciting the Quran`
  String get monthly_deeds_ramadan_deed_2 {
    return Intl.message(
      'Reciting the Quran',
      name: 'monthly_deeds_ramadan_deed_2',
      desc: '',
      args: [],
    );
  }

  /// `Dua al-Iftitah`
  String get monthly_deeds_ramadan_deed_3 {
    return Intl.message(
      'Dua al-Iftitah',
      name: 'monthly_deeds_ramadan_deed_3',
      desc: '',
      args: [],
    );
  }

  /// `Reviving the Nights of Qadr`
  String get monthly_deeds_ramadan_deed_4 {
    return Intl.message(
      'Reviving the Nights of Qadr',
      name: 'monthly_deeds_ramadan_deed_4',
      desc: '',
      args: [],
    );
  }

  /// `Saturday`
  String get weekday_saturday {
    return Intl.message(
      'Saturday',
      name: 'weekday_saturday',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Saturday`
  String get day_name_saturday {
    return Intl.message(
      'Deeds of Saturday',
      name: 'day_name_saturday',
      desc: '',
      args: [],
    );
  }

  /// `S`
  String get weekday_letter_saturday {
    return Intl.message(
      'S',
      name: 'weekday_letter_saturday',
      desc: '',
      args: [],
    );
  }

  /// `Sunday`
  String get weekday_sunday {
    return Intl.message('Sunday', name: 'weekday_sunday', desc: '', args: []);
  }

  /// `Deeds of Sunday`
  String get day_name_sunday {
    return Intl.message(
      'Deeds of Sunday',
      name: 'day_name_sunday',
      desc: '',
      args: [],
    );
  }

  /// `S`
  String get weekday_letter_sunday {
    return Intl.message('S', name: 'weekday_letter_sunday', desc: '', args: []);
  }

  /// `Monday`
  String get weekday_monday {
    return Intl.message('Monday', name: 'weekday_monday', desc: '', args: []);
  }

  /// `Deeds of Monday`
  String get day_name_monday {
    return Intl.message(
      'Deeds of Monday',
      name: 'day_name_monday',
      desc: '',
      args: [],
    );
  }

  /// `M`
  String get weekday_letter_monday {
    return Intl.message('M', name: 'weekday_letter_monday', desc: '', args: []);
  }

  /// `Tuesday`
  String get weekday_tuesday {
    return Intl.message('Tuesday', name: 'weekday_tuesday', desc: '', args: []);
  }

  /// `Deeds of Tuesday`
  String get day_name_tuesday {
    return Intl.message(
      'Deeds of Tuesday',
      name: 'day_name_tuesday',
      desc: '',
      args: [],
    );
  }

  /// `T`
  String get weekday_letter_tuesday {
    return Intl.message(
      'T',
      name: 'weekday_letter_tuesday',
      desc: '',
      args: [],
    );
  }

  /// `Wednesday`
  String get weekday_wednesday {
    return Intl.message(
      'Wednesday',
      name: 'weekday_wednesday',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Wednesday`
  String get day_name_wednesday {
    return Intl.message(
      'Deeds of Wednesday',
      name: 'day_name_wednesday',
      desc: '',
      args: [],
    );
  }

  /// `W`
  String get weekday_letter_wednesday {
    return Intl.message(
      'W',
      name: 'weekday_letter_wednesday',
      desc: '',
      args: [],
    );
  }

  /// `Thursday`
  String get weekday_thursday {
    return Intl.message(
      'Thursday',
      name: 'weekday_thursday',
      desc: '',
      args: [],
    );
  }

  /// `Deeds of Thursday`
  String get day_name_thursday {
    return Intl.message(
      'Deeds of Thursday',
      name: 'day_name_thursday',
      desc: '',
      args: [],
    );
  }

  /// `T`
  String get weekday_letter_thursday {
    return Intl.message(
      'T',
      name: 'weekday_letter_thursday',
      desc: '',
      args: [],
    );
  }

  /// `Friday`
  String get weekday_friday {
    return Intl.message('Friday', name: 'weekday_friday', desc: '', args: []);
  }

  /// `Deeds of Friday`
  String get day_name_friday {
    return Intl.message(
      'Deeds of Friday',
      name: 'day_name_friday',
      desc: '',
      args: [],
    );
  }

  /// `F`
  String get weekday_letter_friday {
    return Intl.message('F', name: 'weekday_letter_friday', desc: '', args: []);
  }

  /// `Reciting Surah Al-Kahf`
  String get story_sat_1_title {
    return Intl.message(
      'Reciting Surah Al-Kahf',
      name: 'story_sat_1_title',
      desc: '',
      args: [],
    );
  }

  /// `Praise be to Allah who revealed the Book to His servant and placed no crookedness in it.`
  String get story_sat_1_translation {
    return Intl.message(
      'Praise be to Allah who revealed the Book to His servant and placed no crookedness in it.',
      name: 'story_sat_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Saturday Supplication`
  String get story_sat_2_title {
    return Intl.message(
      'Saturday Supplication',
      name: 'story_sat_2_title',
      desc: '',
      args: [],
    );
  }

  /// `Our Lord, grant us mercy from Yourself and guide us rightly in our affair.`
  String get story_sat_2_translation {
    return Intl.message(
      'Our Lord, grant us mercy from Yourself and guide us rightly in our affair.',
      name: 'story_sat_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Establishing the Five Daily Prayers`
  String get story_sat_3_title {
    return Intl.message(
      'Establishing the Five Daily Prayers',
      name: 'story_sat_3_title',
      desc: '',
      args: [],
    );
  }

  /// `Establish prayer from the decline of the sun until the darkness of the night, and the Quran of dawn.`
  String get story_sat_3_translation {
    return Intl.message(
      'Establish prayer from the decline of the sun until the darkness of the night, and the Quran of dawn.',
      name: 'story_sat_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Giving Charity on Saturday`
  String get story_sat_4_title {
    return Intl.message(
      'Giving Charity on Saturday',
      name: 'story_sat_4_title',
      desc: '',
      args: [],
    );
  }

  /// `Establish prayer, give zakat, and bow with those who bow.`
  String get story_sat_4_translation {
    return Intl.message(
      'Establish prayer, give zakat, and bow with those who bow.',
      name: 'story_sat_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Istighfar and Repentance`
  String get story_sat_5_title {
    return Intl.message(
      'Istighfar and Repentance',
      name: 'story_sat_5_title',
      desc: '',
      args: [],
    );
  }

  /// `So glorify your Lord with praise and seek His forgiveness. Indeed, He is ever accepting of repentance.`
  String get story_sat_5_translation {
    return Intl.message(
      'So glorify your Lord with praise and seek His forgiveness. Indeed, He is ever accepting of repentance.',
      name: 'story_sat_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Supplication and Whispered Prayer on Sunday`
  String get story_sun_1_title {
    return Intl.message(
      'Supplication and Whispered Prayer on Sunday',
      name: 'story_sun_1_title',
      desc: '',
      args: [],
    );
  }

  /// `When My servants ask you about Me, indeed I am near. I respond to the call of the supplicant.`
  String get story_sun_1_translation {
    return Intl.message(
      'When My servants ask you about Me, indeed I am near. I respond to the call of the supplicant.',
      name: 'story_sun_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Dhikr and Tasbih`
  String get story_sun_2_title {
    return Intl.message(
      'Dhikr and Tasbih',
      name: 'story_sun_2_title',
      desc: '',
      args: [],
    );
  }

  /// `Surely, in the remembrance of Allah do hearts find rest.`
  String get story_sun_2_translation {
    return Intl.message(
      'Surely, in the remembrance of Allah do hearts find rest.',
      name: 'story_sun_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Voluntary Fasting on Sunday`
  String get story_sun_3_title {
    return Intl.message(
      'Voluntary Fasting on Sunday',
      name: 'story_sun_3_title',
      desc: '',
      args: [],
    );
  }

  /// `O you who believe, fasting has been prescribed for you as it was prescribed for those before you.`
  String get story_sun_3_translation {
    return Intl.message(
      'O you who believe, fasting has been prescribed for you as it was prescribed for those before you.',
      name: 'story_sun_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Recitation of the Noble Quran`
  String get story_sun_4_title {
    return Intl.message(
      'Recitation of the Noble Quran',
      name: 'story_sun_4_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, this Quran guides to that which is most upright.`
  String get story_sun_4_translation {
    return Intl.message(
      'Indeed, this Quran guides to that which is most upright.',
      name: 'story_sun_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Sending Blessings upon the Prophet`
  String get story_sun_5_title {
    return Intl.message(
      'Sending Blessings upon the Prophet',
      name: 'story_sun_5_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, Allah and His angels send blessings upon the Prophet. O believers, send blessings and peace upon him.`
  String get story_sun_5_translation {
    return Intl.message(
      'Indeed, Allah and His angels send blessings upon the Prophet. O believers, send blessings and peace upon him.',
      name: 'story_sun_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Hastening toward Good Deeds`
  String get story_mon_1_title {
    return Intl.message(
      'Hastening toward Good Deeds',
      name: 'story_mon_1_title',
      desc: '',
      args: [],
    );
  }

  /// `Race toward forgiveness from your Lord and a garden as wide as the heavens and the earth.`
  String get story_mon_1_translation {
    return Intl.message(
      'Race toward forgiveness from your Lord and a garden as wide as the heavens and the earth.',
      name: 'story_mon_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Praise and Gratitude to Allah`
  String get story_mon_2_title {
    return Intl.message(
      'Praise and Gratitude to Allah',
      name: 'story_mon_2_title',
      desc: '',
      args: [],
    );
  }

  /// `All praise belongs to Allah, Lord of the worlds.`
  String get story_mon_2_translation {
    return Intl.message(
      'All praise belongs to Allah, Lord of the worlds.',
      name: 'story_mon_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Repentance and Istighfar on Monday`
  String get story_mon_3_title {
    return Intl.message(
      'Repentance and Istighfar on Monday',
      name: 'story_mon_3_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, Allah loves those who repent and loves those who purify themselves.`
  String get story_mon_3_translation {
    return Intl.message(
      'Indeed, Allah loves those who repent and loves those who purify themselves.',
      name: 'story_mon_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Truthfulness and Honesty`
  String get story_mon_4_title {
    return Intl.message(
      'Truthfulness and Honesty',
      name: 'story_mon_4_title',
      desc: '',
      args: [],
    );
  }

  /// `O believers, fear Allah and be with the truthful.`
  String get story_mon_4_translation {
    return Intl.message(
      'O believers, fear Allah and be with the truthful.',
      name: 'story_mon_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Spending in the Way of Allah`
  String get story_mon_5_title {
    return Intl.message(
      'Spending in the Way of Allah',
      name: 'story_mon_5_title',
      desc: '',
      args: [],
    );
  }

  /// `And those in whose wealth there is a known right for the beggar and the deprived.`
  String get story_mon_5_translation {
    return Intl.message(
      'And those in whose wealth there is a known right for the beggar and the deprived.',
      name: 'story_mon_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Patience and Perseverance`
  String get story_tue_1_title {
    return Intl.message(
      'Patience and Perseverance',
      name: 'story_tue_1_title',
      desc: '',
      args: [],
    );
  }

  /// `Allah does not burden a soul beyond its capacity. For it is what it has earned and against it is what it has committed.`
  String get story_tue_1_translation {
    return Intl.message(
      'Allah does not burden a soul beyond its capacity. For it is what it has earned and against it is what it has committed.',
      name: 'story_tue_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Reciting Surah Al-Ikhlas`
  String get story_tue_2_title {
    return Intl.message(
      'Reciting Surah Al-Ikhlas',
      name: 'story_tue_2_title',
      desc: '',
      args: [],
    );
  }

  /// `Say: He is Allah, One. Allah, the Eternal Refuge.`
  String get story_tue_2_translation {
    return Intl.message(
      'Say: He is Allah, One. Allah, the Eternal Refuge.',
      name: 'story_tue_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Humility and Modesty`
  String get story_tue_3_title {
    return Intl.message(
      'Humility and Modesty',
      name: 'story_tue_3_title',
      desc: '',
      args: [],
    );
  }

  /// `The servants of the Most Merciful are those who walk upon the earth humbly.`
  String get story_tue_3_translation {
    return Intl.message(
      'The servants of the Most Merciful are those who walk upon the earth humbly.',
      name: 'story_tue_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Patience and Steadfastness`
  String get story_tue_4_title {
    return Intl.message(
      'Patience and Steadfastness',
      name: 'story_tue_4_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, Allah is with the patient.`
  String get story_tue_4_translation {
    return Intl.message(
      'Indeed, Allah is with the patient.',
      name: 'story_tue_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Trust in Allah`
  String get story_tue_5_title {
    return Intl.message(
      'Trust in Allah',
      name: 'story_tue_5_title',
      desc: '',
      args: [],
    );
  }

  /// `Whoever relies upon Allah, He is sufficient for him. Indeed, Allah will accomplish His purpose.`
  String get story_tue_5_translation {
    return Intl.message(
      'Whoever relies upon Allah, He is sufficient for him. Indeed, Allah will accomplish His purpose.',
      name: 'story_tue_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Gratitude for Allah's Blessings`
  String get story_wed_1_title {
    return Intl.message(
      'Gratitude for Allah\'s Blessings',
      name: 'story_wed_1_title',
      desc: '',
      args: [],
    );
  }

  /// `So which of your Lord's favors will you both deny?`
  String get story_wed_1_translation {
    return Intl.message(
      'So which of your Lord\'s favors will you both deny?',
      name: 'story_wed_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Good Deeds on Wednesday`
  String get story_wed_2_title {
    return Intl.message(
      'Good Deeds on Wednesday',
      name: 'story_wed_2_title',
      desc: '',
      args: [],
    );
  }

  /// `Whoever comes with a good deed shall have ten times the like of it.`
  String get story_wed_2_translation {
    return Intl.message(
      'Whoever comes with a good deed shall have ten times the like of it.',
      name: 'story_wed_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Brotherhood and Reconciliation`
  String get story_wed_3_title {
    return Intl.message(
      'Brotherhood and Reconciliation',
      name: 'story_wed_3_title',
      desc: '',
      args: [],
    );
  }

  /// `The believers are but brothers, so make peace between your brothers.`
  String get story_wed_3_translation {
    return Intl.message(
      'The believers are but brothers, so make peace between your brothers.',
      name: 'story_wed_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Seeking Knowledge`
  String get story_wed_4_title {
    return Intl.message(
      'Seeking Knowledge',
      name: 'story_wed_4_title',
      desc: '',
      args: [],
    );
  }

  /// `And say: My Lord, increase me in knowledge.`
  String get story_wed_4_translation {
    return Intl.message(
      'And say: My Lord, increase me in knowledge.',
      name: 'story_wed_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Supplication and Prayer`
  String get story_wed_5_title {
    return Intl.message(
      'Supplication and Prayer',
      name: 'story_wed_5_title',
      desc: '',
      args: [],
    );
  }

  /// `Your Lord said: Call upon Me; I will respond to you.`
  String get story_wed_5_translation {
    return Intl.message(
      'Your Lord said: Call upon Me; I will respond to you.',
      name: 'story_wed_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Glorifying Allah`
  String get story_thu_1_title {
    return Intl.message(
      'Glorifying Allah',
      name: 'story_thu_1_title',
      desc: '',
      args: [],
    );
  }

  /// `So exalted is He in whose hand is the dominion of all things, and to Him you will be returned.`
  String get story_thu_1_translation {
    return Intl.message(
      'So exalted is He in whose hand is the dominion of all things, and to Him you will be returned.',
      name: 'story_thu_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Preparing for Friday Prayer`
  String get story_thu_2_title {
    return Intl.message(
      'Preparing for Friday Prayer',
      name: 'story_thu_2_title',
      desc: '',
      args: [],
    );
  }

  /// `O believers, when the call is made for prayer on Friday, hasten to the remembrance of Allah.`
  String get story_thu_2_translation {
    return Intl.message(
      'O believers, when the call is made for prayer on Friday, hasten to the remembrance of Allah.',
      name: 'story_thu_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Night Prayer on Thursday`
  String get story_thu_3_title {
    return Intl.message(
      'Night Prayer on Thursday',
      name: 'story_thu_3_title',
      desc: '',
      args: [],
    );
  }

  /// `And during part of the night, pray with it as extra worship for you.`
  String get story_thu_3_translation {
    return Intl.message(
      'And during part of the night, pray with it as extra worship for you.',
      name: 'story_thu_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Sincere Worship and Servitude`
  String get story_thu_4_title {
    return Intl.message(
      'Sincere Worship and Servitude',
      name: 'story_thu_4_title',
      desc: '',
      args: [],
    );
  }

  /// `I did not create jinn and mankind except that they worship Me.`
  String get story_thu_4_translation {
    return Intl.message(
      'I did not create jinn and mankind except that they worship Me.',
      name: 'story_thu_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Hope in Allah's Mercy`
  String get story_thu_5_title {
    return Intl.message(
      'Hope in Allah\'s Mercy',
      name: 'story_thu_5_title',
      desc: '',
      args: [],
    );
  }

  /// `Say: O My servants who have transgressed against themselves, do not despair of Allah's mercy.`
  String get story_thu_5_translation {
    return Intl.message(
      'Say: O My servants who have transgressed against themselves, do not despair of Allah\'s mercy.',
      name: 'story_thu_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Friday Prayer and Seeking Provision`
  String get story_fri_1_title {
    return Intl.message(
      'Friday Prayer and Seeking Provision',
      name: 'story_fri_1_title',
      desc: '',
      args: [],
    );
  }

  /// `When the prayer has been concluded, disperse through the land and seek Allah's bounty.`
  String get story_fri_1_translation {
    return Intl.message(
      'When the prayer has been concluded, disperse through the land and seek Allah\'s bounty.',
      name: 'story_fri_1_translation',
      desc: '',
      args: [],
    );
  }

  /// `Reciting Surah Al-Kahf on Friday`
  String get story_fri_2_title {
    return Intl.message(
      'Reciting Surah Al-Kahf on Friday',
      name: 'story_fri_2_title',
      desc: '',
      args: [],
    );
  }

  /// `Praise be to Allah who revealed the Book to His servant and made no crookedness in it.`
  String get story_fri_2_translation {
    return Intl.message(
      'Praise be to Allah who revealed the Book to His servant and made no crookedness in it.',
      name: 'story_fri_2_translation',
      desc: '',
      args: [],
    );
  }

  /// `Abundant Salawat on Friday`
  String get story_fri_3_title {
    return Intl.message(
      'Abundant Salawat on Friday',
      name: 'story_fri_3_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, Allah and His angels send blessings upon the Prophet.`
  String get story_fri_3_translation {
    return Intl.message(
      'Indeed, Allah and His angels send blessings upon the Prophet.',
      name: 'story_fri_3_translation',
      desc: '',
      args: [],
    );
  }

  /// `Friday Charity`
  String get story_fri_4_title {
    return Intl.message(
      'Friday Charity',
      name: 'story_fri_4_title',
      desc: '',
      args: [],
    );
  }

  /// `Take from their wealth a charity by which you purify them and cause them increase.`
  String get story_fri_4_translation {
    return Intl.message(
      'Take from their wealth a charity by which you purify them and cause them increase.',
      name: 'story_fri_4_translation',
      desc: '',
      args: [],
    );
  }

  /// `Supplication and Drawing Near to Allah`
  String get story_fri_5_title {
    return Intl.message(
      'Supplication and Drawing Near to Allah',
      name: 'story_fri_5_title',
      desc: '',
      args: [],
    );
  }

  /// `O believers, fear Allah and seek the means of nearness to Him.`
  String get story_fri_5_translation {
    return Intl.message(
      'O believers, fear Allah and seek the means of nearness to Him.',
      name: 'story_fri_5_translation',
      desc: '',
      args: [],
    );
  }

  /// `Reviving Thursday Night`
  String get story_fri_6_title {
    return Intl.message(
      'Reviving Thursday Night',
      name: 'story_fri_6_title',
      desc: '',
      args: [],
    );
  }

  /// `Indeed, We sent it down in a blessed night; surely We are ever warning.`
  String get story_fri_6_translation {
    return Intl.message(
      'Indeed, We sent it down in a blessed night; surely We are ever warning.',
      name: 'story_fri_6_translation',
      desc: '',
      args: [],
    );
  }

  /// `Deeds and Supplications`
  String get amal_adia {
    return Intl.message(
      'Deeds and Supplications',
      name: 'amal_adia',
      desc: '',
      args: [],
    );
  }

  /// `Search by`
  String get search_by_type_title {
    return Intl.message(
      'Search by',
      name: 'search_by_type_title',
      desc: '',
      args: [],
    );
  }

  /// `Surah`
  String get search_surah_short {
    return Intl.message(
      'Surah',
      name: 'search_surah_short',
      desc: '',
      args: [],
    );
  }

  /// `Ayah`
  String get search_ayah_short {
    return Intl.message('Ayah', name: 'search_ayah_short', desc: '', args: []);
  }

  /// `Example: 2:255 or Allah`
  String get search_ayah_example {
    return Intl.message(
      'Example: 2:255 or Allah',
      name: 'search_ayah_example',
      desc: '',
      args: [],
    );
  }

  /// `Enter a Surah name`
  String get search_enter_surah_name {
    return Intl.message(
      'Enter a Surah name',
      name: 'search_enter_surah_name',
      desc: '',
      args: [],
    );
  }

  /// `Enter an Ayah, text, or number`
  String get search_enter_ayah_text_or_number {
    return Intl.message(
      'Enter an Ayah, text, or number',
      name: 'search_enter_ayah_text_or_number',
      desc: '',
      args: [],
    );
  }

  /// `Go to Ayah`
  String get search_go_to_ayah {
    return Intl.message(
      'Go to Ayah',
      name: 'search_go_to_ayah',
      desc: '',
      args: [],
    );
  }

  /// `No result found for "{query}"`
  String search_no_result_for(Object query) {
    return Intl.message(
      'No result found for "$query"',
      name: 'search_no_result_for',
      desc: '',
      args: [query],
    );
  }

  /// `Ayah text or number (example: 2:255)`
  String get search_ayah_filter_subtitle {
    return Intl.message(
      'Ayah text or number (example: 2:255)',
      name: 'search_ayah_filter_subtitle',
      desc: '',
      args: [],
    );
  }

  /// `Press back again to exit the app`
  String get exit_app_message {
    return Intl.message(
      'Press back again to exit the app',
      name: 'exit_app_message',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'fa'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
